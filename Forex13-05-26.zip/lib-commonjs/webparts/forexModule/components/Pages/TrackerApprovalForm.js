"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
require("../Pages/Css/NewRequest.scss");
var react_router_dom_1 = require("react-router-dom");
var spcrud_1 = tslib_1.__importDefault(require("../../service/BAL/spcrud"));
/* ---------- Layout Helpers ---------- */
var Section = function (_a) {
    var title = _a.title, children = _a.children;
    return (react_1.default.createElement("div", { className: "form-section" },
        title && react_1.default.createElement("h3", null, title),
        children));
};
var Grid = function (_a) {
    var children = _a.children;
    return (react_1.default.createElement("div", { className: "form-grid" }, children));
};
var Field = function (_a) {
    var label = _a.label, children = _a.children, full = _a.full;
    return (react_1.default.createElement("div", { className: full ? "form-field full" : "form-field" },
        react_1.default.createElement("label", null, label),
        children));
};
var CollapsibleSection = function (_a) {
    var title = _a.title, children = _a.children;
    var _b = react_1.default.useState(false), open = _b[0], setOpen = _b[1];
    return (react_1.default.createElement("div", { className: "form-section collapsible" },
        react_1.default.createElement("div", { className: "form-section-header", onClick: function () { return setOpen(!open); } },
            react_1.default.createElement("span", null, title),
            react_1.default.createElement("i", { className: "fas fa-chevron-".concat(open ? "up" : "down") })),
        open && (react_1.default.createElement("div", { className: "form-section-body" }, children))));
};
var TrackerApprovalForm = function (props) {
    var Id = (0, react_router_dom_1.useParams)().Id;
    var history = (0, react_router_dom_1.useHistory)();
    var spCrudOps = (0, spcrud_1.default)();
    var _a = (0, react_1.useState)(""), paymentType = _a[0], setPaymentType = _a[1];
    var _b = (0, react_1.useState)({}), employee = _b[0], setEmployee = _b[1];
    var _c = (0, react_1.useState)({}), vendor = _c[0], setVendor = _c[1];
    var _d = (0, react_1.useState)(""), requestNumber = _d[0], setRequestNumber = _d[1];
    var _e = (0, react_1.useState)(""), currency = _e[0], setCurrency = _e[1];
    var _f = (0, react_1.useState)(""), requestedOn = _f[0], setRequestedOn = _f[1];
    var _g = (0, react_1.useState)(""), totalAmount = _g[0], setTotalAmount = _g[1];
    var _h = (0, react_1.useState)(""), foreignBankCharges = _h[0], setForeignBankCharges = _h[1];
    var _j = (0, react_1.useState)({}), invoiceAttachments = _j[0], setInvoiceAttachments = _j[1];
    var _k = (0, react_1.useState)({}), otherAttachments = _k[0], setOtherAttachments = _k[1];
    var _l = (0, react_1.useState)({}), poAttachments = _l[0], setPoAttachments = _l[1];
    var _m = (0, react_1.useState)({}), piAttachments = _m[0], setPiAttachments = _m[1];
    var _o = (0, react_1.useState)({}), boeAttachments = _o[0], setBoeAttachments = _o[1];
    var _p = (0, react_1.useState)({}), blAttachments = _p[0], setBlAttachments = _p[1];
    var _q = (0, react_1.useState)({}), poAttachmentsAdvance = _q[0], setPoAttachmentsAddvance = _q[1];
    var _r = (0, react_1.useState)({}), piAttachmentsAddvance = _r[0], setPiAttachmentsAddvance = _r[1];
    var _s = (0, react_1.useState)(false), isClosedWithAD = _s[0], setIsClosedWithAD = _s[1];
    var _t = (0, react_1.useState)(""), referenceNumber = _t[0], setReferenceNumber = _t[1];
    var _u = (0, react_1.useState)([
        {
            invoiceNo: "",
            invoiceDate: "",
            boeNo: "",
            boeDate: "",
            mrnNo: "",
            blNo: "",
            blDate: "",
            invoiceAmount: "",
        },
    ]), rows = _u[0], setRows = _u[1];
    var _v = (0, react_1.useState)([
        {
            invoiceNo: "",
            invoiceDate: "",
            boeNo: "",
            boeDate: "",
            mrnNo: "",
            blNo: "",
            blDate: "",
            invoiceAmountnew: "",
        },
    ]), ShowInvoiceData = _v[0], serShowInvoiceData = _v[1];
    var _w = (0, react_1.useState)([]), workflowHistory = _w[0], setWorkflowHistory = _w[1];
    var _x = (0, react_1.useState)(""), approverRemark = _x[0], setApproverRemark = _x[1];
    (0, react_1.useEffect)(function () {
        if (Id)
            loadForexData(Id);
    }, [Id]);
    var getVendorData = function (vendorCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, res, v;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    return [4 /*yield*/, sp.getData("VendorMaster", "VendorCode,VendorName,VendorNameLegal,VendorShortName,VendorType,City/Title,State/Title,Country/Title,Currency/Title,PostalCode,ContactPersonName,EmailId,PhoneNumber,AlternateContact,BeneficiaryName,BankName,AccountNumberIBAN,SWIFTBICCode,RoutingNumberABA,IFSCCode,IntermediaryBank,IntermediarySWIFTCode,NatureOfPayment/Title,PurposeCodeRBI,BankCountry,BankAddress,VendorAddress", "NatureOfPayment,City,State,Country,Currency", "VendorCode eq '".concat(vendorCode, "'"), { column: "ID", isAscending: true }, 1, props)];
                case 2:
                    res = _a.sent();
                    if (res.length > 0) {
                        v = res[0];
                        setVendor({
                            VendorCode: v.VendorCode,
                            VendorName: v.VendorName,
                            VendorAddress: v.VendorAddress,
                            City: v.City.Title,
                            Country: v.Country.Title,
                            PostalCode: v.PostalCode,
                            BankName: v.BankName,
                            BankCountry: v.BankCountry,
                            SWIFTBICCode: v.SWIFTBICCode,
                            BankAddress: v.BankAddress,
                            AccountNumberIBAN: v.AccountNumberIBAN
                        });
                    }
                    return [2 /*return*/];
            }
        });
    }); };
    var loadForexData = function (id) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, parent, data, parsed, child, formattedRows, invoiceAttachmentMap_1, otherAttachmentMap_1, poAttachmentMap_1, piAttachmentMap_1;
        var _a, _b, _c;
        return tslib_1.__generator(this, function (_d) {
            switch (_d.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _d.sent();
                    return [4 /*yield*/, sp.getData("ForexRequest", "*,RM/Title,HOD/Title,Currency/Title", "RM,HOD,Currency", "ID eq ".concat(id), { column: "ID", isAscending: true }, 1, props)];
                case 2:
                    parent = _d.sent();
                    if (!(parent.length > 0)) return [3 /*break*/, 5];
                    data = parent[0];
                    if (data.WorkFlowHistory) {
                        try {
                            parsed = JSON.parse(data.WorkFlowHistory);
                            setWorkflowHistory(parsed);
                        }
                        catch (_e) {
                            setWorkflowHistory([]);
                        }
                    }
                    setPaymentType(data.ForexType);
                    setRequestNumber(data.ForexNumber);
                    setRequestedOn((_a = data.RequestedOn) === null || _a === void 0 ? void 0 : _a.split("T")[0]);
                    setCurrency(data.Currency.Title);
                    setTotalAmount(data.TotalAmount);
                    setForeignBankCharges(data.ForeignBankCharges);
                    setEmployee({
                        EmployeeCode: data.EmployeeCode || "",
                        EmployeeName: data.EmployeeName || "",
                        Division: data.Division || "",
                        Location: data.Location || "",
                        RM: ((_b = data.RM) === null || _b === void 0 ? void 0 : _b.Title) || "",
                        HOD: ((_c = data.HOD) === null || _c === void 0 ? void 0 : _c.Title) || "",
                        ContactNo: data.ContactNo || "",
                        EmployeeStatus: data.EmployeeStatus || "",
                        Email: data.Email || ""
                    });
                    // setVendor({
                    //     VendorCode: data.VendorCode,
                    //     VendorName: data.VendorName,
                    //     VendorAddress: data.VendorAddress,
                    //     City: data.City,
                    //     Country: data.Country,
                    //     PostalCode: data.PostalCode,
                    //     BankName: data.BankName,
                    //     BankCountry: data.BankCountry,
                    //     SWIFTBICCode: data.BankSwiftCode,
                    //     BankAddress: data.BankAddress,
                    //     AccountNumberIBAN: data.BankAccNo,
                    // });
                    getVendorData(data.VendorCode);
                    return [4 /*yield*/, loadTrackerData(Number(id))];
                case 3:
                    _d.sent();
                    return [4 /*yield*/, sp.getData("ForexServicesBillPayment", "*,AttachmentFiles", "AttachmentFiles", "ForexIDId eq ".concat(id), { column: "ID", isAscending: true }, 5000, props)];
                case 4:
                    child = _d.sent();
                    if (child.length > 0) {
                        formattedRows = child.map(function (item) {
                            var _a, _b, _c, _d;
                            return ({
                                invoiceNo: item.InvoiceNumber || "",
                                invoiceDate: ((_a = item.InvoiceDate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "",
                                invoiceAmountnew: item.InvoiceAmount || "",
                                mrnNo: item.MRNNumber || "",
                                mrnDate: ((_b = item.MRNDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                blNo: item.BillofLandingNo || "",
                                blDate: ((_c = item.BillOfLandingdate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                boeNo: item.BOENo || "",
                                boeDate: ((_d = item.BOEDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || ""
                            });
                        });
                        serShowInvoiceData(formattedRows);
                        invoiceAttachmentMap_1 = {};
                        otherAttachmentMap_1 = {};
                        poAttachmentMap_1 = {};
                        piAttachmentMap_1 = {};
                        child.forEach(function (item, index) {
                            var files = item.AttachmentFiles || [];
                            invoiceAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("INV_"); });
                            otherAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("DOC_"); });
                            poAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PO_"); });
                            piAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PI_"); });
                        });
                        setInvoiceAttachments(invoiceAttachmentMap_1);
                        setOtherAttachments(otherAttachmentMap_1);
                        setPoAttachments(poAttachmentMap_1);
                        setPiAttachments(piAttachmentMap_1);
                    }
                    _d.label = 5;
                case 5: return [2 /*return*/];
            }
        });
    }); };
    /* ---------- Rows ---------- */
    var addRow = function () {
        setRows(tslib_1.__spreadArray(tslib_1.__spreadArray([], rows, true), [
            {
                invoiceNo: "",
                invoiceDate: "",
                boeNo: "",
                boeDate: "",
                mrnNo: "",
                blNo: "",
                blDate: "",
                invoiceAmount: "",
            },
        ], false));
    };
    var deleteRow = function (index) {
        var updated = rows.filter(function (_, i) { return i !== index; });
        setRows(updated);
    };
    var handleChange = function (index, field, value) {
        var updated = tslib_1.__spreadArray([], rows, true);
        updated[index][field] = value;
        setRows(updated);
    };
    var totalInvoiceAmount = rows.reduce(function (sum, r) { return sum + (parseFloat(r.invoiceAmount) || 0); }, 0);
    var totalInvoiceAmountnew = ShowInvoiceData.reduce(function (sum, r) { return sum + (parseFloat(r.invoiceAmountnew) || 0); }, 0);
    var uniqueBoeNumbers = Array.from(new Set(rows.map(function (r) { return r.boeNo; }).filter(Boolean)));
    var uniqueBlNumbers = Array.from(new Set(rows.map(function (r) { return r.blNo; }).filter(Boolean)));
    var loadTrackerData = function (forexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, tracker, formattedRows, attachmentMap, poAttachmentMap_2, piAttachmentMap_2, otherAttachmentMap_2, boeAttachmentMap_1, blAttachmentMap_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    return [4 /*yield*/, sp.getData("ForexAdvanceBillPayment", "*,AttachmentFiles", "AttachmentFiles", "ForexIDId eq ".concat(forexId), { column: "ID", isAscending: true }, 5000, props)];
                case 2:
                    tracker = _a.sent();
                    if (tracker.length > 0) {
                        formattedRows = tracker.map(function (item) {
                            var _a, _b, _c, _d;
                            return ({
                                invoiceNo: item.InvoiceNumber || "",
                                invoiceDate: ((_a = item.InvoiceDate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "",
                                invoiceAmount: item.InvoiceAmount || "",
                                mrnNo: item.MRNNumber || "",
                                mrnDate: ((_b = item.MRNDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                blNo: item.BillofLandingNo || "",
                                blDate: ((_c = item.BillOfLandingdate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                boeNo: item.BOENo || "",
                                boeDate: ((_d = item.BOEDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || ""
                            });
                        });
                        setRows(formattedRows);
                        attachmentMap = {};
                        poAttachmentMap_2 = {};
                        piAttachmentMap_2 = {};
                        otherAttachmentMap_2 = {};
                        boeAttachmentMap_1 = {};
                        blAttachmentMap_1 = {};
                        tracker.forEach(function (item, index) {
                            var files = item.AttachmentFiles || [];
                            poAttachmentMap_2[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PO_"); });
                            piAttachmentMap_2[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PI_"); });
                            otherAttachmentMap_2[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("DOC_"); });
                            boeAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("BOE_"); });
                            blAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("BL_"); });
                        });
                        setPoAttachmentsAddvance(poAttachmentMap_2);
                        setPiAttachmentsAddvance(piAttachmentMap_2);
                        setOtherAttachments(otherAttachmentMap_2);
                        setBoeAttachments(boeAttachmentMap_1);
                        setBlAttachments(blAttachmentMap_1);
                    }
                    return [2 /*return*/];
            }
        });
    }); };
    var handleInvoiceFile = function (index, files) {
        if (!files)
            return;
        var updated = tslib_1.__assign({}, invoiceAttachments);
        updated[index] = Array.from(files);
        setInvoiceAttachments(updated);
    };
    var handleOtherFile = function (index, files) {
        if (!files)
            return;
        var updated = tslib_1.__assign({}, otherAttachments);
        updated[index] = Array.from(files);
        setOtherAttachments(updated);
    };
    var handleBoeUpload = function (index, files) {
        if (!files)
            return;
        var updated = tslib_1.__assign({}, boeAttachments);
        updated[index] = Array.from(files);
        setBoeAttachments(updated);
    };
    var handleBlUpload = function (index, files) {
        if (!files)
            return;
        var updated = tslib_1.__assign({}, blAttachments);
        updated[index] = Array.from(files);
        setBlAttachments(updated);
    };
    var rejectRequest = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, existingItem, existingHistory, user, updatedHistory;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    if (!approverRemark || approverRemark.trim() === "") {
                        alert("Please enter remark before rejecting");
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, sp.getData("ForexRequest", "WorkFlowHistory", "", "ID eq ".concat(Id), { column: "ID", isAscending: true }, 1, props)];
                case 2:
                    existingItem = _a.sent();
                    existingHistory = [];
                    if (existingItem.length > 0 && existingItem[0].WorkFlowHistory) {
                        try {
                            existingHistory = JSON.parse(existingItem[0].WorkFlowHistory);
                        }
                        catch (_b) {
                            existingHistory = [];
                        }
                    }
                    user = props.context.pageContext.user;
                    updatedHistory = tslib_1.__spreadArray([], existingHistory, true);
                    updatedHistory.push({
                        CurrentApprover: user.displayName,
                        Role: "TreasuryApproval",
                        ActionTaken: "Rejected",
                        Comment: approverRemark,
                        Date: new Date().toISOString(),
                        CurrentStatus: "Rejected"
                    });
                    return [4 /*yield*/, sp.updateData("ForexRequest", Number(Id), {
                            Status: "Rejected",
                            ApproverRemark: approverRemark,
                            WorkFlowHistory: JSON.stringify(updatedHistory) // 🔥 IMPORTANT
                        }, props)];
                case 3:
                    _a.sent();
                    alert("Request Rejected");
                    history.push("/");
                    return [2 /*return*/];
            }
        });
    }); };
    var approveRequest = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, existingItem, existingHistory, user, updatedHistory;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    if (!approverRemark || approverRemark.trim() === "") {
                        alert("Please enter remark before approving");
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, sp.getData("ForexRequest", "WorkFlowHistory", "", "ID eq ".concat(Id), { column: "ID", isAscending: true }, 1, props)];
                case 2:
                    existingItem = _a.sent();
                    existingHistory = [];
                    if (existingItem.length > 0 && existingItem[0].WorkFlowHistory) {
                        try {
                            existingHistory = JSON.parse(existingItem[0].WorkFlowHistory);
                        }
                        catch (_b) {
                            existingHistory = [];
                        }
                    }
                    user = props.context.pageContext.user;
                    updatedHistory = tslib_1.__spreadArray([], existingHistory, true);
                    updatedHistory.push({
                        CurrentApprover: user.displayName,
                        Role: "TreasuryApproval",
                        ActionTaken: "Approved",
                        Comment: approverRemark,
                        Date: new Date().toISOString(),
                        CurrentStatus: "Paid & Closed"
                    });
                    return [4 /*yield*/, sp.updateData("ForexRequest", Number(Id), {
                            Status: "Paid & Closed",
                            TreasuryApproverRemark: approverRemark,
                            ClosedWithADBank: isClosedWithAD ? "Yes" : "No",
                            ReferenceNumber: referenceNumber,
                            WorkFlowHistory: JSON.stringify(updatedHistory), // 🔥 IMPORTANT
                            CurrentApproverId: null
                        }, props)];
                case 3:
                    _a.sent();
                    alert("Request Approved");
                    history.push("/");
                    return [2 /*return*/];
            }
        });
    }); };
    return (react_1.default.createElement("div", { className: "forex-wrapper" },
        react_1.default.createElement("div", { className: "forex-header" },
            react_1.default.createElement("h2", null, "Forex Payment - Advance Payment Tracker Approval Form")),
        react_1.default.createElement("div", { className: "forex-card" },
            react_1.default.createElement(Section, { title: "Requestor Information" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Type" },
                        react_1.default.createElement("input", { value: paymentType, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Code" },
                        react_1.default.createElement("input", { value: employee.EmployeeCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Name" },
                        react_1.default.createElement("input", { value: employee.EmployeeName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Division" },
                        react_1.default.createElement("input", { value: employee.Division, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Location" },
                        react_1.default.createElement("input", { value: employee.Location, readOnly: true })),
                    react_1.default.createElement(Field, { label: "RM" },
                        react_1.default.createElement("input", { value: employee.RM, readOnly: true })),
                    react_1.default.createElement(Field, { label: "HOD" },
                        react_1.default.createElement("input", { value: employee.HOD, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Contact No" },
                        react_1.default.createElement("input", { value: employee.ContactNo, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Status" },
                        react_1.default.createElement("input", { value: employee.EmployeeStatus, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Email", full: true },
                        react_1.default.createElement("input", { value: employee.Email, readOnly: true })))),
            react_1.default.createElement(CollapsibleSection, { title: "Vendor - Beneficiary Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Vendor Code" },
                        react_1.default.createElement("input", { value: vendor.VendorCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Vendor Name" },
                        react_1.default.createElement("input", { value: vendor.VendorName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Address", full: true },
                        react_1.default.createElement("input", { value: vendor.VendorAddress, readOnly: true })),
                    react_1.default.createElement(Field, { label: "City" },
                        react_1.default.createElement("input", { value: vendor.City, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Country" },
                        react_1.default.createElement("input", { value: vendor.Country, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Pincode" },
                        react_1.default.createElement("input", { value: vendor.PostalCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Name" },
                        react_1.default.createElement("input", { value: vendor.BankName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Country" },
                        react_1.default.createElement("input", { value: vendor.BankCountry, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Swift Code" },
                        react_1.default.createElement("input", { value: vendor.SWIFTBICCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Branch" },
                        react_1.default.createElement("input", { value: vendor.BankAddress, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank IBAN / Account No", full: true },
                        react_1.default.createElement("input", { value: vendor.AccountNumberIBAN, readOnly: true })))),
            react_1.default.createElement(Section, { title: "Advance Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { value: totalAmount, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { value: foreignBankCharges, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, readOnly: true })))),
            react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                react_1.default.createElement("thead", null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("th", null, "Sr.No."),
                        react_1.default.createElement("th", null, "Performa Invoice No"),
                        react_1.default.createElement("th", null, "Performa Invoice Date"),
                        react_1.default.createElement("th", null, "Performa Invoice Amount"),
                        react_1.default.createElement("th", null, "Attach PO"),
                        react_1.default.createElement("th", null, "Attach PI"),
                        react_1.default.createElement("th", null, "Attach Other"))),
                react_1.default.createElement("tbody", null, ShowInvoiceData.map(function (row, index) {
                    var _a, _b, _c;
                    return (react_1.default.createElement("tr", { key: index },
                        react_1.default.createElement("td", null, index + 1),
                        react_1.default.createElement("td", null, row.invoiceNo),
                        react_1.default.createElement("td", null, row.invoiceDate),
                        react_1.default.createElement("td", null, row.invoiceAmountnew),
                        react_1.default.createElement("td", null, ((_a = poAttachments[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (poAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                            react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", className: "upload-link" }, file.FileName))); })) : (react_1.default.createElement("span", null, "-"))),
                        react_1.default.createElement("td", null, ((_b = piAttachments[index]) === null || _b === void 0 ? void 0 : _b.length) > 0 ? (piAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                            react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", className: "upload-link" }, file.FileName))); })) : (react_1.default.createElement("span", null, "-"))),
                        react_1.default.createElement("td", null, ((_c = otherAttachments[index]) === null || _c === void 0 ? void 0 : _c.length) > 0 ? (otherAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                            react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", className: "upload-link" }, file.FileName))); })) : (react_1.default.createElement("span", null, "-")))));
                })),
                react_1.default.createElement("tfoot", null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("td", { colSpan: 2 }),
                        react_1.default.createElement("td", { style: { fontWeight: "bold" } }, "Total Amount"),
                        react_1.default.createElement("td", null, totalInvoiceAmountnew.toFixed(2)),
                        react_1.default.createElement("td", { colSpan: 3 })))),
            paymentType === "Goods-Advance Payment" && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(Section, { title: "Bill Payment Details (For Goods Bill Payment)" },
                    react_1.default.createElement("p", { style: { color: "red", fontSize: "12px" } }, "Tracker data submitted by user"),
                    react_1.default.createElement("table", { className: "data-table" },
                        react_1.default.createElement("thead", null,
                            react_1.default.createElement("tr", null,
                                react_1.default.createElement("th", null, "Sr.No."),
                                react_1.default.createElement("th", null, "Invoice Number"),
                                react_1.default.createElement("th", null, "Invoice Date"),
                                react_1.default.createElement("th", null, "BOE Number"),
                                react_1.default.createElement("th", null, "BOE Date"),
                                react_1.default.createElement("th", null, "MRN Number"),
                                react_1.default.createElement("th", null, "Bill of Lading Number"),
                                react_1.default.createElement("th", null, "Bill of Lading Date"),
                                react_1.default.createElement("th", null, "Invoice Amount"),
                                react_1.default.createElement("th", null, "Attach Invoice"),
                                react_1.default.createElement("th", null, "Attach Other"))),
                        react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                            var _a, _b;
                            return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, index + 1),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.invoiceNo)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.invoiceDate)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.boeNo)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.boeDate)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.mrnNo)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.blNo)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.blDate)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.invoiceAmount)),
                                react_1.default.createElement("td", null, ((_a = poAttachmentsAdvance[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (poAttachmentsAdvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, download: true, target: "_blank", rel: "noopener noreferrer", className: "upload-link" },
                                        "\uD83D\uDCE5 ",
                                        file.FileName || file.name))); })) : (react_1.default.createElement("span", null, "-"))),
                                react_1.default.createElement("td", null, ((_b = piAttachmentsAddvance[index]) === null || _b === void 0 ? void 0 : _b.length) > 0 ? (piAttachmentsAddvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, download: true, target: "_blank", rel: "noopener noreferrer", className: "upload-link" },
                                        "\uD83D\uDCE5 ",
                                        file.FileName || file.name))); })) : (react_1.default.createElement("span", null, "-")))));
                        })),
                        react_1.default.createElement("tfoot", null,
                            react_1.default.createElement("tr", null,
                                react_1.default.createElement("td", { colSpan: 7 }),
                                react_1.default.createElement("td", { style: { fontWeight: "bold" } }, "Total Amount"),
                                react_1.default.createElement("td", null, totalInvoiceAmount.toFixed(2)),
                                react_1.default.createElement("td", { colSpan: 2 }))))),
                react_1.default.createElement("div", { style: { display: "flex", gap: "40px", marginTop: "20px" } },
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "12px" } }, "Unique BOE no listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "BOE No"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBoeNumbers.map(function (boe, index) {
                                var _a;
                                return (react_1.default.createElement("tr", { key: index },
                                    react_1.default.createElement("td", null, boe),
                                    react_1.default.createElement("td", null, ((_a = boeAttachments[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (boeAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i, style: { fontSize: "12px" } },
                                        react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", download: true, rel: "noopener noreferrer", className: "upload-link" },
                                            "\uD83D\uDCC4 ",
                                            file.FileName))); })) : (react_1.default.createElement("span", null, "-")))));
                            })))),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "12px" } }, "Unique Bill of Lading listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "Bill of Lading"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBlNumbers.map(function (bl, index) {
                                var _a;
                                return (react_1.default.createElement("tr", { key: index },
                                    react_1.default.createElement("td", null, bl),
                                    react_1.default.createElement("td", null, ((_a = blAttachments[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (blAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i, style: { fontSize: "12px" } },
                                        react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", download: true, rel: "noopener noreferrer", className: "upload-link" },
                                            "\uD83D\uDCC4 ",
                                            file.FileName))); })) : (react_1.default.createElement("span", null, "-")))));
                            }))))))),
            paymentType === "Service-Advance Payment" && (react_1.default.createElement("div", { style: { marginTop: "30px" } },
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Bill Payment Details (for Service Bill Payment)")),
                react_1.default.createElement("table", { className: "data-table" },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr.No."),
                            react_1.default.createElement("th", null, "Invoice Number"),
                            react_1.default.createElement("th", null, "Invoice Date"),
                            react_1.default.createElement("th", null, "Invoice Amount"),
                            react_1.default.createElement("th", null, "MRN Number"),
                            react_1.default.createElement("th", null, "MRN Date"),
                            react_1.default.createElement("th", null, "Invoice Document"),
                            react_1.default.createElement("th", null, "Other Document"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.invoiceNo)),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.invoiceDate)),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.invoiceAmount)),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.mrnNo)),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.mrnDate)),
                            react_1.default.createElement("td", null, ((_a = poAttachmentsAdvance[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (poAttachmentsAdvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                react_1.default.createElement("a", { href: file.ServerRelativeUrl, download: true, target: "_blank", rel: "noopener noreferrer", className: "upload-link" },
                                    "\uD83D\uDCE5 ",
                                    file.FileName || file.name))); })) : (react_1.default.createElement("span", null, "-"))),
                            react_1.default.createElement("td", null, ((_b = piAttachmentsAddvance[index]) === null || _b === void 0 ? void 0 : _b.length) > 0 ? (piAttachmentsAddvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                react_1.default.createElement("a", { href: file.ServerRelativeUrl, download: true, target: "_blank", rel: "noopener noreferrer", className: "upload-link" },
                                    "\uD83D\uDCE5 ",
                                    file.FileName || file.name))); })) : (react_1.default.createElement("span", null, "-")))));
                    })),
                    react_1.default.createElement("tfoot", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("td", { colSpan: 2 }),
                            react_1.default.createElement("td", { style: { fontWeight: "bold" } }, "Total Amount"),
                            react_1.default.createElement("td", null, totalInvoiceAmount.toFixed(2)),
                            react_1.default.createElement("td", { colSpan: 5 })))))),
            react_1.default.createElement(CollapsibleSection, { title: "Workflow History" }, workflowHistory.length > 0 ? (react_1.default.createElement("table", { className: "data-table" },
                react_1.default.createElement("thead", null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("th", null, "Action By"),
                        react_1.default.createElement("th", null, "Action"),
                        react_1.default.createElement("th", null, "Remark"),
                        react_1.default.createElement("th", null, "Date"),
                        react_1.default.createElement("th", null, "Status"))),
                react_1.default.createElement("tbody", null, workflowHistory.map(function (item, index) { return (react_1.default.createElement("tr", { key: index },
                    react_1.default.createElement("td", null, item.CurrentApprover),
                    react_1.default.createElement("td", null, item.ActionTaken),
                    react_1.default.createElement("td", null, item.Comment || "-"),
                    react_1.default.createElement("td", null, item.Date
                        ? new Date(item.Date).toLocaleString("en-GB")
                        : ""),
                    react_1.default.createElement("td", null, item.CurrentStatus))); })))) : (react_1.default.createElement("p", null, "No workflow history available"))),
            react_1.default.createElement("div", { style: { marginTop: "20px" } },
                react_1.default.createElement("label", null,
                    react_1.default.createElement("b", null, "Approver's Remarks:")),
                react_1.default.createElement("textarea", { style: { width: "70%", height: "40px", marginLeft: "10px" }, value: approverRemark, onChange: function (e) { return setApproverRemark(e.target.value); } })),
            react_1.default.createElement(Section, { title: "Bank Closure Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Closed with AD bank" },
                        react_1.default.createElement("input", { type: "checkbox", checked: isClosedWithAD, onChange: function (e) {
                                setIsClosedWithAD(e.target.checked);
                                // Clear reference if unchecked
                                if (!e.target.checked) {
                                    setReferenceNumber("");
                                }
                            } })),
                    react_1.default.createElement(Field, { label: "Reference Number (on selection of checkbox)" },
                        react_1.default.createElement("input", { type: "text", value: referenceNumber, disabled: !isClosedWithAD, onChange: function (e) { return setReferenceNumber(e.target.value); } })))),
            react_1.default.createElement("div", { className: "button-row" },
                react_1.default.createElement("button", { className: "btn-submit", onClick: approveRequest }, "Approve"),
                react_1.default.createElement("button", { className: "btn-Reject", onClick: rejectRequest, style: { background: "#d9534f !important" } }, "Reject"),
                react_1.default.createElement("button", { className: "btn-exit", onClick: function () { return history.push("/"); } }, "Exit")))));
};
exports.default = TrackerApprovalForm;
//# sourceMappingURL=TrackerApprovalForm.js.map