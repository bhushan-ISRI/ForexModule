"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var react_router_dom_1 = require("react-router-dom");
require("../../components/Pages/Css/ApprovedRejectedbyme.scss");
var spcrud_1 = tslib_1.__importDefault(require("../../service/BAL/spcrud"));
var react_router_dom_2 = require("react-router-dom");
var ModernForexDashboard = function (props) {
    var _a, _b;
    var _c = (0, react_1.useState)([]), listData = _c[0], setListData = _c[1];
    var _d = (0, react_1.useState)([]), filteredData = _d[0], setFilteredData = _d[1];
    var _e = (0, react_1.useState)(false), loading = _e[0], setLoading = _e[1];
    var _f = (0, react_1.useState)(""), searchTerm = _f[0], setSearchTerm = _f[1];
    var _g = (0, react_1.useState)("All"), statusFilter = _g[0], setStatusFilter = _g[1];
    // =========================================
    // PAGINATION STATES
    // =========================================
    var _h = (0, react_1.useState)(1), currentPage = _h[0], setCurrentPage = _h[1];
    var itemsPerPage = 10;
    var currentUser = (_b = (_a = props.context.pageContext.user.displayName) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === null || _b === void 0 ? void 0 : _b.trim();
    // =========================================
    // FORMAT DATE
    // =========================================
    var history = (0, react_router_dom_2.useHistory)();
    var formatDate = function (dateString) {
        if (!dateString)
            return "-";
        return new Date(dateString)
            .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric"
        })
            .replace(/\//g, "-");
    };
    // =========================================
    // GET CURRENT APPROVER
    // =========================================
    var getCurrentApprover = function (allApprovers) {
        var matrix = [];
        try {
            matrix =
                typeof allApprovers === "string"
                    ? JSON.parse(allApprovers)
                    : allApprovers || [];
        }
        catch (_a) {
            matrix = [];
        }
        var current = matrix.find(function (x) { return x.Status === "Pending"; });
        if (!current)
            return "Completed";
        return "".concat(current.Role, " - ").concat(current.Approver);
    };
    // =========================================
    // LOAD DATA
    // =========================================
    var loadData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var spCrudOps, data, e_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, 4, 5]);
                    setLoading(true);
                    return [4 /*yield*/, (0, spcrud_1.default)()];
                case 1:
                    spCrudOps = _a.sent();
                    return [4 /*yield*/, spCrudOps.getRootData("ForexRequest", "ID,Title,ForexNumber,ForexType,EmployeeName,EmployeeCode,RequestedOn,Status,Location,VendorName,TotalAmount,AllApprovers,WorkFlowHistory", "", "", { column: "ID", isAscending: false }, 5000, props)];
                case 2:
                    data = _a.sent();
                    console.log("🔥 Dashboard Data:", data);
                    setListData(Array.isArray(data) ? data : []);
                    setFilteredData(Array.isArray(data) ? data : []);
                    return [3 /*break*/, 5];
                case 3:
                    e_1 = _a.sent();
                    console.error("❌ Dashboard Error:", e_1);
                    alert("Error loading dashboard");
                    return [3 /*break*/, 5];
                case 4:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        loadData();
    }, []);
    // =========================================
    // DASHBOARD COUNTS
    // =========================================
    var dashboardCounts = (0, react_1.useMemo)(function () {
        var approvedByMe = listData.filter(function (item) {
            var history = [];
            try {
                history =
                    typeof item.WorkFlowHistory === "string"
                        ? JSON.parse(item.WorkFlowHistory)
                        : item.WorkFlowHistory || [];
            }
            catch (_a) {
                history = [];
            }
            return history.some(function (h) {
                var _a, _b;
                return h.ActionTaken === "Approved" &&
                    ((_b = (_a = h.CurrentApprover) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === null || _b === void 0 ? void 0 : _b.trim()) === currentUser;
            });
        }).length;
        var rejectedByMe = listData.filter(function (item) {
            var history = [];
            try {
                history =
                    typeof item.WorkFlowHistory === "string"
                        ? JSON.parse(item.WorkFlowHistory)
                        : item.WorkFlowHistory || [];
            }
            catch (_a) {
                history = [];
            }
            return history.some(function (h) {
                var _a, _b;
                return h.ActionTaken === "Rejected" &&
                    ((_b = (_a = h.CurrentApprover) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === null || _b === void 0 ? void 0 : _b.trim()) === currentUser;
            });
        }).length;
        var sentBackByMe = listData.filter(function (item) {
            var history = [];
            try {
                history =
                    typeof item.WorkFlowHistory === "string"
                        ? JSON.parse(item.WorkFlowHistory)
                        : item.WorkFlowHistory || [];
            }
            catch (_a) {
                history = [];
            }
            return history.some(function (h) {
                var _a, _b;
                return h.ActionTaken === "Sent Back" &&
                    ((_b = (_a = h.CurrentApprover) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === null || _b === void 0 ? void 0 : _b.trim()) === currentUser;
            });
        }).length;
        return {
            total: listData.length,
            approvedByMe: approvedByMe,
            rejectedByMe: rejectedByMe,
            sentBackByMe: sentBackByMe
        };
    }, [listData]);
    // =========================================
    // FILTERS
    // =========================================
    (0, react_1.useEffect)(function () {
        // =====================================
        // DEFAULT DATA = ONLY MY ACTIONED ITEMS
        // =====================================
        var data = listData.filter(function (item) {
            var history = [];
            try {
                history =
                    typeof item.WorkFlowHistory === "string"
                        ? JSON.parse(item.WorkFlowHistory)
                        : item.WorkFlowHistory || [];
            }
            catch (_a) {
                history = [];
            }
            return history.some(function (h) {
                return ["Approved", "Rejected", "Sent Back"].includes(h.ActionTaken) &&
                    (h.CurrentApprover || "")
                        .toLowerCase()
                        .trim() === currentUser;
            });
        });
        // =====================================
        // STATUS FILTER
        // =====================================
        if (statusFilter !== "All") {
            if (statusFilter === "ApprovedByMe") {
                data = data.filter(function (item) {
                    var history = [];
                    try {
                        history =
                            typeof item.WorkFlowHistory === "string"
                                ? JSON.parse(item.WorkFlowHistory)
                                : item.WorkFlowHistory || [];
                    }
                    catch (_a) {
                        history = [];
                    }
                    return history.some(function (h) {
                        return h.ActionTaken === "Approved" &&
                            (h.CurrentApprover || "")
                                .toLowerCase()
                                .trim() === currentUser;
                    });
                });
            }
            else if (statusFilter === "RejectedByMe") {
                data = data.filter(function (item) {
                    var history = [];
                    try {
                        history =
                            typeof item.WorkFlowHistory === "string"
                                ? JSON.parse(item.WorkFlowHistory)
                                : item.WorkFlowHistory || [];
                    }
                    catch (_a) {
                        history = [];
                    }
                    return history.some(function (h) {
                        return h.ActionTaken === "Rejected" &&
                            (h.CurrentApprover || "")
                                .toLowerCase()
                                .trim() === currentUser;
                    });
                });
            }
            else if (statusFilter === "SentBackByMe") {
                data = data.filter(function (item) {
                    var history = [];
                    try {
                        history =
                            typeof item.WorkFlowHistory === "string"
                                ? JSON.parse(item.WorkFlowHistory)
                                : item.WorkFlowHistory || [];
                    }
                    catch (_a) {
                        history = [];
                    }
                    return history.some(function (h) {
                        return h.ActionTaken === "Sent Back" &&
                            (h.CurrentApprover || "")
                                .toLowerCase()
                                .trim() === currentUser;
                    });
                });
            }
        }
        // =====================================
        // SEARCH FILTER
        // =====================================
        if (searchTerm) {
            var lowerSearch_1 = searchTerm.toLowerCase();
            data = data.filter(function (item) {
                return Object.values({
                    requestNo: item.ForexNumber,
                    employee: item.EmployeeName,
                    vendor: item.VendorName,
                    status: item.Status,
                    location: item.Location,
                    amount: item.TotalAmount,
                    //status: item.Status,
                    requestDate: formatDate(item.RequestedOn),
                    forexType: item.ForexType
                })
                    .join(" ")
                    .toLowerCase()
                    .includes(lowerSearch_1);
            });
        }
        setFilteredData(data);
    }, [listData, searchTerm, statusFilter]);
    // =========================================
    // RESET PAGE ON FILTER CHANGE
    // =========================================
    (0, react_1.useEffect)(function () {
        setCurrentPage(1);
    }, [searchTerm, statusFilter]);
    // =========================================
    // PAGINATION LOGIC
    // =========================================
    var totalPages = Math.ceil(filteredData.length / itemsPerPage);
    var startIndex = (currentPage - 1) * itemsPerPage;
    var endIndex = startIndex + itemsPerPage;
    var paginatedData = filteredData.slice(startIndex, endIndex);
    return (React.createElement("div", { className: "approved-rejected-dashboard" },
        React.createElement("div", { className: "dashboard-header" },
            React.createElement("div", null,
                React.createElement("h2", null, "Forex Workflow Dashboard"),
                React.createElement("p", null, "Track approvals, rejections and workflow status"))),
        React.createElement("div", { className: "dashboard-cards" },
            React.createElement("div", { className: "dashboard-card total" },
                React.createElement("h3", null, "Total Requests"),
                React.createElement("h1", null, dashboardCounts.total)),
            React.createElement("div", { className: "dashboard-card approved" },
                React.createElement("h3", null, "Approved By Me"),
                React.createElement("h1", null, dashboardCounts.approvedByMe)),
            React.createElement("div", { className: "dashboard-card rejected" },
                React.createElement("h3", null, "Rejected By Me"),
                React.createElement("h1", null, dashboardCounts.rejectedByMe)),
            React.createElement("div", { className: "dashboard-card sentback" },
                React.createElement("h3", null, "Sent Back By Me"),
                React.createElement("h1", null, dashboardCounts.sentBackByMe))),
        React.createElement("div", { className: "filter-section" },
            React.createElement("input", { type: "text", placeholder: "Search request...", className: "form-control", value: searchTerm, onChange: function (e) { return setSearchTerm(e.target.value); } }),
            React.createElement("select", { className: "form-control", value: statusFilter, onChange: function (e) { return setStatusFilter(e.target.value); } },
                React.createElement("option", { value: "All" }, "All"),
                React.createElement("option", { value: "Pending" }, "Pending"),
                React.createElement("option", { value: "ApprovedByMe" }, "Approved By Me"),
                React.createElement("option", { value: "RejectedByMe" }, "Rejected By Me"),
                React.createElement("option", { value: "SentBackByMe" }, "Sent Back By Me"),
                React.createElement("option", { value: "Rejected" }, "Rejected"),
                React.createElement("option", { value: "Sent Back" }, "Sent Back"),
                React.createElement("option", { value: "Paid" }, "Paid"))),
        React.createElement("div", { className: "table-wrapper" },
            React.createElement("table", { className: "custom-table" },
                React.createElement("thead", null,
                    React.createElement("tr", null,
                        React.createElement("th", null, "Request No"),
                        React.createElement("th", null, "Type"),
                        React.createElement("th", null, "Employee"),
                        React.createElement("th", null, "Vendor"),
                        React.createElement("th", null, "Location"),
                        React.createElement("th", null, "Amount"),
                        React.createElement("th", null, "Status"),
                        React.createElement("th", null, "Date"),
                        React.createElement("th", null, "Action"))),
                React.createElement("tbody", null, loading ? (React.createElement("tr", null,
                    React.createElement("td", { colSpan: 10 }, "Loading..."))) : paginatedData.length === 0 ? (React.createElement("tr", null,
                    React.createElement("td", { colSpan: 10 }, "No Records Found"))) : (paginatedData.map(function (item) {
                    var _a;
                    return (React.createElement("tr", { key: item.ID },
                        React.createElement("td", null, item.ForexNumber),
                        React.createElement("td", null, item.ForexType),
                        React.createElement("td", null, item.EmployeeName),
                        React.createElement("td", null, item.VendorName),
                        React.createElement("td", null, item.Location),
                        React.createElement("td", null,
                            "\u20B9 ",
                            item.TotalAmount),
                        React.createElement("td", null,
                            React.createElement("span", { className: "status-badge ".concat((_a = item.Status) === null || _a === void 0 ? void 0 : _a.replace(/\s/g, '-')) }, item.Status)),
                        React.createElement("td", null, formatDate(item.RequestedOn)),
                        React.createElement("td", null,
                            React.createElement(react_router_dom_1.Link, { to: "/ViewRequest/".concat(item.ID) }, "View"))));
                })))),
            !loading && totalPages > 1 && (React.createElement("div", { className: "pagination-wrapper" },
                React.createElement("button", { className: "page-btn", disabled: currentPage === 1, onClick: function () { return setCurrentPage(function (prev) { return prev - 1; }); } }, "Previous"),
                tslib_1.__spreadArray([], Array(totalPages), true).map(function (_, index) { return (React.createElement("button", { key: index, className: "page-number ".concat(currentPage === index + 1 ? "active-page" : ""), onClick: function () { return setCurrentPage(index + 1); } }, index + 1)); }),
                React.createElement("button", { className: "page-btn", disabled: currentPage === totalPages, onClick: function () { return setCurrentPage(function (prev) { return prev + 1; }); } }, "Next")))),
        React.createElement("a", { onClick: function () { return history.push("/"); }, className: "exit-btn" }, "Exit")));
};
exports.default = ModernForexDashboard;
//# sourceMappingURL=ApprovedRejectByme.js.map