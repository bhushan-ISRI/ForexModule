"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.APTeamLP = void 0;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var react_router_dom_1 = require("react-router-dom");
require("../../components/Pages/Css/InitiatorDashboard.scss");
var spcrud_1 = tslib_1.__importDefault(require("../../service/BAL/spcrud"));
var LeftArrow_png_1 = tslib_1.__importDefault(require("../../assets/LeftArrow.png"));
var RightArrow_png_1 = tslib_1.__importDefault(require("../../assets/RightArrow.png"));
var Eye_png_1 = tslib_1.__importDefault(require("../../assets/Eye.png"));
var Pencil_png_1 = tslib_1.__importDefault(require("../../assets/Pencil.png"));
var Renew_png_1 = tslib_1.__importDefault(require("../../assets/Renew.png"));
var APTeamLP = function (props) {
    var _a = (0, react_1.useState)(""), searchTerm = _a[0], setSearchTerm = _a[1];
    var _b = (0, react_1.useState)("All"), statusFilter = _b[0], setStatusFilter = _b[1];
    var _c = (0, react_1.useState)([]), listData = _c[0], setListData = _c[1];
    var _d = (0, react_1.useState)([]), filteredData = _d[0], setFilteredData = _d[1];
    var _e = (0, react_1.useState)(true), loading = _e[0], setLoading = _e[1];
    // Pagination
    var itemsPerPage = 10;
    var _f = (0, react_1.useState)(1), currentPage = _f[0], setCurrentPage = _f[1];
    var history = (0, react_router_dom_1.useHistory)();
    var formatDate = function (dateString) {
        if (!dateString)
            return "";
        var date = new Date(dateString);
        return date
            .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
        })
            .replace(/\//g, "-");
    };
    // 🔹 Fetch Data
    var GetListData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var spCrudOps, parentItems;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    setLoading(true);
                    return [4 /*yield*/, (0, spcrud_1.default)()];
                case 1:
                    spCrudOps = _a.sent();
                    return [4 /*yield*/, spCrudOps.getRootData("NDADetail", "ID,ReqtNo,RequestorName,RequestorEmail,RequestDate,VendorName,Amount,NDAStartDate,NDAExpiryDate,VendorContactName,VendorContactEmail,AdditionalNotes,Status,ServiceType/ID,ServiceType/Title,Author/ID", "ServiceType,Author", "AuthorId eq " + props.id, { column: "ID", isAscending: false }, 5000, props)];
                case 2:
                    parentItems = _a.sent();
                    setListData(parentItems);
                    setFilteredData(parentItems);
                    setLoading(false);
                    return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        GetListData();
    }, []);
    // 🔹 Search + Status Filter Combined
    (0, react_1.useEffect)(function () {
        var data = tslib_1.__spreadArray([], listData, true);
        if (statusFilter !== "All") {
            data = data.filter(function (item) { return item.Status === statusFilter; });
        }
        if (searchTerm) {
            var lowerSearch_1 = searchTerm.toLowerCase();
            data = data.filter(function (item) {
                var _a;
                return Object.values({
                    requestNo: item.ReqtNo,
                    requestDate: formatDate(item.RequestDate),
                    vendorName: item.VendorName,
                    contactPerson: item.VendorContactName,
                    serviceType: (_a = item.ServiceType) === null || _a === void 0 ? void 0 : _a.Title,
                    status: item.Status,
                    amount: item.Amount,
                })
                    .join(" ")
                    .toLowerCase()
                    .includes(lowerSearch_1);
            });
        }
        setFilteredData(data);
        setCurrentPage(1);
    }, [searchTerm, statusFilter, listData]);
    // 🔹 Pagination
    var totalPages = Math.ceil(filteredData.length / itemsPerPage);
    var handlePageChange = function (page) {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    var sortedData = tslib_1.__spreadArray([], filteredData, true).sort(function (a, b) { return b.ID - a.ID; });
    var paginatedData = sortedData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
    return (React.createElement("div", { className: "dashboard-wrapper" },
        React.createElement("div", { className: "header" },
            React.createElement("div", { className: "left-banner" },
                React.createElement("div", { className: "logo-text" },
                    React.createElement("h2", null, "Fixed Asset Disposal Advice - AP Team Dashboard")))),
        React.createElement("div", { className: "filter-section" },
            React.createElement("div", { className: "filter-left" },
                React.createElement("input", { type: "text", placeholder: "Search...", className: "form-control", value: searchTerm, onChange: function (e) { return setSearchTerm(e.target.value); } }),
                React.createElement("select", { className: "form-control", value: statusFilter, onChange: function (e) { return setStatusFilter(e.target.value); } },
                    React.createElement("option", { value: "All" }, "All Status"),
                    React.createElement("option", { value: "Draft" }, "Draft"),
                    React.createElement("option", { value: "Submitted" }, "Submitted"),
                    React.createElement("option", { value: "Approved" }, "Approved"),
                    React.createElement("option", { value: "Send back" }, "Send back"),
                    React.createElement("option", { value: "Rejected" }, "Rejected")))),
        React.createElement("div", { className: "table-section" },
            React.createElement("div", { className: "table-vert-scroll" },
                React.createElement("table", { className: "custom-table" },
                    React.createElement("thead", null,
                        React.createElement("tr", null,
                            React.createElement("th", null, "Request No."),
                            React.createElement("th", null, "Employee Name"),
                            React.createElement("th", null, "Request Date"),
                            React.createElement("th", null, "Service Type"),
                            React.createElement("th", null, "Vendor Name"),
                            React.createElement("th", null, "Amount"),
                            React.createElement("th", null, "Status"),
                            React.createElement("th", null, "Action"))),
                    React.createElement("tbody", null, loading ? (React.createElement("tr", null,
                        React.createElement("td", { colSpan: 8, className: "text-center" }, "Loading data..."))) : paginatedData.length === 0 ? (React.createElement("tr", null,
                        React.createElement("td", { colSpan: 8, className: "text-center" }, "No records found"))) : (paginatedData.map(function (item) {
                        var _a, _b;
                        return (React.createElement("tr", { key: item.ID },
                            React.createElement("td", null, item.ReqtNo),
                            React.createElement("td", null, item.RequestorName),
                            React.createElement("td", null, formatDate(item.RequestDate)),
                            React.createElement("td", null, (_a = item.ServiceType) === null || _a === void 0 ? void 0 : _a.Title),
                            React.createElement("td", null, item.VendorName),
                            React.createElement("td", null,
                                "\u20B9 ",
                                item.Amount || "-"),
                            React.createElement("td", null,
                                React.createElement("span", { className: "status-badge ".concat((_b = item.Status) === null || _b === void 0 ? void 0 : _b.replace(" ", "-")) }, item.Status)),
                            React.createElement("td", null, item.Status === "Send back" ||
                                item.Status === "Draft" ? (React.createElement(react_router_dom_1.Link, { to: "/NDAEditform/".concat(item.ID) },
                                React.createElement("img", { src: Pencil_png_1.default, width: 16, alt: "Edit" }))) : (React.createElement(React.Fragment, null,
                                React.createElement(react_router_dom_1.Link, { to: "/NDAViewmore/".concat(item.ID) },
                                    React.createElement("img", { src: Eye_png_1.default, width: 16, alt: "View" })),
                                item.Status === "Approved" && (React.createElement(react_router_dom_1.Link, { to: "/RenewalForm/".concat(item.ID), style: { marginLeft: "10px" } },
                                    React.createElement("img", { src: Renew_png_1.default, width: 16, alt: "Renew" }))))))));
                    }))))),
            React.createElement("div", { className: "pagination" },
                React.createElement("button", { onClick: function () { return handlePageChange(currentPage - 1); }, disabled: currentPage === 1 },
                    React.createElement("img", { src: LeftArrow_png_1.default, width: 14 })),
                Array.from({ length: totalPages }, function (_, i) { return i + 1; })
                    .filter(function (page) { return Math.abs(page - currentPage) <= 2; })
                    .map(function (page) { return (React.createElement("button", { key: page, onClick: function () { return handlePageChange(page); }, className: currentPage === page ? "active" : "" }, page)); }),
                React.createElement("button", { onClick: function () { return handlePageChange(currentPage + 1); }, disabled: currentPage === totalPages },
                    React.createElement("img", { src: RightArrow_png_1.default, width: 14 }))))));
};
exports.APTeamLP = APTeamLP;
exports.default = exports.APTeamLP;
//# sourceMappingURL=APTeamLandingPage.js.map