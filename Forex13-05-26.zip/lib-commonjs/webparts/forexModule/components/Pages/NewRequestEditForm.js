"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
require("../Pages/Css/NewRequest.scss");
var react_router_dom_1 = require("react-router-dom");
var react_2 = require("@fluentui/react");
var spcrud_1 = tslib_1.__importDefault(require("../../service/BAL/spcrud"));
var react_router_dom_2 = require("react-router-dom");
var all_1 = require("@pnp/sp/presets/all");
//import USESPCRUD from "../../service/BAL/spcrud";
var sp_http_1 = require("@microsoft/sp-http");
/* Helper Components */
var Section = function (_a) {
    var title = _a.title, children = _a.children;
    return (react_1.default.createElement("div", { className: "form-section" },
        react_1.default.createElement("h3", null, title),
        children));
};
var Grid = function (_a) {
    var children = _a.children;
    return (react_1.default.createElement("div", { className: "form-grid" }, children));
};
var Field = function (_a) {
    var label = _a.label, children = _a.children, full = _a.full, required = _a.required;
    return (react_1.default.createElement("div", { className: full ? "form-field full" : "form-field" },
        react_1.default.createElement("label", null,
            label,
            required && react_1.default.createElement("span", { className: "required-star" }, "*")),
        children));
};
var Editrequest = function (props) {
    var Id = (0, react_router_dom_2.useParams)().Id;
    var history = (0, react_router_dom_1.useHistory)();
    var spCrudOps = (0, spcrud_1.default)();
    var _a = (0, react_1.useState)("Goods-Bill Payment"), paymentType = _a[0], setPaymentType = _a[1];
    var _b = (0, react_1.useState)("Yes"), taxDocumentView = _b[0], setTaxDocumentView = _b[1];
    var _c = (0, react_1.useState)(), paymenttypeDropdownValue = _c[0], setPaymentTypeDropdownValue = _c[1];
    var _d = (0, react_1.useState)(""), fromdate = _d[0], setFromDate = _d[1];
    var _e = (0, react_1.useState)(""), todate = _e[0], setToDate = _e[1];
    var _f = (0, react_1.useState)(""), dTAAApplicable = _f[0], setDTAAApplicable = _f[1];
    var _g = react_1.default.useState(false), showVendorPopup = _g[0], setShowVendorPopup = _g[1];
    var _h = (0, react_1.useState)(""), bankaccountno = _h[0], setBankAccountNo = _h[1];
    var _j = (0, react_1.useState)(""), bankname = _j[0], setBankName = _j[1];
    var _k = (0, react_1.useState)(""), bankswiftcode = _k[0], setBankSwiftCode = _k[1];
    var _l = (0, react_1.useState)(""), remarks = _l[0], setRemarks = _l[1];
    var _m = (0, react_1.useState)(""), requestNumber = _m[0], setRequestNumber = _m[1];
    var _o = (0, react_1.useState)(""), requestedOn = _o[0], setRequestedOn = _o[1];
    var _p = (0, react_1.useState)(""), currency = _p[0], setCurrency = _p[1];
    var _q = (0, react_1.useState)([]), currencyOptions = _q[0], setCurrencyOptions = _q[1];
    var _r = (0, react_1.useState)(""), totalAmount = _r[0], setTotalAmount = _r[1];
    var _s = (0, react_1.useState)(""), foreignBankCharges = _s[0], setForeignBankCharges = _s[1];
    var _t = (0, react_1.useState)(""), poContractNo = _t[0], setPoContractNo = _t[1];
    var _u = (0, react_1.useState)(""), poDate = _u[0], setPoDate = _u[1];
    var _v = (0, react_1.useState)(""), expectedSettlementDate = _v[0], setExpectedSettlementDate = _v[1];
    var _w = (0, react_1.useState)(""), eligibleAmountWithWHT = _w[0], setEligibleAmountWithWHT = _w[1];
    var _x = (0, react_1.useState)(""), paidAmount = _x[0], setPaidAmount = _x[1];
    var _y = (0, react_1.useState)(""), ballenceEligibleAmount = _y[0], setBallenceEligibleAmount = _y[1];
    var _z = (0, react_1.useState)([]), approvers = _z[0], setApprovers = _z[1];
    //const [approverDetails, setApproverDetails] = useState<any[]>([]);
    var _0 = (0, react_1.useState)([]), approverDetails = _0[0], setApproverDetails = _0[1];
    var _1 = react_1.default.useState({
        EmployeeCode: "",
        EmployeeName: "",
        Division: "",
        Location: "",
        RM: "",
        HOD: "",
        ContactNo: "",
        EmployeeStatus: "",
        Email: "",
        RMId: 0,
        HODId: 0
    }), employee = _1[0], setEmployee = _1[1];
    var _2 = react_1.default.useState({
        VendorCode: "",
        VendorName: "",
        VendorNameLegal: "",
        VendorShortName: "",
        VendorType: "",
        City: "",
        State: "",
        Country: "",
        Currency: "",
        PostalCode: "",
        ContactPersonName: "",
        EmailId: "",
        PhoneNumber: "",
        AlternateContact: "",
        BeneficiaryName: "",
        BankName: "",
        AccountNumberIBAN: "",
        SWIFTBICCode: "",
        RoutingNumberABA: "",
        IFSCCode: "",
        IntermediaryBank: "",
        IntermediarySWIFTCode: "",
        NatureOfPayment: "",
        PurposeCodeRBI: "",
        BankCountry: "",
        BankAddress: "",
        VendorAddress: ""
    }), vendor = _2[0], setVendor = _2[1];
    var _3 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        SEPClause: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), permanentEstablishmentDeclaration = _3[0], setPermanentEstablishmentDeclaration = _3[1];
    var _4 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        TaxIdentificationNumber: "",
        CountryOfTaxResidence: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), taxResidencyCertificate = _4[0], setTaxResidencyCertificate = _4[1];
    var _5 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        AcknowledgmentNumber: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), form10F = _5[0], setForm10F = _5[1];
    var _6 = react_1.default.useState([
        {
            invoiceNo: "",
            invoiceDate: "",
            boeNo: "",
            boeDate: "",
            mrnNo: "",
            blNo: "",
            blDate: "",
            invoiceAmount: "",
            mrnDate: "",
            attachments: []
        }
    ]), rows = _6[0], setRows = _6[1];
    var _7 = (0, react_1.useState)({}), poFiles = _7[0], setPoFiles = _7[1];
    var _8 = (0, react_1.useState)({}), piFiles = _8[0], setPiFiles = _8[1];
    //const [otherFiles, setOtherFiles] = useState<any>({});
    var _9 = (0, react_1.useState)([]), wfHistory = _9[0], setWfHistory = _9[1];
    var _10 = (0, react_1.useState)(null), currentApproverId = _10[0], setCurrentApproverId = _10[1];
    var _11 = (0, react_1.useState)({}), invoiceFiles = _11[0], setInvoiceFiles = _11[1];
    var _12 = (0, react_1.useState)({}), otherFiles = _12[0], setOtherFiles = _12[1];
    var _13 = (0, react_1.useState)({}), otherFilesAdv = _13[0], setOtherFilesAdv = _13[1];
    var _14 = (0, react_1.useState)({}), boeFiles = _14[0], setBoeFiles = _14[1];
    var _15 = (0, react_1.useState)({}), blFiles = _15[0], setBlFiles = _15[1];
    var _16 = (0, react_1.useState)([]), boeLibraryFiles = _16[0], setBoeLibraryFiles = _16[1];
    var _17 = (0, react_1.useState)([]), bolLibraryFiles = _17[0], setBolLibraryFiles = _17[1];
    var _18 = (0, react_1.useState)(false), isSubmitting = _18[0], setIsSubmitting = _18[1];
    var _19 = (0, react_1.useState)([]), vendorOptions = _19[0], setVendorOptions = _19[1];
    var addRow = function () {
        setRows(tslib_1.__spreadArray(tslib_1.__spreadArray([], rows, true), [
            {
                invoiceNo: "",
                invoiceDate: "",
                boeNo: "",
                boeDate: "",
                mrnNo: "",
                blNo: "",
                blDate: "",
                invoiceAmount: "",
                mrnDate: "",
                attachments: []
            }
        ], false));
    };
    var deleteRow = function (index) {
        var updatedRows = rows.filter(function (_, i) { return i !== index; });
        setRows(updatedRows);
    };
    var handleChange = function (index, field, value) {
        var _a;
        var updatedRows = tslib_1.__spreadArray([], rows, true);
        // updatedRows[index][field] = value as any;
        updatedRows[index] = tslib_1.__assign(tslib_1.__assign({}, updatedRows[index]), (_a = {}, _a[field] = value, _a));
        setRows(updatedRows);
    };
    var totalInvoiceAmount = rows.reduce(function (sum, row) {
        return sum + (parseFloat(row.invoiceAmount) || 0);
    }, 0);
    var uniqueBoeNumbers = rows
        .map(function (r) { return r.boeNo; })
        .filter(function (value, index, self) {
        return value && self.indexOf(value) === index;
    });
    var uniqueBlNumbers = rows
        .map(function (r) { return r.blNo; })
        .filter(function (value, index, self) {
        return value && self.indexOf(value) === index;
    });
    (0, react_1.useEffect)(function () {
        loadVendorOptions();
        getuserData();
        getFinancialYearStart();
        getCurrencyData();
        getApproversdata();
        if (Id) {
            loadForexData(Id);
        }
    }, [Id]);
    var loadVendorOptions = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, vendors, options, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, sp.getData("VendorMaster", "ID,VendorCode,VendorName", "", "", { column: "VendorCode", isAscending: true }, 5000, props)];
                case 3:
                    vendors = _a.sent();
                    options = vendors.map(function (v) { return ({
                        key: v.VendorCode,
                        text: "".concat(v.VendorCode)
                    }); });
                    setVendorOptions(options);
                    return [3 /*break*/, 5];
                case 4:
                    error_1 = _a.sent();
                    console.error("Error loading vendors:", error_1);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var getCurrencyData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp_1, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    sp_1 = _a.sent();
                    return [4 /*yield*/, sp_1.getData("Currency", "Title,Id", "", "", { column: "Title", isAscending: true }, 5000, props).then(function (res) {
                            var options = res.map(function (c) { return ({
                                key: c.Id,
                                text: c.Title
                            }); });
                            setCurrencyOptions(options);
                        })];
                case 2:
                    _a.sent();
                    return [3 /*break*/, 4];
                case 3:
                    error_2 = _a.sent();
                    console.error("Error fetching currency data:", error_2);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    //----------------------- load data for edit------------------------//
    all_1.sp.setup({
        spfxContext: props.context
    });
    var loadForexData = function (forexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, parent_1, data, history_1, child, webUrl_1, childWithAttachments, formattedRows, boeFiles_1, bolFiles, error_3;
        var _a, _b, _c, _d;
        return tslib_1.__generator(this, function (_e) {
            switch (_e.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _e.sent();
                    _e.label = 2;
                case 2:
                    _e.trys.push([2, 8, , 9]);
                    return [4 /*yield*/, sp.getData("ForexRequest", "*,Currency/Title,Currency/Id", "Currency", "ID eq ".concat(forexId), { column: "ID", isAscending: true }, 1, props)];
                case 3:
                    parent_1 = _e.sent();
                    if (parent_1.length > 0) {
                        data = parent_1[0];
                        setPaymentType(data.ForexType || "");
                        setRequestNumber(data.ForexNumber || "");
                        setRequestedOn(((_a = data.RequestedOn) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "");
                        setCurrency(((_b = data.Currency) === null || _b === void 0 ? void 0 : _b.Id) || "");
                        setTotalAmount(data.TotalAmount || "");
                        setForeignBankCharges(data.ForeignBankCharges || "");
                        setPoContractNo(data.poContractNo || "");
                        setPoDate(((_c = data.poDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "");
                        setExpectedSettlementDate(((_d = data.expectedSettlementDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "");
                        setBankName(data.BankName || "");
                        setBankAccountNo(data.BankAccNo || "");
                        setRemarks(data.Remarks || "");
                        setDTAAApplicable(data.DTAAApplicable || "");
                        setTaxDocumentView(data.DocumentIsAvailable || "");
                        setBankSwiftCode(data.BankSwiftCode || "");
                        setEligibleAmountWithWHT(data.EligibleAmountWithWHT || "");
                        setPaidAmount(data.PaidAmount || "");
                        setBallenceEligibleAmount(data.BallenceEligibleAmount || "");
                        setVendor(tslib_1.__assign(tslib_1.__assign({}, vendor), { VendorCode: data.VendorCode, VendorName: data.VendorName }));
                        getVendorData(data.VendorCode);
                        try {
                            history_1 = [];
                            if (data.WorkFlowHistory) {
                                history_1 =
                                    typeof data.WorkFlowHistory === "string"
                                        ? JSON.parse(data.WorkFlowHistory)
                                        : data.WorkFlowHistory;
                            }
                            setWfHistory(history_1 || []);
                            console.log("🔥 WFHistory:", history_1);
                        }
                        catch (e) {
                            console.error("WFHistory error", e);
                        }
                    }
                    return [4 /*yield*/, sp.getData("ForexServicesBillPayment", "*", "", "ForexIDId eq ".concat(forexId), { column: "ID", isAscending: true }, 5000, props)];
                case 4:
                    child = _e.sent();
                    webUrl_1 = props.context.pageContext.web.absoluteUrl;
                    return [4 /*yield*/, Promise.all(child.map(function (item) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
                            var url, response, data, e_1;
                            var _a;
                            return tslib_1.__generator(this, function (_b) {
                                switch (_b.label) {
                                    case 0:
                                        _b.trys.push([0, 3, , 4]);
                                        url = "".concat(webUrl_1, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(item.ID, ")/AttachmentFiles");
                                        return [4 /*yield*/, props.context.spHttpClient.get(url, sp_http_1.SPHttpClient.configurations.v1)];
                                    case 1:
                                        response = _b.sent();
                                        return [4 /*yield*/, response.json()];
                                    case 2:
                                        data = _b.sent();
                                        return [2 /*return*/, tslib_1.__assign(tslib_1.__assign({}, item), { attachments: data.value || ((_a = data.d) === null || _a === void 0 ? void 0 : _a.results) || [] })];
                                    case 3:
                                        e_1 = _b.sent();
                                        console.error("❌ Attachment error for item:", item.ID, e_1);
                                        return [2 /*return*/, tslib_1.__assign(tslib_1.__assign({}, item), { attachments: [] })];
                                    case 4: return [2 /*return*/];
                                }
                            });
                        }); }))];
                case 5:
                    childWithAttachments = _e.sent();
                    if (child.length > 0) {
                        formattedRows = childWithAttachments.map(function (item) {
                            var _a, _b, _c, _d;
                            return ({
                                id: item.ID,
                                invoiceNo: item.InvoiceNumber || "",
                                invoiceDate: ((_a = item.InvoiceDate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "",
                                invoiceAmount: item.InvoiceAmount || "",
                                mrnNo: item.MRNNumber || "",
                                mrnDate: ((_b = item.MRNDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                blNo: item.BillofLandingNo || "",
                                blDate: ((_c = item.BillOfLandingdate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                boeNo: item.BOENo || "",
                                boeDate: ((_d = item.BOEDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "",
                                attachments: item.attachments || []
                            });
                        });
                        setRows(formattedRows);
                    }
                    return [4 /*yield*/, sp.getData("BOEAttachments", "FileLeafRef,FileRef,BOENo,ReqeuestId", "", "ReqeuestId eq '".concat(forexId, "'"), { column: "ID", isAscending: true }, 5000, props)];
                case 6:
                    boeFiles_1 = _e.sent();
                    return [4 /*yield*/, sp.getData("BillOfLandingAttachment", "FileLeafRef,FileRef,BOLNo,ReqeuestId", "", "ReqeuestId eq '".concat(forexId, "'"), { column: "ID", isAscending: true }, 5000, props)];
                case 7:
                    bolFiles = _e.sent();
                    setBoeLibraryFiles(boeFiles_1);
                    setBolLibraryFiles(bolFiles);
                    return [3 /*break*/, 9];
                case 8:
                    error_3 = _e.sent();
                    console.error("Error loading edit data:", error_3);
                    return [3 /*break*/, 9];
                case 9: return [2 /*return*/];
            }
        });
    }); };
    var buildApprovalFlow = function (employeeData, selectedType) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp_2, baseApprovers_1, requestTypeFilter, matrixData, matrixApprovers, fullFlow, uniqueFlow, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    sp_2 = _a.sent();
                    baseApprovers_1 = [];
                    if (employeeData.RMId) {
                        baseApprovers_1.push({
                            Id: employeeData.RMId,
                            Name: employeeData.RM,
                            Role: "RM",
                            Level: 1
                        });
                    }
                    if (employeeData.HODId) {
                        baseApprovers_1.push({
                            Id: employeeData.HODId,
                            Name: employeeData.HOD,
                            Role: "HOD",
                            Level: 2
                        });
                    }
                    requestTypeFilter = selectedType.includes("Advance")
                        ? "Advance Payment"
                        : selectedType;
                    return [4 /*yield*/, sp_2.getData("ForexApprovalMatrix", "Title,Role,Approver/Id,Approver/Title,Level,RequestType", "Approver", "RequestType eq '".concat(requestTypeFilter, "' and Status eq 'Active'"), { column: "Level", isAscending: true }, 5000, props)];
                case 2:
                    matrixData = _a.sent();
                    matrixApprovers = matrixData.map(function (item, index) {
                        var _a, _b;
                        return ({
                            Id: (_a = item.Approver) === null || _a === void 0 ? void 0 : _a.Id,
                            Name: (_b = item.Approver) === null || _b === void 0 ? void 0 : _b.Title,
                            Role: item.Role,
                            Level: baseApprovers_1.length + index + 1
                        });
                    });
                    fullFlow = tslib_1.__spreadArray(tslib_1.__spreadArray([], baseApprovers_1, true), matrixApprovers, true);
                    uniqueFlow = fullFlow.filter(function (v, i, self) { return self.findIndex(function (x) { return x.Id === v.Id; }) === i; });
                    // ✅ UI
                    setApproverDetails(uniqueFlow);
                    setApprovers(uniqueFlow.map(function (a) { return a.Id; }));
                    // ✅ RETURN (IMPORTANT)
                    return [2 /*return*/, uniqueFlow];
                case 3:
                    error_4 = _a.sent();
                    console.error("Error building approval flow:", error_4);
                    return [2 /*return*/, []];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    //=----------------------- userdata------------------------//
    var getuserData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    (_a.sent()).getData("EmployeeMaster", "EmployeeCode,EmployeeName,Division,Location,RM/EMail,RM/Id,HOD/EMail,HOD/Id,RM/Title,HOD/Title,ContactNo,EmployeeStatus,Email,Employee/Id,Employee/Title", "RM,HOD,Employee", "EmployeeId eq '".concat(props.context.pageContext.legacyPageContext.userId, "'"), { column: "ID", isAscending: true }, 1, props)
                        .then(function (res) {
                        var _a, _b, _c, _d, _e, _f, _g, _h;
                        if (res.length > 0) {
                            var userData = res[0];
                            setEmployee({
                                EmployeeCode: userData.EmployeeCode || "",
                                EmployeeName: userData.EmployeeName || "",
                                Division: userData.Division || "",
                                Location: userData.Location || "",
                                RM: ((_a = userData.RM) === null || _a === void 0 ? void 0 : _a.Title) || "",
                                HOD: ((_b = userData.HOD) === null || _b === void 0 ? void 0 : _b.Title) || "",
                                ContactNo: userData.ContactNo || "",
                                EmployeeStatus: userData.EmployeeStatus || "",
                                Email: userData.Email || "",
                                RMId: ((_c = userData.RM) === null || _c === void 0 ? void 0 : _c.Id) || 0,
                                HODId: ((_d = userData.HOD) === null || _d === void 0 ? void 0 : _d.Id) || 0
                            });
                            buildApprovalFlow({
                                RMId: (_e = userData.RM) === null || _e === void 0 ? void 0 : _e.Id,
                                HODId: (_f = userData.HOD) === null || _f === void 0 ? void 0 : _f.Id,
                                RM: (_g = userData.RM) === null || _g === void 0 ? void 0 : _g.Title,
                                HOD: (_h = userData.HOD) === null || _h === void 0 ? void 0 : _h.Title
                            }, paymentType);
                        }
                        else {
                            console.log("No user data found for the current email.");
                        }
                    })
                        .catch(function (error) {
                        console.error("Error fetching user data:", error);
                    });
                    return [2 /*return*/];
            }
        });
    }); };
    //----------------------VendorData-------------------------//
    var getVendorData = function (vendorCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!vendorCode)
                        return [2 /*return*/];
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    (_a.sent()).getData("VendorMaster", "VendorCode,VendorName,VendorNameLegal,VendorShortName,VendorType,City/Title,State/Title,Country/Title,Currency/Title,PostalCode,ContactPersonName,EmailId,PhoneNumber,AlternateContact,BeneficiaryName,BankName,AccountNumberIBAN,SWIFTBICCode,RoutingNumberABA,IFSCCode,IntermediaryBank,IntermediarySWIFTCode,NatureOfPayment/Title,PurposeCodeRBI,BankCountry,BankAddress,VendorAddress", "NatureOfPayment,City,State,Country,Currency", "VendorCode eq '".concat(vendorCode, "'"), { column: "ID", isAscending: true }, 1, props)
                        .then(function (res) {
                        var _a, _b, _c, _d, _e;
                        if (res.length > 0) {
                            var v = res[0];
                            setVendor({
                                VendorCode: v.VendorCode || "",
                                VendorName: v.VendorName || "",
                                VendorNameLegal: v.VendorNameLegal || "",
                                VendorShortName: v.VendorShortName || "",
                                VendorType: v.VendorType || "",
                                City: ((_a = v.City) === null || _a === void 0 ? void 0 : _a.Title) || "",
                                State: ((_b = v.State) === null || _b === void 0 ? void 0 : _b.Title) || "",
                                Country: ((_c = v.Country) === null || _c === void 0 ? void 0 : _c.Title) || "",
                                Currency: ((_d = v.Currency) === null || _d === void 0 ? void 0 : _d.Title) || "",
                                PostalCode: v.PostalCode || "",
                                ContactPersonName: v.ContactPersonName || "",
                                EmailId: v.EmailId || "",
                                PhoneNumber: v.PhoneNumber || "",
                                AlternateContact: v.AlternateContact || "",
                                BeneficiaryName: v.BeneficiaryName || "",
                                BankName: v.BankName || "",
                                AccountNumberIBAN: v.AccountNumberIBAN || "",
                                SWIFTBICCode: v.SWIFTBICCode || "",
                                RoutingNumberABA: v.RoutingNumberABA || "",
                                IFSCCode: v.IFSCCode || "",
                                IntermediaryBank: v.IntermediaryBank || "",
                                IntermediarySWIFTCode: v.IntermediarySWIFTCode || "",
                                NatureOfPayment: ((_e = v.NatureOfPayment) === null || _e === void 0 ? void 0 : _e.Title) || "",
                                PurposeCodeRBI: v.PurposeCodeRBI || "",
                                BankAddress: v.BankAddress || "",
                                BankCountry: v.BankCountry || "",
                                VendorAddress: v.VendorAddress || ""
                            });
                            getTaxDeclarationdata(v.VendorCode);
                        }
                        else {
                            //alert("Vendor not found");
                            setShowVendorPopup(true);
                        }
                    })
                        .catch(function (error) {
                        console.error("Error fetching vendor data:", error);
                    });
                    return [2 /*return*/];
            }
        });
    }); };
    var getTaxDeclarationdata = function (vendorCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!vendorCode)
                        return [2 /*return*/];
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    (_a.sent()).getData("VendorTaxDeclaration", "VendorMasterId/ID,VendorCode/VendorCode,VendorName/VendorName,DeclarationType,DocumentAvailable,DocumentNumber,DocumentDate,SEPClause,ValidityStartDate,ValidityEndDate,TaxIdentificationNumber,CountryOfTaxResidence,AcknowledgmentNumber,AttachmentFiles/FileName,AttachmentFiles/ServerRelativeUrl", "VendorMasterId,VendorCode,VendorName,AttachmentFiles", "VendorCode/VendorCode eq '".concat(vendorCode, "'"), { column: "ID", isAscending: true }, 5000, props)
                        .then(function (res) {
                        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z;
                        var dates = [];
                        var permanent = res.find(function (item) { return item.DeclarationType === "Permanent Establishment"; });
                        if (permanent) {
                            var endDate = (_a = permanent.ValidityEndDate) === null || _a === void 0 ? void 0 : _a.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setPermanentEstablishmentDeclaration({
                                DocumentAvailable: permanent.DocumentAvailable || "",
                                DocumentNumber: permanent.DocumentNumber || "",
                                DocumentDate: ((_b = permanent.DocumentDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                SEPClause: permanent.SEPClause || "",
                                ValidityStartDate: ((_c = permanent.ValidityStartDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                ValidityEndDate: ((_d = permanent.ValidityEndDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "",
                                Attachmenturl: ((_f = (_e = permanent.AttachmentFiles) === null || _e === void 0 ? void 0 : _e[0]) === null || _f === void 0 ? void 0 : _f.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_h = (_g = permanent.AttachmentFiles) === null || _g === void 0 ? void 0 : _g[0]) === null || _h === void 0 ? void 0 : _h.FileName) || ""
                            });
                        }
                        else {
                            setPermanentEstablishmentDeclaration({
                                DocumentAvailable: "",
                                DocumentNumber: "",
                                DocumentDate: "",
                                SEPClause: "",
                                ValidityStartDate: "",
                                ValidityEndDate: "",
                                Attachmenturl: "",
                                Attachmentfilename: ""
                            });
                        }
                        var taxRes = res.find(function (item) { return item.DeclarationType === "TAX Residency Certificate"; });
                        if (taxRes) {
                            var endDate = (_j = permanent.ValidityEndDate) === null || _j === void 0 ? void 0 : _j.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setTaxResidencyCertificate({
                                DocumentAvailable: taxRes.DocumentAvailable || "",
                                DocumentNumber: taxRes.DocumentNumber || "",
                                DocumentDate: ((_k = taxRes.DocumentDate) === null || _k === void 0 ? void 0 : _k.split("T")[0]) || "",
                                ValidityStartDate: ((_l = taxRes.ValidityStartDate) === null || _l === void 0 ? void 0 : _l.split("T")[0]) || "",
                                ValidityEndDate: ((_m = taxRes.ValidityEndDate) === null || _m === void 0 ? void 0 : _m.split("T")[0]) || "",
                                TaxIdentificationNumber: taxRes.TaxIdentificationNumber || "",
                                CountryOfTaxResidence: taxRes.CountryOfTaxResidence || "",
                                Attachmenturl: ((_p = (_o = taxRes.AttachmentFiles) === null || _o === void 0 ? void 0 : _o[0]) === null || _p === void 0 ? void 0 : _p.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_r = (_q = taxRes.AttachmentFiles) === null || _q === void 0 ? void 0 : _q[0]) === null || _r === void 0 ? void 0 : _r.FileName) || ""
                            });
                        }
                        else {
                            setTaxResidencyCertificate({
                                DocumentAvailable: "",
                                DocumentNumber: "",
                                DocumentDate: "",
                                ValidityStartDate: "",
                                ValidityEndDate: "",
                                TaxIdentificationNumber: "",
                                CountryOfTaxResidence: "",
                                Attachmenturl: "",
                                Attachmentfilename: ""
                            });
                        }
                        // ✅ Form 10F
                        var form10 = res.find(function (item) { return item.DeclarationType === "Form 10 F"; });
                        if (form10) {
                            var endDate = (_s = permanent.ValidityEndDate) === null || _s === void 0 ? void 0 : _s.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setForm10F({
                                DocumentAvailable: form10.DocumentAvailable || "",
                                DocumentNumber: form10.DocumentNumber || "",
                                DocumentDate: ((_t = form10.DocumentDate) === null || _t === void 0 ? void 0 : _t.split("T")[0]) || "",
                                ValidityStartDate: ((_u = form10.ValidityStartDate) === null || _u === void 0 ? void 0 : _u.split("T")[0]) || "",
                                ValidityEndDate: ((_v = form10.ValidityEndDate) === null || _v === void 0 ? void 0 : _v.split("T")[0]) || "",
                                AcknowledgmentNumber: form10.AcknowledgmentNumber || "",
                                Attachmenturl: ((_x = (_w = form10.AttachmentFiles) === null || _w === void 0 ? void 0 : _w[0]) === null || _x === void 0 ? void 0 : _x.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_z = (_y = form10.AttachmentFiles) === null || _y === void 0 ? void 0 : _y[0]) === null || _z === void 0 ? void 0 : _z.FileName) || ""
                            });
                        }
                        else {
                            setForm10F({
                                DocumentAvailable: "",
                                DocumentNumber: "",
                                DocumentDate: "",
                                ValidityStartDate: "",
                                ValidityEndDate: "",
                                AcknowledgmentNumber: "",
                                Attachmenturl: "",
                                Attachmentfilename: ""
                            });
                        }
                        if (dates.length > 0) {
                            var minDate = dates.sort()[0]; // YYYY-MM-DD format works for sorting
                            setToDate(minDate); // store in state
                        }
                    })
                        .catch(function (error) {
                        console.error("Error fetching tax declaration data:", error);
                    });
                    return [2 /*return*/];
            }
        });
    }); };
    var getFinancialYearStart = function () {
        var today = new Date();
        var year = today.getFullYear();
        var month = today.getMonth(); // 0 = Jan
        var fyStartYear = month < 3 ? year - 1 : year;
        setFromDate("".concat(fyStartYear, "-04-01"));
    };
    var getApproversdata = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, res, approverList;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    return [4 /*yield*/, sp.getData("ForexApprovalMAtrix", "ID,Approver/Id,Approver/Title,Level", "Approver", "", { column: "Level", isAscending: true }, 5000, props)];
                case 2:
                    res = _a.sent();
                    approverList = res.map(function (a) { return ({
                        Id: a.Approver.Id,
                        Name: a.Approver.Title,
                        Level: a.Level
                    }); });
                    setApproverDetails(approverList);
                    return [2 /*return*/];
            }
        });
    }); };
    var validateForm = function () {
        // ================= HEADER VALIDATION =================
        if (!requestedOn) {
            alert("Requested On is required");
            setIsSubmitting(false);
            return false;
        }
        if (!currency) {
            alert("Currency is required");
            setIsSubmitting(false);
            return false;
        }
        if (!foreignBankCharges) {
            alert("Foreign Bank Charges is required");
            setIsSubmitting(false);
            return false;
        }
        if (paymentType.includes("Advance Payment")) {
            if (!poContractNo) {
                alert("PO/Contract No is required");
                setIsSubmitting(false);
                return false;
            }
            if (!poDate) {
                alert("PO Date is required");
                setIsSubmitting(false);
                return false;
            }
            if (!expectedSettlementDate) {
                alert("Expected Settlement Date is required");
                setIsSubmitting(false);
                return false;
            }
            if (!requestedOn) {
                alert("Requested On is required");
                setIsSubmitting(false);
                return false;
            }
            if (!currency) {
                alert("Currency is required");
                setIsSubmitting(false);
                return false;
            }
            if (!foreignBankCharges) {
                alert("Foreign Bank Charges is required");
                setIsSubmitting(false);
                return false;
            }
        }
        // ================= ROW VALIDATION =================
        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            // COMMON
            if (!row.invoiceNo) {
                alert("Invoice No required in row ".concat(i + 1));
                setIsSubmitting(false);
                return false;
            }
            if (!row.invoiceDate) {
                alert("Invoice Date required in row ".concat(i + 1));
                setIsSubmitting(false);
                return false;
            }
            if (!row.invoiceAmount) {
                alert("Invoice Amount required in row ".concat(i + 1));
                setIsSubmitting(false);
                return false;
            }
            // ================= GOODS BILL =================
            if (paymentType === "Goods-Bill Payment") {
                if (!row.boeNo) {
                    alert("BOE No required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
                if (!row.boeDate) {
                    alert("BOE Date required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
                if (!row.blNo) {
                    alert("BL No required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
                if (!row.blDate) {
                    alert("BL Date required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
                // if (!invoiceFiles[i] || invoiceFiles[i].length === 0 || row.attachments.filter((f) => f.FileName.startsWith("INV_")).length === 0) {
                //     alert(`Invoice attachment required in row ${i + 1}`);
                //     return false;
                // }
                var hasNewFile = invoiceFiles[i] && invoiceFiles[i].length > 0;
                var hasExistingFile = row.attachments &&
                    row.attachments.some(function (f) { return f.FileName.startsWith("INV_"); });
                if (!hasNewFile && !hasExistingFile) {
                    alert("Invoice attachment required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
            }
            // ================= SERVICE BILL =================
            if (paymentType === "Service-Bill Payment") {
                if (!row.mrnNo) {
                    alert("MRN No required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
                if (!row.mrnDate) {
                    alert("MRN Date required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
                // if (!invoiceFiles[i] || invoiceFiles[i].length === 0 || row.attachments.filter((f) => f.FileName.startsWith("INV_")).length === 0) {
                //     alert(`Invoice attachment required in row ${i + 1}`);
                //     return false;
                // }
                var hasNewFile = invoiceFiles[i] && invoiceFiles[i].length > 0;
                var hasExistingFile = row.attachments &&
                    row.attachments.some(function (f) { return f.FileName.startsWith("INV_"); });
                if (!hasNewFile && !hasExistingFile) {
                    alert("Invoice attachment required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
            }
            // ================= ADVANCE =================
            if (paymentType === "Service-Advance Payment" ||
                paymentType === "Goods-Advance Payment") {
                var hasPOFiles = poFiles[i] && poFiles[i].length > 0;
                var hasPOAttachments = row.attachments &&
                    row.attachments.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PO_"); }).length > 0;
                if (!hasPOFiles && !hasPOAttachments) {
                    alert("PO attachment required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
                var hasPIFiles = piFiles[i] && piFiles[i].length > 0;
                var hasPIAttachments = row.attachments &&
                    row.attachments.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PI_"); }).length > 0;
                if (!hasPIFiles && !hasPIAttachments) {
                    alert("PI attachment required in row ".concat(i + 1));
                    setIsSubmitting(false);
                    return false;
                }
            }
        }
        // ================= UNIQUE BOE FILES =================
        // if (paymentType === "Goods-Bill Payment") {
        //     for (let boe of uniqueBoeNumbers) {
        //         if (!boeFiles[boe] || boeFiles[boe].length === 0 || boeLibraryFiles.filter(f => f.BOENo === boe).length === 0) {
        //             alert(`BOE document required for BOE No: ${boe}`);
        //             return false;
        //         }
        //     }
        //     for (let bl of uniqueBlNumbers) {
        //         if (!blFiles[bl] || blFiles[bl].length === 0 || bolLibraryFiles.filter(f => f.BOLNo === bl).length === 0) {
        //             alert(`BL document required for BL No: ${bl}`);
        //             return false;
        //         }
        //     }
        // }
        if (paymentType === "Goods-Bill Payment") {
            var _loop_1 = function (boe) {
                var hasNewBoeFile = boeFiles[boe] && boeFiles[boe].length > 0;
                var hasExistingBoeFile = boeLibraryFiles &&
                    boeLibraryFiles.some(function (f) { return f.BOENo === boe; });
                if (!hasNewBoeFile && !hasExistingBoeFile) {
                    alert("BOE document required for BOE No: ".concat(boe));
                    setIsSubmitting(false);
                    return { value: false };
                }
            };
            for (var _i = 0, uniqueBoeNumbers_1 = uniqueBoeNumbers; _i < uniqueBoeNumbers_1.length; _i++) {
                var boe = uniqueBoeNumbers_1[_i];
                var state_1 = _loop_1(boe);
                if (typeof state_1 === "object")
                    return state_1.value;
            }
            var _loop_2 = function (bl) {
                var hasNewBlFile = blFiles[bl] && blFiles[bl].length > 0;
                var hasExistingBlFile = bolLibraryFiles &&
                    bolLibraryFiles.some(function (f) { return f.BOLNo === bl; });
                if (!hasNewBlFile && !hasExistingBlFile) {
                    alert("BL document required for BL No: ".concat(bl));
                    setIsSubmitting(false);
                    return { value: false };
                }
            };
            for (var _a = 0, uniqueBlNumbers_1 = uniqueBlNumbers; _a < uniqueBlNumbers_1.length; _a++) {
                var bl = uniqueBlNumbers_1[_a];
                var state_2 = _loop_2(bl);
                if (typeof state_2 === "object")
                    return state_2.value;
            }
        }
        return true;
    };
    var uploadToLibrary = function (libraryName, fileName, file, metadata) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var webUrl, serverRelativeUrl, folderPath, uploadUrl, uploadOptions, uploadResponse, errorText, uploadResult, entityTypeResponse, entityTypeData, entityTypeName, itemUrl, updateOptions, updateResponse, errorText;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    webUrl = props.context.pageContext.web.absoluteUrl;
                    serverRelativeUrl = props.context.pageContext.web.serverRelativeUrl;
                    folderPath = "".concat(serverRelativeUrl, "/").concat(libraryName);
                    uploadUrl = "".concat(webUrl, "/_api/web/GetFolderByServerRelativeUrl('").concat(folderPath, "')/Files/add(url='").concat(fileName, "',overwrite=true)");
                    uploadOptions = {
                        body: file
                    };
                    return [4 /*yield*/, props.context.spHttpClient.post(uploadUrl, sp_http_1.SPHttpClient.configurations.v1, uploadOptions)];
                case 1:
                    uploadResponse = _a.sent();
                    if (!!uploadResponse.ok) return [3 /*break*/, 3];
                    return [4 /*yield*/, uploadResponse.text()];
                case 2:
                    errorText = _a.sent();
                    console.error("Upload error:", errorText);
                    throw new Error("File upload failed");
                case 3: return [4 /*yield*/, uploadResponse.json()];
                case 4:
                    uploadResult = _a.sent();
                    return [4 /*yield*/, props.context.spHttpClient.get("".concat(webUrl, "/_api/web/lists/getbytitle('").concat(libraryName, "')?$select=ListItemEntityTypeFullName"), sp_http_1.SPHttpClient.configurations.v1)];
                case 5:
                    entityTypeResponse = _a.sent();
                    return [4 /*yield*/, entityTypeResponse.json()];
                case 6:
                    entityTypeData = _a.sent();
                    entityTypeName = entityTypeData.ListItemEntityTypeFullName;
                    itemUrl = "".concat(webUrl, "/_api/web/GetFileByServerRelativeUrl('").concat(uploadResult.ServerRelativeUrl, "')/ListItemAllFields");
                    updateOptions = {
                        headers: {
                            "IF-MATCH": "*",
                            "X-HTTP-Method": "MERGE",
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(metadata)
                    };
                    return [4 /*yield*/, props.context.spHttpClient.post(itemUrl, sp_http_1.SPHttpClient.configurations.v1, updateOptions)];
                case 7:
                    updateResponse = _a.sent();
                    if (!!updateResponse.ok) return [3 /*break*/, 9];
                    return [4 /*yield*/, updateResponse.text()];
                case 8:
                    errorText = _a.sent();
                    console.error("Metadata update error:", errorText);
                    throw new Error("Metadata update failed");
                case 9: return [2 /*return*/];
            }
        });
    }); };
    var onsubmit = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp_3, prevHistory, currentUser, newEntry, flow, currentApprover, nextApprover, wfHistoryPayload, parentResponse, oldRows, requestId_1, error_5;
        var _a, _b, _c, _d;
        return tslib_1.__generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    if (isSubmitting)
                        return [2 /*return*/];
                    setIsSubmitting(true);
                    _e.label = 1;
                case 1:
                    _e.trys.push([1, 8, , 9]);
                    return [4 /*yield*/, spCrudOps];
                case 2:
                    sp_3 = _e.sent();
                    // 🔹 1️⃣ Validate Before Saving
                    if (!validateForm())
                        return [2 /*return*/];
                    if (rows.length === 0) {
                        alert("Please add at least one invoice row.");
                        setIsSubmitting(false);
                        return [2 /*return*/];
                    }
                    prevHistory = [];
                    try {
                        prevHistory =
                            typeof wfHistory === "string"
                                ? JSON.parse(wfHistory)
                                : wfHistory || [];
                    }
                    catch (_f) {
                        prevHistory = [];
                    }
                    currentUser = ((_c = (_b = (_a = props.context) === null || _a === void 0 ? void 0 : _a.pageContext) === null || _b === void 0 ? void 0 : _b.user) === null || _c === void 0 ? void 0 : _c.displayName) || "User";
                    newEntry = {
                        CurrentApprover: currentUser,
                        ActionTaken: "Request resubmitted",
                        Comment: remarks || "",
                        Date: new Date().toISOString(),
                        CurrentStatus: "Resubmitted"
                    };
                    prevHistory.push(newEntry);
                    return [4 /*yield*/, buildApprovalFlow({
                            RMId: employee.RMId,
                            HODId: employee.HODId,
                            RM: employee.RM,
                            HOD: employee.HOD
                        }, paymentType)];
                case 3:
                    flow = _e.sent();
                    currentApprover = flow.length > 0 ? flow[0].Id : null;
                    nextApprover = flow.length > 1 ? flow[1].Id : null;
                    wfHistoryPayload = JSON.stringify(prevHistory);
                    if (!Id) return [3 /*break*/, 5];
                    return [4 /*yield*/, sp_3.updateData("ForexRequest", Number(Id), {
                            ForexType: paymentType,
                            EmployeeCode: employee.EmployeeCode,
                            EmployeeName: employee.EmployeeName,
                            Division: employee.Division,
                            Location: employee.Location,
                            RMId: employee.RMId,
                            HODId: employee.HODId,
                            ContactNo: ((_d = employee.ContactNo) === null || _d === void 0 ? void 0 : _d.toString()) || "",
                            Email: employee.Email,
                            BankName: bankname || "",
                            BankAccNo: bankaccountno || "",
                            Remarks: remarks || "",
                            Status: "Pending for RM Approval",
                            NatureOfPayment: paymentType,
                            DocumentIsAvailable: taxDocumentView,
                            DTAAApplicable: dTAAApplicable,
                            ForexNumber: requestNumber,
                            TotalAmount: (totalAmount) || "",
                            ForeignBankCharges: (foreignBankCharges) || "",
                            RequestedOn: requestedOn || null,
                            VendorCode: vendor.VendorCode,
                            VendorName: vendor.VendorName,
                            poContractNo: poContractNo || "",
                            poDate: poDate || null,
                            expectedSettlementDate: expectedSettlementDate || null,
                            BankSwiftCode: bankswiftcode || "",
                            BallenceEligibleAmount: "" + ballenceEligibleAmount,
                            PaidAmount: "" + paidAmount,
                            EligibleAmountWithWHT: "" + eligibleAmountWithWHT,
                            WorkFlowHistory: wfHistoryPayload,
                            CurrentApproverId: currentApprover,
                            AllApprovers: JSON.stringify(flow)
                        }, props)];
                case 4:
                    parentResponse = _e.sent();
                    _e.label = 5;
                case 5: return [4 /*yield*/, sp_3.getData("ForexServicesBillPayment", "ID", "", "ForexIDId eq ".concat(Id), { column: "ID", isAscending: true }, 5000, props)];
                case 6:
                    oldRows = _e.sent();
                    requestId_1 = Id;
                    console.log("✅ Parent Saved ID:", requestId_1);
                    // 🔥 INSERT + UPDATE + ATTACHMENTS
                    return [4 /*yield*/, Promise.all(rows
                            .filter(function (row) { return row.invoiceNo; })
                            .map(function (row, index) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
                            var itemId, inserted, webUrl, _i, _a, file, fileName, uploadUrl, _b, _c, file, fileName, _d, _e, file, fileName, _f, _g, file, fileName;
                            return tslib_1.__generator(this, function (_h) {
                                switch (_h.label) {
                                    case 0:
                                        itemId = row.id;
                                        if (!itemId) return [3 /*break*/, 2];
                                        return [4 /*yield*/, sp_3.updateData("ForexServicesBillPayment", itemId, {
                                                SrNo: "" + (index + 1),
                                                InvoiceNumber: row.invoiceNo || "",
                                                InvoiceDate: row.invoiceDate || null,
                                                InvoiceAmount: row.invoiceAmount || "",
                                                MRNNumber: row.mrnNo || "",
                                                MRNDate: row.mrnDate || null,
                                                BillofLandingNo: row.blNo || "",
                                                BillOfLandingdate: row.blDate || null,
                                                BOENo: row.boeNo || "",
                                                BOEDate: row.boeDate || null
                                            }, props)];
                                    case 1:
                                        _h.sent();
                                        return [3 /*break*/, 4];
                                    case 2: return [4 /*yield*/, sp_3.insertData("ForexServicesBillPayment", {
                                            ForexIDId: requestId_1,
                                            SrNo: "" + (index + 1),
                                            InvoiceNumber: row.invoiceNo || "",
                                            InvoiceDate: row.invoiceDate || null,
                                            InvoiceAmount: row.invoiceAmount || "",
                                            MRNNumber: row.mrnNo || "",
                                            MRNDate: row.mrnDate || null,
                                            BillofLandingNo: row.blNo || "",
                                            BillOfLandingdate: row.blDate || null,
                                            BOENo: row.boeNo || "",
                                            BOEDate: row.boeDate || null
                                        }, props)];
                                    case 3:
                                        inserted = _h.sent();
                                        itemId = inserted.data.Id;
                                        _h.label = 4;
                                    case 4:
                                        webUrl = props.context.pageContext.web.absoluteUrl;
                                        _i = 0, _a = (invoiceFiles[index] || []);
                                        _h.label = 5;
                                    case 5:
                                        if (!(_i < _a.length)) return [3 /*break*/, 8];
                                        file = _a[_i];
                                        fileName = "INV_".concat(row.invoiceNo || "ROW" + index, "_").concat(file.name);
                                        uploadUrl = "".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(itemId, ")/AttachmentFiles/add(FileName='").concat(encodeURIComponent(fileName), "')");
                                        return [4 /*yield*/, props.context.spHttpClient.post(uploadUrl, sp_http_1.SPHttpClient.configurations.v1, {
                                                headers: {
                                                    "Accept": "application/json;odata=nometadata"
                                                },
                                                body: file
                                            })];
                                    case 6:
                                        _h.sent();
                                        _h.label = 7;
                                    case 7:
                                        _i++;
                                        return [3 /*break*/, 5];
                                    case 8:
                                        _b = 0, _c = (otherFiles[index] || []);
                                        _h.label = 9;
                                    case 9:
                                        if (!(_b < _c.length)) return [3 /*break*/, 12];
                                        file = _c[_b];
                                        fileName = "DOC_".concat(row.invoiceNo || "ROW" + index, "_").concat(file.name);
                                        return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(itemId, ")/AttachmentFiles/add(FileName='").concat(encodeURIComponent(fileName), "')"), sp_http_1.SPHttpClient.configurations.v1, {
                                                headers: { "Accept": "application/json;odata=nometadata" },
                                                body: file
                                            })];
                                    case 10:
                                        _h.sent();
                                        _h.label = 11;
                                    case 11:
                                        _b++;
                                        return [3 /*break*/, 9];
                                    case 12:
                                        _d = 0, _e = (poFiles[index] || []);
                                        _h.label = 13;
                                    case 13:
                                        if (!(_d < _e.length)) return [3 /*break*/, 16];
                                        file = _e[_d];
                                        fileName = "PO_".concat(file.name);
                                        return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(itemId, ")/AttachmentFiles/add(FileName='").concat(encodeURIComponent(fileName), "')"), sp_http_1.SPHttpClient.configurations.v1, {
                                                headers: { "Accept": "application/json;odata=nometadata" },
                                                body: file
                                            })];
                                    case 14:
                                        _h.sent();
                                        _h.label = 15;
                                    case 15:
                                        _d++;
                                        return [3 /*break*/, 13];
                                    case 16:
                                        _f = 0, _g = (piFiles[index] || []);
                                        _h.label = 17;
                                    case 17:
                                        if (!(_f < _g.length)) return [3 /*break*/, 20];
                                        file = _g[_f];
                                        fileName = "PI_".concat(file.name);
                                        return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(itemId, ")/AttachmentFiles/add(FileName='").concat(encodeURIComponent(fileName), "')"), sp_http_1.SPHttpClient.configurations.v1, {
                                                headers: { "Accept": "application/json;odata=nometadata" },
                                                body: file
                                            })];
                                    case 18:
                                        _h.sent();
                                        _h.label = 19;
                                    case 19:
                                        _f++;
                                        return [3 /*break*/, 17];
                                    case 20: return [2 /*return*/];
                                }
                            });
                        }); }))];
                case 7:
                    // 🔥 INSERT + UPDATE + ATTACHMENTS
                    _e.sent();
                    alert("✅ Data Updated successfully!");
                    history.push("/");
                    return [3 /*break*/, 9];
                case 8:
                    error_5 = _e.sent();
                    console.error("❌ Error submitting data:", error_5);
                    alert("Something went wrong. Please check console.");
                    return [3 /*break*/, 9];
                case 9: return [2 /*return*/];
            }
        });
    }); };
    var handledraft = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp_4, workflowHistory, approverslist, currentApprover, nextApprover, allApproversJson, parentResponse, requestId, index, row, childResponse, childItemId, webUrl, _i, _a, file, fileName, _b, _c, file, fileName, _d, _e, file, fileName, _f, _g, file, fileName, _h, _j, file, fileName, _k, uniqueBoeNumbers_2, boeNo, files, _l, files_1, file, _m, uniqueBlNumbers_2, blNo, files, _o, files_2, file, error_6;
        var _p;
        return tslib_1.__generator(this, function (_q) {
            switch (_q.label) {
                case 0:
                    _q.trys.push([0, 38, 39, 40]);
                    setIsSubmitting(true);
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    sp_4 = _q.sent();
                    workflowHistory = [
                        {
                            CurrentApprover: employee.EmployeeName,
                            ActionTaken: "Draft Saved",
                            Comment: remarks || "",
                            Date: new Date().toISOString(),
                            CurrentStatus: "Draft"
                        }
                    ];
                    approverslist = approvers || [];
                    currentApprover = approverslist.length > 0 ? approverslist[0] : null;
                    nextApprover = approverslist.length > 1 ? approverslist[1] : null;
                    allApproversJson = JSON.stringify(approverDetails);
                    return [4 /*yield*/, sp_4.updateData("ForexRequest", Number(Id), {
                            ForexType: paymentType,
                            EmployeeCode: employee.EmployeeCode,
                            EmployeeName: employee.EmployeeName,
                            Division: employee.Division,
                            Location: employee.Location,
                            RMId: employee.RMId || null,
                            HODId: employee.HODId || null,
                            ContactNo: ((_p = employee.ContactNo) === null || _p === void 0 ? void 0 : _p.toString()) || "",
                            Email: employee.Email,
                            BankName: bankname || "",
                            BankAccNo: bankaccountno || "",
                            BankSwiftCode: bankswiftcode || "",
                            Remarks: remarks || "",
                            Status: "Draft",
                            NatureOfPayment: paymentType,
                            DocumentIsAvailable: taxDocumentView,
                            DTAAApplicable: dTAAApplicable,
                            ForexNumber: requestNumber,
                            TotalAmount: "" + totalAmount,
                            ForeignBankCharges: foreignBankCharges || "",
                            RequestedOn: requestedOn || null,
                            VendorCode: vendor.VendorCode || "",
                            VendorName: vendor.VendorName || "",
                            poContractNo: poContractNo || "",
                            poDate: poDate || null,
                            expectedSettlementDate: expectedSettlementDate || null,
                            EmployeeStatus: employee.EmployeeStatus || "",
                            BallenceEligibleAmount: "" + ballenceEligibleAmount,
                            PaidAmount: "" + paidAmount,
                            EligibleAmountWithWHT: "" + eligibleAmountWithWHT,
                            CurrencyId: currency || null,
                            WorkFlowHistory: JSON.stringify(workflowHistory),
                            // Draft -> no approval flow
                            CurrentApproverId: null,
                            NextApproversId: { results: [] },
                            AllApprovers: "" + allApproversJson
                        }, props)];
                case 2:
                    parentResponse = _q.sent();
                    requestId = parentResponse.data.ID;
                    console.log("Draft Saved ID:", requestId);
                    index = 0;
                    _q.label = 3;
                case 3:
                    if (!(index < rows.length)) return [3 /*break*/, 25];
                    row = rows[index];
                    // Skip empty rows
                    if (!row.invoiceNo &&
                        !row.invoiceDate &&
                        !row.invoiceAmount)
                        return [3 /*break*/, 24];
                    return [4 /*yield*/, sp_4.insertData("ForexServicesBillPayment", {
                            ForexIDId: requestId,
                            SrNo: "" + (index + 1),
                            InvoiceNumber: row.invoiceNo || "",
                            InvoiceDate: row.invoiceDate || null,
                            InvoiceAmount: row.invoiceAmount || "",
                            MRNNumber: row.mrnNo || "",
                            MRNDate: row.mrnDate || null,
                            BillofLandingNo: row.blNo || "",
                            BillOfLandingdate: row.blDate || null,
                            BOENo: row.boeNo || "",
                            BOEDate: row.boeDate || null
                        }, props)];
                case 4:
                    childResponse = _q.sent();
                    childItemId = childResponse.data.ID;
                    webUrl = props.context.pageContext.web.absoluteUrl;
                    if (!(paymentType === "Goods-Bill Payment" || paymentType === "Service-Bill Payment")) return [3 /*break*/, 12];
                    if (!(invoiceFiles[index] && invoiceFiles[index].length > 0)) return [3 /*break*/, 8];
                    _i = 0, _a = (invoiceFiles[index] || []);
                    _q.label = 5;
                case 5:
                    if (!(_i < _a.length)) return [3 /*break*/, 8];
                    file = _a[_i];
                    fileName = "INV_".concat(row.invoiceNo, "_").concat(file.name);
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(childItemId, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, { body: file })];
                case 6:
                    _q.sent();
                    _q.label = 7;
                case 7:
                    _i++;
                    return [3 /*break*/, 5];
                case 8:
                    if (!(otherFiles[index] && otherFiles[index].length > 0)) return [3 /*break*/, 12];
                    _b = 0, _c = (otherFiles[index] || []);
                    _q.label = 9;
                case 9:
                    if (!(_b < _c.length)) return [3 /*break*/, 12];
                    file = _c[_b];
                    fileName = "DOC_".concat(row.invoiceNo, "_").concat(file.name);
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(childItemId, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, { body: file })];
                case 10:
                    _q.sent();
                    _q.label = 11;
                case 11:
                    _b++;
                    return [3 /*break*/, 9];
                case 12:
                    if (!(paymentType === "Goods-Advance Payment" || paymentType === "Service-Advance Payment")) return [3 /*break*/, 24];
                    if (!(poFiles[index] && poFiles[index].length > 0)) return [3 /*break*/, 16];
                    _d = 0, _e = (poFiles[index] || []);
                    _q.label = 13;
                case 13:
                    if (!(_d < _e.length)) return [3 /*break*/, 16];
                    file = _e[_d];
                    fileName = "PO_".concat(row.invoiceNo, "_").concat(file.name);
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(childItemId, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, { body: file })];
                case 14:
                    _q.sent();
                    _q.label = 15;
                case 15:
                    _d++;
                    return [3 /*break*/, 13];
                case 16:
                    if (!(piFiles[index] && piFiles[index].length > 0)) return [3 /*break*/, 20];
                    _f = 0, _g = (piFiles[index] || []);
                    _q.label = 17;
                case 17:
                    if (!(_f < _g.length)) return [3 /*break*/, 20];
                    file = _g[_f];
                    fileName = "PI_".concat(row.invoiceNo, "_").concat(file.name);
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(childItemId, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, { body: file })];
                case 18:
                    _q.sent();
                    _q.label = 19;
                case 19:
                    _f++;
                    return [3 /*break*/, 17];
                case 20:
                    if (!(otherFilesAdv[index] && otherFilesAdv[index].length > 0)) return [3 /*break*/, 24];
                    _h = 0, _j = (otherFilesAdv[index] || []);
                    _q.label = 21;
                case 21:
                    if (!(_h < _j.length)) return [3 /*break*/, 24];
                    file = _j[_h];
                    fileName = "DOC_".concat(row.invoiceNo, "_").concat(file.name);
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(childItemId, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, { body: file })];
                case 22:
                    _q.sent();
                    _q.label = 23;
                case 23:
                    _h++;
                    return [3 /*break*/, 21];
                case 24:
                    index++;
                    return [3 /*break*/, 3];
                case 25:
                    _k = 0, uniqueBoeNumbers_2 = uniqueBoeNumbers;
                    _q.label = 26;
                case 26:
                    if (!(_k < uniqueBoeNumbers_2.length)) return [3 /*break*/, 31];
                    boeNo = uniqueBoeNumbers_2[_k];
                    if (!(!boeFiles[boeNo] || boeFiles[boeNo].length > 0)) return [3 /*break*/, 30];
                    files = boeFiles[boeNo] || [];
                    _l = 0, files_1 = files;
                    _q.label = 27;
                case 27:
                    if (!(_l < files_1.length)) return [3 /*break*/, 30];
                    file = files_1[_l];
                    return [4 /*yield*/, uploadToLibrary("BOEAttachments", "".concat(requestId, "_").concat(boeNo, "_").concat(Date.now(), "_").concat(file.name), file, {
                            Title: file.name,
                            BOENo: boeNo,
                            ReqeuestId: requestId.toString()
                        })];
                case 28:
                    _q.sent();
                    _q.label = 29;
                case 29:
                    _l++;
                    return [3 /*break*/, 27];
                case 30:
                    _k++;
                    return [3 /*break*/, 26];
                case 31:
                    _m = 0, uniqueBlNumbers_2 = uniqueBlNumbers;
                    _q.label = 32;
                case 32:
                    if (!(_m < uniqueBlNumbers_2.length)) return [3 /*break*/, 37];
                    blNo = uniqueBlNumbers_2[_m];
                    if (!(!blFiles[blNo] || blFiles[blNo].length > 0)) return [3 /*break*/, 36];
                    files = blFiles[blNo] || [];
                    _o = 0, files_2 = files;
                    _q.label = 33;
                case 33:
                    if (!(_o < files_2.length)) return [3 /*break*/, 36];
                    file = files_2[_o];
                    return [4 /*yield*/, uploadToLibrary("BillOfLandingAttachment", "".concat(requestId, "_").concat(blNo, "_").concat(Date.now(), "_").concat(file.name), file, {
                            Title: file.name,
                            BOLNo: blNo,
                            ReqeuestId: requestId.toString()
                        })];
                case 34:
                    _q.sent();
                    _q.label = 35;
                case 35:
                    _o++;
                    return [3 /*break*/, 33];
                case 36:
                    _m++;
                    return [3 /*break*/, 32];
                case 37:
                    alert("Draft saved successfully!");
                    history.push("/");
                    return [3 /*break*/, 40];
                case 38:
                    error_6 = _q.sent();
                    console.error("Error saving draft:", error_6);
                    alert("Something went wrong while saving draft.");
                    return [3 /*break*/, 40];
                case 39:
                    setIsSubmitting(false);
                    return [7 /*endfinally*/];
                case 40: return [2 /*return*/];
            }
        });
    }); };
    var handleAdvanceFileChange = function (index, e, type) {
        var files = e.target.files;
        if (type === "po") {
            setPoFiles(function (prev) {
                var _a;
                return (tslib_1.__assign(tslib_1.__assign({}, prev), (_a = {}, _a[index] = files, _a)));
            });
        }
        else if (type === "pi") {
            setPiFiles(function (prev) {
                var _a;
                return (tslib_1.__assign(tslib_1.__assign({}, prev), (_a = {}, _a[index] = files, _a)));
            });
        }
        else {
            setOtherFilesAdv(function (prev) {
                var _a;
                return (tslib_1.__assign(tslib_1.__assign({}, prev), (_a = {}, _a[index] = files, _a)));
            });
        }
    };
    var handleFileChange = function (index, e, type) {
        var selectedFiles = e.target.files;
        if (type === "invoice") {
            setInvoiceFiles(function (prev) {
                var _a;
                return (tslib_1.__assign(tslib_1.__assign({}, prev), (_a = {}, _a[index] = selectedFiles, _a)));
            });
        }
        else {
            setOtherFiles(function (prev) {
                var _a;
                return (tslib_1.__assign(tslib_1.__assign({}, prev), (_a = {}, _a[index] = selectedFiles, _a)));
            });
        }
    };
    var handleBoeBlFileChange = function (key, e, type) {
        var files = e.target.files;
        if (type === "boe") {
            setBoeFiles(function (prev) {
                var _a;
                return (tslib_1.__assign(tslib_1.__assign({}, prev), (_a = {}, _a[key] = files, _a)));
            });
        }
        else {
            setBlFiles(function (prev) {
                var _a;
                return (tslib_1.__assign(tslib_1.__assign({}, prev), (_a = {}, _a[key] = files, _a)));
            });
        }
    };
    var formatDate = function (date) {
        if (!date)
            return "";
        var d = new Date(date);
        var day = String(d.getDate()).padStart(2, "0");
        var month = String(d.getMonth() + 1).padStart(2, "0");
        var year = d.getFullYear();
        return "".concat(day, "-").concat(month, "-").concat(year);
    };
    var removeAttachment = function (itemId, fileName, rowIndex) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var webUrl, updatedRows, error_7;
        var _a;
        return tslib_1.__generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 2, , 3]);
                    webUrl = props.context.pageContext.web.absoluteUrl;
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexServicesBillPayment')/items(").concat(itemId, ")/AttachmentFiles/getByFileName('").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, {
                            headers: {
                                "IF-MATCH": "*",
                                "X-HTTP-Method": "DELETE"
                            }
                        })];
                case 1:
                    _b.sent();
                    updatedRows = tslib_1.__spreadArray([], rows, true);
                    updatedRows[rowIndex].attachments =
                        (_a = updatedRows[rowIndex].attachments) === null || _a === void 0 ? void 0 : _a.filter(function (f) { return f.FileName !== fileName; });
                    setRows(updatedRows);
                    alert("Attachment removed successfully");
                    return [3 /*break*/, 3];
                case 2:
                    error_7 = _b.sent();
                    console.error("Error deleting attachment:", error_7);
                    alert("Error deleting attachment");
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    return (react_1.default.createElement("div", { className: "forex-wrapper" },
        react_1.default.createElement("div", { className: "forex-header" },
            react_1.default.createElement("h2", null, "Forex Payment Edit Form")),
        react_1.default.createElement("div", { className: "forex-card" },
            react_1.default.createElement(Section, { title: "Approval Flow" },
                react_1.default.createElement("div", { className: "approval-ribbon" },
                    react_1.default.createElement("div", { className: "ribbon-step initiator" }, employee.EmployeeName),
                    approverDetails.map(function (approver, index) { return (react_1.default.createElement("div", { key: index, className: "ribbon-step approver" }, approver.Name)); }))),
            react_1.default.createElement(Section, { title: "Requestor Information" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Type", required: true },
                        react_1.default.createElement("select", { value: paymentType, onChange: function (e) {
                                var selected = e.target.value;
                                setPaymentType(selected);
                                buildApprovalFlow({
                                    RMId: employee.RMId,
                                    HODId: employee.HODId,
                                    RM: employee.RM,
                                    HOD: employee.HOD
                                }, selected);
                            }, disabled // disable if rows exist
                            : true },
                            react_1.default.createElement("option", { value: "Goods-Bill Payment" }, "Goods-Bill Payment"),
                            react_1.default.createElement("option", { value: "Service-Bill Payment" }, "Service-Bill Payment"),
                            react_1.default.createElement("option", { value: "Goods-Advance Payment" }, "Goods-Advance Payment"),
                            react_1.default.createElement("option", { value: "Service-Advance Payment" }, "Service-Advance Payment")))),
                react_1.default.createElement(Grid, { style: { marginTop: "20px" } },
                    react_1.default.createElement(Field, { label: "Employee Code" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Name" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Division" },
                        react_1.default.createElement("input", { type: "text", value: employee.Division, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Location" },
                        react_1.default.createElement("input", { type: "text", value: employee.Location, readOnly: true })),
                    react_1.default.createElement(Field, { label: "RM" },
                        react_1.default.createElement("input", { type: "text", value: employee.RM, readOnly: true })),
                    react_1.default.createElement(Field, { label: "HOD" },
                        react_1.default.createElement("input", { type: "text", value: employee.HOD, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Contact No" },
                        react_1.default.createElement("input", { type: "text", value: employee.ContactNo, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Status" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeStatus, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Email", full: true },
                        react_1.default.createElement("input", { type: "email", value: employee.Email, readOnly: true })))),
            react_1.default.createElement(Section, { title: "Vendor / Beneficiary Details " },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Vendor Code", required: true },
                        react_1.default.createElement(react_2.ComboBox, { placeholder: "Search Vendor Code", options: vendorOptions, selectedKey: vendor.VendorCode, allowFreeform: false, autoComplete: "on", useComboBoxAsMenuWidth: true, onChange: function (event, option, index, value) {
                                if (option) {
                                    var code_1 = option.key;
                                    setVendor(function (prev) { return (tslib_1.__assign(tslib_1.__assign({}, prev), { VendorCode: code_1 })); });
                                    getVendorData(code_1);
                                }
                            } })),
                    react_1.default.createElement(Field, { label: "Vendor Name" },
                        react_1.default.createElement("input", { value: vendor.VendorName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Address", full: true },
                        react_1.default.createElement("input", { value: vendor.VendorAddress, readOnly: true })),
                    react_1.default.createElement(Field, { label: "City" },
                        react_1.default.createElement("input", { value: vendor.City, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Country" },
                        react_1.default.createElement("input", { value: vendor.Country, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Pincode" },
                        react_1.default.createElement("input", { value: vendor.PostalCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Name" },
                        react_1.default.createElement("input", { value: vendor.BankName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Country" },
                        react_1.default.createElement("input", { value: vendor.BankCountry, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Swift Code" },
                        react_1.default.createElement("input", { value: vendor.SWIFTBICCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Branch Address" },
                        react_1.default.createElement("input", { value: vendor.BankAddress, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank IBAN / Account No", full: true },
                        react_1.default.createElement("input", { value: vendor.AccountNumberIBAN, readOnly: true })))),
            react_1.default.createElement(Section, { title: "Tax & Regulatory Information" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Nature of Payment" },
                        react_1.default.createElement("input", { value: paymentType, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Tax Document Available?" },
                        react_1.default.createElement("select", { onChange: function (e) { setTaxDocumentView(e.target.value); } },
                            react_1.default.createElement("option", null, "Yes"),
                            react_1.default.createElement("option", null, "No"))),
                    taxDocumentView === "No" && (react_1.default.createElement(Field, null,
                        react_1.default.createElement("span", { style: { color: "red" } }, "(if No, withholding tax will be applicable)"))),
                    taxDocumentView === "Yes" && (react_1.default.createElement(Field, { label: "DTAA Applicable?", required: true },
                        react_1.default.createElement("select", { value: dTAAApplicable, onChange: function (e) { return setDTAAApplicable(e.target.value); } },
                            react_1.default.createElement("option", { value: "" }, "Select"),
                            react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                            react_1.default.createElement("option", { value: "No" }, "No")))))),
            taxDocumentView === "Yes" && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(Section, { title: "Permanent Establishment Declaration" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Document Available" },
                            react_1.default.createElement("select", { value: permanentEstablishmentDeclaration.DocumentAvailable || "", disabled: true },
                                react_1.default.createElement("option", { value: "" }, "Select"),
                                react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                react_1.default.createElement("option", { value: "No" }, "No"))),
                        react_1.default.createElement(Field, { label: "Document Number" },
                            react_1.default.createElement("input", { value: permanentEstablishmentDeclaration.DocumentNumber || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Document Date" },
                            react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.DocumentDate || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Validity Start Date" },
                            react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.ValidityStartDate || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Validity End Date" },
                            react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.ValidityEndDate || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "View Document" },
                            react_1.default.createElement("span", null,
                                react_1.default.createElement("a", { href: permanentEstablishmentDeclaration.Attachmenturl || "#", target: "_blank" }, permanentEstablishmentDeclaration.Attachmentfilename || "No Document Available"))))),
                react_1.default.createElement(Section, { title: "Tax Residency Certificate" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Document Available" },
                            react_1.default.createElement("select", { value: taxResidencyCertificate.DocumentAvailable || "", disabled: true },
                                react_1.default.createElement("option", { value: "" }, "Select"),
                                react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                react_1.default.createElement("option", { value: "No" }, "No"))),
                        react_1.default.createElement(Field, { label: "Document Number" },
                            react_1.default.createElement("input", { value: taxResidencyCertificate.DocumentNumber || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Country of Tax Residence" },
                            react_1.default.createElement("input", { value: taxResidencyCertificate.CountryOfTaxResidence || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Tax Identification Number" },
                            react_1.default.createElement("input", { value: taxResidencyCertificate.TaxIdentificationNumber || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Validity Start Date" },
                            react_1.default.createElement("input", { type: "date", value: taxResidencyCertificate.ValidityStartDate || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Validity End Date" },
                            react_1.default.createElement("input", { type: "date", value: taxResidencyCertificate.ValidityEndDate || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "View Document" },
                            react_1.default.createElement("span", null,
                                react_1.default.createElement("a", { href: taxResidencyCertificate.Attachmenturl || "#", target: "_blank" }, taxResidencyCertificate.Attachmentfilename || "No Document Available"))))),
                react_1.default.createElement(Section, { title: "Form 10F" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Document Available" },
                            react_1.default.createElement("select", { value: form10F.DocumentAvailable || "", disabled: true },
                                react_1.default.createElement("option", { value: "" }, "Select"),
                                react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                react_1.default.createElement("option", { value: "No" }, "No"))),
                        react_1.default.createElement(Field, { label: "Document Number" },
                            react_1.default.createElement("input", { value: form10F.DocumentNumber || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Acknowledgment Number" },
                            react_1.default.createElement("input", { value: form10F.AcknowledgmentNumber || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Document Date" },
                            react_1.default.createElement("input", { type: "date", value: form10F.DocumentDate || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Validity Start Date" },
                            react_1.default.createElement("input", { type: "date", value: form10F.ValidityStartDate || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "Validity End Date" },
                            react_1.default.createElement("input", { type: "date", value: form10F.ValidityEndDate || "", readOnly: true })),
                        react_1.default.createElement(Field, { label: "View Document" },
                            react_1.default.createElement("span", null,
                                react_1.default.createElement("a", { href: form10F.Attachmenturl || "#", target: "_blank" }, form10F.Attachmentfilename || "No Document Available"))))))),
            react_1.default.createElement(Section, null,
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement("div", { className: "date-summary" },
                        react_1.default.createElement("span", { className: "label" }, "From"),
                        react_1.default.createElement("span", { className: "value" }, formatDate(fromdate)),
                        react_1.default.createElement("span", { className: "label" }, "To"),
                        react_1.default.createElement("span", { className: "value" },
                            formatDate(todate),
                            ","))),
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Eligible amount that can be transmitted without WHT", required: true },
                        react_1.default.createElement("input", { type: "number", value: eligibleAmountWithWHT, onChange: function (e) { return setEligibleAmountWithWHT(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Paid Amount", required: true },
                        react_1.default.createElement("input", { type: "number", value: paidAmount, onChange: function (e) { return setPaidAmount(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Balance eligible amount(Without with holding Tax)", required: true },
                        react_1.default.createElement("input", { type: "number", value: ballenceEligibleAmount, onChange: function (e) { return setBallenceEligibleAmount(e.target.value); } })))),
            paymentType === "Goods-Bill Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number", required: true },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On", required: true },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Currency", required: true },
                        react_1.default.createElement(react_2.Dropdown, { options: currencyOptions, selectedKey: currency, onChange: function (e, option) {
                                if (option) {
                                    setCurrency(option.key);
                                }
                            } })),
                    react_1.default.createElement(Field, { label: "Total Amount", required: true },
                        react_1.default.createElement("input", { type: "number", value: totalInvoiceAmount.toFixed(2), onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges", required: true },
                        react_1.default.createElement("select", { className: "form-control", value: foreignBankCharges, onChange: function (e) { return setForeignBankCharges(e.target.value); } },
                            react_1.default.createElement("option", { value: "" }, "Select"),
                            react_1.default.createElement("option", { value: "Beneficiary" }, "Beneficiary"),
                            react_1.default.createElement("option", { value: "Our" }, "Our"),
                            react_1.default.createElement("option", { value: "Shared" }, "Shared"))),
                    "                            "),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr.No "),
                            react_1.default.createElement("th", null,
                                "Invoice No ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Invoice Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "BOE No ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "BOE Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "MRN No ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Bill of Lading No ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Bill of Lading Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Invoice Amount ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Attach Invoice",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null, "Attach Other Docs"),
                            react_1.default.createElement("th", null, "Add/Delete Entry"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.boeNo, onChange: function (e) {
                                        return handleChange(index, "boeNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.boeDate, onChange: function (e) {
                                        return handleChange(index, "boeDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.mrnNo, onChange: function (e) {
                                        return handleChange(index, "mrnNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.blNo, onChange: function (e) {
                                        return handleChange(index, "blNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.blDate, onChange: function (e) {
                                        return handleChange(index, "blDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "number", value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null, (_a = row.attachments) === null || _a === void 0 ? void 0 :
                                _a.filter(function (f) { return f.FileName.startsWith("INV_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("INV_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleFileChange(index, e, "invoice"); } })),
                            react_1.default.createElement("td", null, (_b = row.attachments) === null || _b === void 0 ? void 0 :
                                _b.filter(function (f) { return f.FileName.startsWith("DOC_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("DOC_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleFileChange(index, e, "other"); } })),
                            react_1.default.createElement("td", { style: { textAlign: "center" } },
                                index === rows.length - 1 && (react_1.default.createElement("button", { type: "button", onClick: addRow, style: {
                                        background: "#28a745",
                                        color: "white",
                                        marginRight: "5px",
                                        border: "none",
                                        padding: "5px 10px",
                                        cursor: "pointer",
                                        borderRadius: "4px"
                                    } }, "+")),
                                rows.length > 1 && (react_1.default.createElement("button", { type: "button", onClick: function () { return deleteRow(index); }, style: {
                                        background: "#dc3545",
                                        color: "white",
                                        border: "none",
                                        padding: "5px 10px",
                                        cursor: "pointer",
                                        borderRadius: "4px"
                                    } }, "\u2716")))));
                    }))),
                react_1.default.createElement("div", { style: { display: "flex", gap: "40px", marginTop: "30px" } },
                    react_1.default.createElement("div", { style: { flex: 1 } },
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "13px" } }, "Unique BOE no will be listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "BOE No"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBoeNumbers.map(function (boe, index) { return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, boe),
                                react_1.default.createElement("td", null,
                                    boeLibraryFiles
                                        .filter(function (file) { var _a; return ((_a = file.BOENo) === null || _a === void 0 ? void 0 : _a.trim()) === (boe === null || boe === void 0 ? void 0 : boe.trim()); })
                                        .map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.FileRef, target: "_blank" }, file.FileLeafRef))); }),
                                    react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleBoeBlFileChange(boe, e, "boe"); } })))); })))),
                    react_1.default.createElement("div", { style: { flex: 1 } },
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "13px" } }, "Unique Bill of lading no will be listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "Bill of Lading Number"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBlNumbers.map(function (bl, index) { return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, bl),
                                react_1.default.createElement("td", null,
                                    bolLibraryFiles
                                        .filter(function (file) { var _a; return ((_a = file.BOLNo) === null || _a === void 0 ? void 0 : _a.trim()) === (bl === null || bl === void 0 ? void 0 : bl.trim()); })
                                        .map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.FileRef, target: "_blank" }, file.FileLeafRef))); }),
                                    react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleBoeBlFileChange(bl, e, "bl"); } })))); }))))))),
            paymentType === "Service-Bill Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number", required: true },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On", required: true },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Currency", required: true },
                        react_1.default.createElement(react_2.Dropdown, { options: currencyOptions, selectedKey: currency, onChange: function (e, option) {
                                if (option) {
                                    setCurrency(option.key);
                                }
                            } })),
                    react_1.default.createElement(Field, { label: "Total Amount", required: true },
                        react_1.default.createElement("input", { type: "number", value: totalInvoiceAmount.toFixed(2), onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges", required: true },
                        react_1.default.createElement("select", { className: "form-control", value: foreignBankCharges, onChange: function (e) { return setForeignBankCharges(e.target.value); } },
                            react_1.default.createElement("option", { value: "" }, "Select"),
                            react_1.default.createElement("option", { value: "Beneficiary" }, "Beneficiary"),
                            react_1.default.createElement("option", { value: "Our" }, "Our"),
                            react_1.default.createElement("option", { value: "Shared" }, "Shared"))),
                    "                                 "),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null,
                                "Invoice No ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Invoice Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Invoice Amount ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "MRN No ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "MRN Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Attach Invoice ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null, "Attach Other Document"),
                            react_1.default.createElement("th", null, "Add/Delete Entry"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.mrnNo, onChange: function (e) {
                                        return handleChange(index, "mrnNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.mrnDate, onChange: function (e) {
                                        return handleChange(index, "mrnDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null, (_a = row.attachments) === null || _a === void 0 ? void 0 :
                                _a.filter(function (f) { return f.FileName.startsWith("INV_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("INV_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleFileChange(index, e, "invoice"); } })),
                            react_1.default.createElement("td", null, (_b = row.attachments) === null || _b === void 0 ? void 0 :
                                _b.filter(function (f) { return f.FileName.startsWith("DOC_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("DOC_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleFileChange(index, e, "other"); } })),
                            react_1.default.createElement("td", { style: { textAlign: "center" } },
                                index === rows.length - 1 && (react_1.default.createElement("button", { type: "button", onClick: addRow, style: {
                                        background: "#28a745",
                                        color: "white",
                                        marginRight: "5px",
                                        border: "none",
                                        padding: "5px 10px",
                                        cursor: "pointer",
                                        borderRadius: "4px"
                                    } }, "+")),
                                rows.length > 1 && (react_1.default.createElement("button", { type: "button", onClick: function () { return deleteRow(index); }, style: {
                                        background: "#dc3545",
                                        color: "white",
                                        border: "none",
                                        padding: "5px 10px",
                                        cursor: "pointer",
                                        borderRadius: "4px"
                                    } }, "\u2716")))));
                    }))))),
            paymentType === "Service-Advance Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On", required: true },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Currency", required: true },
                        react_1.default.createElement(react_2.Dropdown, { options: currencyOptions, selectedKey: currency, onChange: function (e, option) { if (option)
                                setCurrency(option.key); } })),
                    react_1.default.createElement(Field, { label: "Total Amount", required: true },
                        react_1.default.createElement("input", { type: "number", value: totalInvoiceAmount.toFixed(2), onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges", required: true },
                        react_1.default.createElement("select", { className: "form-control", value: foreignBankCharges, onChange: function (e) { return setForeignBankCharges(e.target.value); } },
                            react_1.default.createElement("option", { value: "" }, "Select"),
                            react_1.default.createElement("option", { value: "Beneficiary" }, "Beneficiary"),
                            react_1.default.createElement("option", { value: "Our" }, "Our"),
                            react_1.default.createElement("option", { value: "Shared" }, "Shared"))),
                    react_1.default.createElement(Field, { label: "PO/Contract No", required: true },
                        react_1.default.createElement("input", { value: poContractNo, onChange: function (e) { setPoContractNo(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "PO Date", required: true },
                        react_1.default.createElement("input", { type: "date", value: poDate, onChange: function (e) { setPoDate(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Expected Settlement Date", required: true },
                        react_1.default.createElement("input", { type: "date", value: expectedSettlementDate, onChange: function (e) { setExpectedSettlementDate(e.target.value); } }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null,
                                "Performa Invoice No ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Performa Invoice Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Performa Invoice Amount ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Attach PO ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Attach PI ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null, "Attach Other Document"),
                            react_1.default.createElement("th", null, "Add/Delete Entry"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b, _c;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null, (_a = row.attachments) === null || _a === void 0 ? void 0 :
                                _a.filter(function (f) { return f.FileName.startsWith("PO_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("PO_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleAdvanceFileChange(index, e, "po"); } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("td", null, (_b = row.attachments) === null || _b === void 0 ? void 0 :
                                    _b.filter(function (f) { return f.FileName.startsWith("PI_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("PI_", "")),
                                        react_1.default.createElement("button", { type: "button", onClick: function () {
                                                return removeAttachment(row.id, file.FileName, index);
                                            }, style: {
                                                background: "#dc3545",
                                                color: "#fff",
                                                border: "none",
                                                borderRadius: "4px",
                                                padding: "2px 8px",
                                                cursor: "pointer"
                                            } }, "Remove"))); }),
                                    react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleAdvanceFileChange(index, e, "pi"); } }))),
                            react_1.default.createElement("td", null, (_c = row.attachments) === null || _c === void 0 ? void 0 :
                                _c.filter(function (f) { return f.FileName.startsWith("DOC_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("DOC_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleAdvanceFileChange(index, e, "other"); } })),
                            react_1.default.createElement("td", { style: { textAlign: "center" } },
                                index === rows.length - 1 && (react_1.default.createElement("button", { type: "button", onClick: addRow, style: {
                                        background: "#28a745",
                                        color: "white",
                                        marginRight: "5px",
                                        border: "none",
                                        padding: "5px 10px",
                                        cursor: "pointer",
                                        borderRadius: "4px"
                                    } }, "+")),
                                rows.length > 1 && (react_1.default.createElement("button", { type: "button", onClick: function () { return deleteRow(index); }, style: {
                                        background: "#dc3545",
                                        color: "white",
                                        border: "none",
                                        padding: "5px 10px",
                                        cursor: "pointer",
                                        borderRadius: "4px"
                                    } }, "\u2716")))));
                    }))))),
            paymentType === "Goods-Advance Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On", required: true },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Currency", required: true },
                        react_1.default.createElement(react_2.Dropdown, { options: currencyOptions, selectedKey: currency, onChange: function (e, option) { if (option)
                                setCurrency(option.key); } })),
                    react_1.default.createElement(Field, { label: "Total Amount", required: true },
                        react_1.default.createElement("input", { type: "number", value: totalInvoiceAmount.toFixed(2), onChange: function (e) { setTotalAmount(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges", required: true },
                        react_1.default.createElement("select", { className: "form-control", value: foreignBankCharges, onChange: function (e) { return setForeignBankCharges(e.target.value); } },
                            react_1.default.createElement("option", { value: "" }, "Select"),
                            react_1.default.createElement("option", { value: "Beneficiary" }, "Beneficiary"),
                            react_1.default.createElement("option", { value: "Our" }, "Our"),
                            react_1.default.createElement("option", { value: "Shared" }, "Shared"))),
                    "                                 ",
                    react_1.default.createElement(Field, { label: "PO/Contract No", required: true },
                        react_1.default.createElement("input", { value: poContractNo, onChange: function (e) { setPoContractNo(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "PO Date", required: true },
                        react_1.default.createElement("input", { type: "date", value: poDate, onChange: function (e) { setPoDate(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Expected Settlement Date", required: true },
                        react_1.default.createElement("input", { type: "date", value: expectedSettlementDate, onChange: function (e) { setExpectedSettlementDate(e.target.value); } }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null,
                                "Performa Invoice No ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Performa Invoice Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Performa Invoice Amount ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Attach PO ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Attach PI ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null, "Attach Other Document"),
                            react_1.default.createElement("th", null, "Add/Delete Entry"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b, _c;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null, (_a = row.attachments) === null || _a === void 0 ? void 0 :
                                _a.filter(function (f) { return f.FileName.startsWith("PO_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("PO_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleAdvanceFileChange(index, e, "po"); } })),
                            react_1.default.createElement("td", null, (_b = row.attachments) === null || _b === void 0 ? void 0 :
                                _b.filter(function (f) { return f.FileName.startsWith("PI_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("PI_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleAdvanceFileChange(index, e, "pi"); } })),
                            react_1.default.createElement("td", null, (_c = row.attachments) === null || _c === void 0 ? void 0 :
                                _c.filter(function (f) { return f.FileName.startsWith("DOC_"); }).map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("DOC_", "")),
                                    react_1.default.createElement("button", { type: "button", onClick: function () {
                                            return removeAttachment(row.id, file.FileName, index);
                                        }, style: {
                                            background: "#dc3545",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "4px",
                                            padding: "2px 8px",
                                            cursor: "pointer"
                                        } }, "Remove"))); }),
                                react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) { return handleAdvanceFileChange(index, e, "other"); } })),
                            react_1.default.createElement("td", { style: { textAlign: "center" } },
                                index === rows.length - 1 && (react_1.default.createElement("button", { type: "button", onClick: addRow, style: {
                                        background: "#28a745",
                                        color: "white",
                                        marginRight: "5px",
                                        border: "none",
                                        padding: "5px 10px",
                                        cursor: "pointer",
                                        borderRadius: "4px"
                                    } }, "+")),
                                rows.length > 1 && (react_1.default.createElement("button", { type: "button", onClick: function () { return deleteRow(index); }, style: {
                                        background: "#dc3545",
                                        color: "white",
                                        border: "none",
                                        padding: "5px 10px",
                                        cursor: "pointer",
                                        borderRadius: "4px"
                                    } }, "\u2716")))));
                    }))))),
            react_1.default.createElement(Section, { title: "Workflow History" }, wfHistory.length > 0 ? (react_1.default.createElement("table", { className: "data-table" },
                react_1.default.createElement("thead", null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("th", null, "Action By"),
                        react_1.default.createElement("th", null, "Action"),
                        react_1.default.createElement("th", null, "Remark"),
                        " ",
                        react_1.default.createElement("th", null, "Date"))),
                react_1.default.createElement("tbody", null, wfHistory.map(function (item, index) { return (react_1.default.createElement("tr", { key: index },
                    react_1.default.createElement("td", null, item.CurrentApprover),
                    "   ",
                    react_1.default.createElement("td", null, item.ActionTaken),
                    "       ",
                    react_1.default.createElement("td", null, item.Comment),
                    "           ",
                    react_1.default.createElement("td", null, item.Date
                        ? new Date(item.Date).toLocaleString("en-GB")
                        : ""))); })))) : (react_1.default.createElement("p", null, "No workflow history available"))),
            react_1.default.createElement(Section, { title: "" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Remarks", full: true },
                        react_1.default.createElement("textarea", { rows: 3, value: remarks, onChange: function (e) { setRemarks(e.target.value); } })))),
            react_1.default.createElement("div", { className: "button-row" },
                react_1.default.createElement("button", { className: "btn-submit", onClick: onsubmit, disabled: isSubmitting }, isSubmitting ? "Submitting..." : "Submit"),
                react_1.default.createElement("button", { className: "btn-submit", onClick: handledraft, disabled: isSubmitting }, isSubmitting ? "Submitting..." : "Save as Draft"),
                react_1.default.createElement("button", { className: "btn-exit", onClick: function () { return history.push("/"); } }, "Exit"))),
        showVendorPopup && (react_1.default.createElement("div", { className: "popup-overlay" },
            react_1.default.createElement("div", { className: "popup-box" },
                react_1.default.createElement("h3", null, "Vendor Not Found"),
                react_1.default.createElement("p", null, "Please add vendor first."),
                react_1.default.createElement("div", { style: { marginTop: "20px", display: "flex", gap: "10px", justifyContent: "center" } },
                    react_1.default.createElement("button", { className: "btn-submit", onClick: function () {
                            setShowVendorPopup(false);
                            history.push("/vendor-creation");
                        } }, "Go to Vendor Creation")))))));
};
exports.default = Editrequest;
//# sourceMappingURL=NewRequestEditForm.js.map