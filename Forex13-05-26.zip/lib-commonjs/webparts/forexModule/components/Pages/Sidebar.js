"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
require("../../components/Pages/Css/Sidebar.scss");
//@ts-ignore
require("@fortawesome/fontawesome-free/css/all.min.css");
var SonaPNGLogo_png_1 = tslib_1.__importDefault(require("../../assets/SonaPNGLogo.png"));
var sp_1 = require("@pnp/sp");
var Sidebar = function (props) {
    var history = (0, react_router_dom_1.useHistory)();
    var location = (0, react_router_dom_1.useLocation)();
    var _a = React.useState(""), selectedTabUrl = _a[0], setSelectedTabUrl = _a[1];
    var _b = React.useState([]), tabs = _b[0], setTabs = _b[1];
    // const [loading, setLoading] = React.useState(true);
    var username = props.userDisplayName;
    // Setup PnPJS
    React.useEffect(function () {
        sp_1.sp.setup({ spfxContext: props.context });
    }, []);
    /** ---------------------------------------------------------
     * Load tabs that the user has access to via SharePoint groups
     * --------------------------------------------------------- */
    var loadTabsWithAccess = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var userGroups, userGroupIds_1, items, allowedTabs, err_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, sp_1.sp.web.currentUser.groups()];
                case 1:
                    userGroups = _a.sent();
                    userGroupIds_1 = userGroups.map(function (g) { return g.Id; });
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("Tabing")
                            .items
                            .select("Id", "Title", "SeqNo", "PageUrl", "TabingViewGroup/Id", "TabingViewGroup/Title")
                            .expand("TabingViewGroup")()];
                case 2:
                    items = _a.sent();
                    allowedTabs = items
                        .filter(function (tab) {
                        var groups = tab.TabingViewGroup || [];
                        // ✅ Public tab → no group assigned
                        if (groups.length === 0)
                            return true;
                        // ✅ User belongs to group → show
                        return groups.some(function (g) { return userGroupIds_1.includes(g.Id); });
                    })
                        .map(function (tab) { return ({
                        id: tab.Id,
                        title: tab.Title,
                        seq: tab.SeqNo || 999,
                        url: tab.PageUrl ? tab.PageUrl.replace(/\s+/g, "") : ""
                    }); })
                        .sort(function (a, b) { return a.seq - b.seq; });
                    setTabs(allowedTabs);
                    if (allowedTabs.length > 0) {
                        setSelectedTabUrl(allowedTabs[0].url);
                    }
                    return [3 /*break*/, 4];
                case 3:
                    err_1 = _a.sent();
                    console.error("Load Tabs Error:", err_1);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    // const loadTabsWithAccess = async () => {
    //   try {
    //     const userGroups = await sp.web.currentUser.groups();
    //     const userGroupIds = userGroups.map(g => g.Id);
    //     const items: any[] = await sp.web.lists
    //       .getByTitle("Tabing")
    //       .items
    //       .select(
    //         "Id",
    //         "Title",
    //         "SeqNo",
    //         "PageUrl",
    //         "TabingViewGroup/Id",
    //         "TabingViewGroup/Title"
    //       )
    //       .expand("TabingViewGroup")();
    //     // 🔹 Step 1: Identify if user is HOD / Legal
    //     const isRoleUser = items.some(tab =>
    //       tab.TabingViewGroup?.some((g: any) =>
    //         userGroupIds.includes(g.Id)
    //       )
    //     );
    //     const allowedTabs = items
    //       .filter(tab => {
    //         const groups = tab.TabingViewGroup || [];
    //         // 🔸 Case 1: Role user → ONLY role tabs
    //         if (isRoleUser) {
    //           return groups.some((g: any) =>
    //             userGroupIds.includes(g.Id)
    //           );
    //         }
    //         // 🔸 Case 2: Normal user → ONLY public tabs
    //         return groups.length === 0;
    //       })
    //       .map(tab => ({
    //         id: tab.Id,
    //         title: tab.Title,
    //         seq: tab.SeqNo || 999,
    //         url: tab.PageUrl ? tab.PageUrl.replace(/\s+/g, "") : ""
    //       }))
    //       .sort((a, b) => a.seq - b.seq);
    //     setTabs(allowedTabs);
    //     if (allowedTabs.length > 0) {
    //       setSelectedTabUrl(allowedTabs[0].url);
    //     }
    //   } catch (err) {
    //     console.error("Load Tabs Error:", err);
    //   }
    // };
    var getActiveClass = function (tabUrl) {
        // current route from browser hash
        var currentRoute = window.location.hash.replace("#", "") || "/";
        // route from tab url
        var tabRoute = tabUrl.split("#")[1] || "/";
        return currentRoute === tabRoute ? "active" : "";
    };
    /** ---------------------------------------------------------
     * Navigate to page
     * --------------------------------------------------------- */
    React.useEffect(function () {
        loadTabsWithAccess();
    }, []);
    return (React.createElement("div", { className: "sidebar" },
        React.createElement("div", { className: "sidehead" },
            React.createElement("div", { className: "logo" },
                React.createElement("img", { src: SonaPNGLogo_png_1.default, width: "25px", height: "25px" })),
            React.createElement("div", { className: "sidehead-right" }, "SONA COMSTAR")),
        React.createElement("div", { className: "sidehead-user" },
            React.createElement("i", { className: "fas fa-user", style: { marginLeft: "6px", marginRight: "10px" } }),
            username),
        React.createElement("ul", { className: "nav" }, tabs.map(function (tab) { return (React.createElement("li", { className: "nav-item", key: tab.id },
            React.createElement("a", { href: tab.url, className: "nav-link ".concat(getActiveClass(tab.url)), style: { cursor: "pointer" } }, tab.title))); }))));
};
exports.default = Sidebar;
//# sourceMappingURL=Sidebar.js.map