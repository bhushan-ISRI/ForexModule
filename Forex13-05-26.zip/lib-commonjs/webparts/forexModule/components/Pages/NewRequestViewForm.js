"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
require("../Pages/Css/NewRequest.scss");
var react_router_dom_1 = require("react-router-dom");
var spcrud_1 = tslib_1.__importDefault(require("../../service/BAL/spcrud"));
/* Helper Components */
var Section = function (_a) {
    var title = _a.title, children = _a.children;
    return (react_1.default.createElement("div", { className: "form-section" },
        react_1.default.createElement("h3", null, title),
        children));
};
var Grid = function (_a) {
    var children = _a.children;
    return (react_1.default.createElement("div", { className: "form-grid" }, children));
};
var Field = function (_a) {
    var label = _a.label, children = _a.children, full = _a.full;
    return (react_1.default.createElement("div", { className: full ? "form-field full" : "form-field" },
        react_1.default.createElement("label", null, label),
        children));
};
var CollapsibleSection = function (_a) {
    var title = _a.title, children = _a.children;
    var _b = react_1.default.useState(false), open = _b[0], setOpen = _b[1];
    return (react_1.default.createElement("div", { className: "form-section collapsible" },
        react_1.default.createElement("div", { className: "form-section-header", onClick: function () { return setOpen(!open); } },
            react_1.default.createElement("span", null, title),
            react_1.default.createElement("i", { className: "fas fa-chevron-".concat(open ? "up" : "down") })),
        open && (react_1.default.createElement("div", { className: "form-section-body" }, children))));
};
var ViewRequestForm = function (props) {
    var Id = (0, react_router_dom_1.useParams)().Id;
    var history = (0, react_router_dom_1.useHistory)();
    var spCrudOps = (0, spcrud_1.default)();
    var _a = (0, react_1.useState)("Goods-Bill Payment"), paymentType = _a[0], setPaymentType = _a[1];
    var _b = (0, react_1.useState)("Yes"), taxDocumentView = _b[0], setTaxDocumentView = _b[1];
    var _c = (0, react_1.useState)(), paymenttypeDropdownValue = _c[0], setPaymentTypeDropdownValue = _c[1];
    var _d = (0, react_1.useState)(""), fromdate = _d[0], setFromDate = _d[1];
    var _e = (0, react_1.useState)(""), todate = _e[0], setToDate = _e[1];
    var _f = (0, react_1.useState)(""), dTAAApplicable = _f[0], setDTAAApplicable = _f[1];
    var _g = react_1.default.useState(false), showVendorPopup = _g[0], setShowVendorPopup = _g[1];
    var _h = (0, react_1.useState)(""), bankaccountno = _h[0], setBankAccountNo = _h[1];
    var _j = (0, react_1.useState)(""), bankname = _j[0], setBankName = _j[1];
    var _k = (0, react_1.useState)(""), bankswiftcode = _k[0], setBankSwiftCode = _k[1];
    var _l = (0, react_1.useState)(""), remarks = _l[0], setRemarks = _l[1];
    var _m = (0, react_1.useState)(""), requestNumber = _m[0], setRequestNumber = _m[1];
    var _o = (0, react_1.useState)(""), requestedOn = _o[0], setRequestedOn = _o[1];
    var _p = (0, react_1.useState)(""), currency = _p[0], setCurrency = _p[1];
    var _q = (0, react_1.useState)(""), totalAmount = _q[0], setTotalAmount = _q[1];
    var _r = (0, react_1.useState)(""), foreignBankCharges = _r[0], setForeignBankCharges = _r[1];
    var _s = (0, react_1.useState)(""), poContractNo = _s[0], setPoContractNo = _s[1];
    var _t = (0, react_1.useState)(""), poDate = _t[0], setPoDate = _t[1];
    var _u = (0, react_1.useState)(""), expectedSettlementDate = _u[0], setExpectedSettlementDate = _u[1];
    var _v = (0, react_1.useState)(""), eligibleAmountWithWHT = _v[0], setEligibleAmountWithWHT = _v[1];
    var _w = (0, react_1.useState)(""), paidAmount = _w[0], setPaidAmount = _w[1];
    var _x = (0, react_1.useState)(""), ballenceEligibleAmount = _x[0], setBallenceEligibleAmount = _x[1];
    var _y = (0, react_1.useState)({}), invoiceAttachments = _y[0], setInvoiceAttachments = _y[1];
    var _z = (0, react_1.useState)({}), otherAttachments = _z[0], setOtherAttachments = _z[1];
    var _0 = (0, react_1.useState)({}), poAttachments = _0[0], setPoAttachments = _0[1];
    var _1 = (0, react_1.useState)({}), piAttachments = _1[0], setPiAttachments = _1[1];
    var _2 = (0, react_1.useState)([]), boeLibraryFiles = _2[0], setBoeLibraryFiles = _2[1];
    var _3 = (0, react_1.useState)([]), bolLibraryFiles = _3[0], setBolLibraryFiles = _3[1];
    var _4 = (0, react_1.useState)([]), approverDetails = _4[0], setApproverDetails = _4[1];
    var _5 = (0, react_1.useState)(null), currentApproverId = _5[0], setCurrentApproverId = _5[1];
    var _6 = (0, react_1.useState)([]), approvers = _6[0], setApprovers = _6[1];
    var _7 = (0, react_1.useState)(""), foreignCurrency = _7[0], setForeignCurrency = _7[1];
    var _8 = (0, react_1.useState)(""), foreignCurrencyAmount = _8[0], setForeignCurrencyAmount = _8[1];
    var _9 = (0, react_1.useState)(""), exchangeRate = _9[0], setExchangeRate = _9[1];
    var _10 = (0, react_1.useState)(""), inrAmount = _10[0], setInrAmount = _10[1];
    var _11 = (0, react_1.useState)(""), paymentDate = _11[0], setPaymentDate = _11[1];
    var _12 = (0, react_1.useState)(""), paymentReferenceNumber = _12[0], setPaymentReferenceNumber = _12[1];
    var _13 = (0, react_1.useState)([]), workflowHistory = _13[0], setWorkflowHistory = _13[1];
    var _14 = (0, react_1.useState)({}), poAttachmentsAdvance = _14[0], setPoAttachmentsAddvance = _14[1];
    var _15 = (0, react_1.useState)({}), piAttachmentsAddvance = _15[0], setPiAttachmentsAddvance = _15[1];
    var _16 = (0, react_1.useState)({}), invoiceAttachmentsTrackeradvance = _16[0], setInvoiceAttachmentsTrackeradvance = _16[1];
    var _17 = (0, react_1.useState)({}), otherAttachmentsTrackeradvance = _17[0], setOtherAttachmentsTrackeradvance = _17[1];
    var _18 = (0, react_1.useState)({}), poAttachmentsTrackeradvance = _18[0], setPoAttachmentsTrackeradvance = _18[1];
    var _19 = (0, react_1.useState)({}), piAttachmentsTrackeradvance = _19[0], setPiAttachmentsTrackeradvance = _19[1];
    var _20 = (0, react_1.useState)({}), boeAttachments = _20[0], setBoeAttachments = _20[1];
    var _21 = (0, react_1.useState)({}), blAttachments = _21[0], setBlAttachments = _21[1];
    var _22 = (0, react_1.useState)({}), boeAttachmentstrackeradvance = _22[0], setBoeAttachmentstrackeradvance = _22[1];
    var _23 = (0, react_1.useState)({}), blAttachmentstrackeradvance = _23[0], setBlAttachmentstrackeradvance = _23[1];
    var _24 = (0, react_1.useState)([
        {
            invoiceNo: "",
            invoiceDate: "",
            boeNo: "",
            boeDate: "",
            mrnNo: "",
            blNo: "",
            blDate: "",
            invoiceAmount: "",
        },
    ]), rowsAdvance = _24[0], setRowsAdvance = _24[1];
    var _25 = react_1.default.useState({
        EmployeeCode: "",
        EmployeeName: "",
        Division: "",
        Location: "",
        RM: "",
        HOD: "",
        ContactNo: "",
        EmployeeStatus: "",
        Email: "",
        RMId: 0,
        HODId: 0
    }), employee = _25[0], setEmployee = _25[1];
    var _26 = react_1.default.useState({
        VendorCode: "",
        VendorName: "",
        VendorNameLegal: "",
        VendorShortName: "",
        VendorType: "",
        City: "",
        State: "",
        Country: "",
        Currency: "",
        PostalCode: "",
        ContactPersonName: "",
        EmailId: "",
        PhoneNumber: "",
        AlternateContact: "",
        BeneficiaryName: "",
        BankName: "",
        AccountNumberIBAN: "",
        SWIFTBICCode: "",
        RoutingNumberABA: "",
        IFSCCode: "",
        IntermediaryBank: "",
        IntermediarySWIFTCode: "",
        NatureOfPayment: "",
        PurposeCodeRBI: "",
        BankCountry: "",
        BankAddress: "",
        VendorAddress: ""
    }), vendor = _26[0], setVendor = _26[1];
    var _27 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        SEPClause: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), permanentEstablishmentDeclaration = _27[0], setPermanentEstablishmentDeclaration = _27[1];
    var _28 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        TaxIdentificationNumber: "",
        CountryOfTaxResidence: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), taxResidencyCertificate = _28[0], setTaxResidencyCertificate = _28[1];
    var _29 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        AcknowledgmentNumber: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), form10F = _29[0], setForm10F = _29[1];
    var _30 = react_1.default.useState([
        {
            invoiceNo: "",
            invoiceDate: "",
            boeNo: "",
            boeDate: "",
            mrnNo: "",
            blNo: "",
            blDate: "",
            invoiceAmount: "",
            mrnDate: "" // Added for Service-Bill Payment
        }
    ]), rows = _30[0], setRows = _30[1];
    var addRow = function () {
        setRows(tslib_1.__spreadArray(tslib_1.__spreadArray([], rows, true), [
            {
                invoiceNo: "",
                invoiceDate: "",
                boeNo: "",
                boeDate: "",
                mrnNo: "",
                blNo: "",
                blDate: "",
                invoiceAmount: "",
                mrnDate: "" // Added for Service-Bill Payment
            }
        ], false));
    };
    var deleteRow = function (index) {
        var updatedRows = rows.filter(function (_, i) { return i !== index; });
        setRows(updatedRows);
    };
    var handleChange = function (index, field, value) {
        var updatedRows = tslib_1.__spreadArray([], rows, true);
        updatedRows[index][field] = value;
        setRows(updatedRows);
    };
    var _31 = (0, react_1.useState)([]), swiftCopy = _31[0], setSwiftCopy = _31[1];
    var _32 = (0, react_1.useState)([]), form15CA = _32[0], setForm15CA = _32[1];
    var _33 = (0, react_1.useState)([]), form15CB = _33[0], setForm15CB = _33[1];
    var _34 = (0, react_1.useState)(""), foreignCurrencypayment = _34[0], setForeignCurrencypayment = _34[1];
    var _35 = (0, react_1.useState)(""), foreignAmountpayment = _35[0], setForeignAmountpayment = _35[1];
    var _36 = (0, react_1.useState)(""), exchangeRatepayment = _36[0], setExchangeRatepayment = _36[1];
    var _37 = (0, react_1.useState)(""), inrAmountpayment = _37[0], setInrAmountpayment = _37[1];
    var _38 = (0, react_1.useState)(""), paymentDatepayment = _38[0], setPaymentDatepayment = _38[1];
    var _39 = (0, react_1.useState)(""), paymentReferencepayment = _39[0], setPaymentReferencepayment = _39[1];
    var isServicePayment = paymentType.includes("Service");
    var isGoodsPayment = paymentType.includes("Goods");
    var _40 = (0, react_1.useState)(""), validationDateshow = _40[0], setValidationDateshow = _40[1];
    var _41 = (0, react_1.useState)(""), voucherNumbershow = _41[0], setVoucherNumbershow = _41[1];
    var totalInvoiceAmount = rows.reduce(function (sum, row) {
        return sum + (parseFloat(row.invoiceAmount) || 0);
    }, 0);
    var uniqueBoeNumbers = rows
        .map(function (r) { return r.boeNo; })
        .filter(function (value, index, self) {
        return value && self.indexOf(value) === index;
    });
    var uniqueBlNumbers = rows
        .map(function (r) { return r.blNo; })
        .filter(function (value, index, self) {
        return value && self.indexOf(value) === index;
    });
    (0, react_1.useEffect)(function () {
        getFinancialYearStart();
        if (Id) {
            loadForexData(Id);
            loadTrackerData(parseInt(Id));
        }
    }, [Id]);
    //----------------------- load data for edit------------------------//
    var loadForexData = function (forexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, parent_1, data_1, parsed, approverList_1, parsed, child, formattedRows, attachmentMap, invoiceAttachmentMap_1, otherAttachmentMap_1, poAttachmentMap_1, piAttachmentMap_1, bolFiles, boeFiles, error_1;
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l;
        return tslib_1.__generator(this, function (_m) {
            switch (_m.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _m.sent();
                    _m.label = 2;
                case 2:
                    _m.trys.push([2, 7, , 8]);
                    return [4 /*yield*/, sp.getData("ForexRequest", "*,AllApprovers,RM/Title,HOD/Title,Author/Id,Currency/Title,Currency/Id,CurrentApprover/Id,CurrentApprover/Title,NextApprovers/Id,NextApprovers/Title,PrevApprovers/Id,PrevApprovers/Title", "RM,HOD,Author,Currency,CurrentApprover,NextApprovers,PrevApprovers", "ID eq ".concat(forexId), { column: "ID", isAscending: true }, 1, props)];
                case 3:
                    parent_1 = _m.sent();
                    if (parent_1.length > 0) {
                        data_1 = parent_1[0];
                        setPaymentType(data_1.ForexType || "");
                        setRequestNumber(data_1.ForexNumber || "");
                        setRequestedOn(((_a = data_1.RequestedOn) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "");
                        setCurrency(data_1.Currency.Title || "");
                        setTotalAmount(data_1.TotalAmount || "");
                        setForeignBankCharges(data_1.ForeignBankCharges || "");
                        setPoContractNo(data_1.poContractNo || "");
                        setPoDate(((_b = data_1.poDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "");
                        setExpectedSettlementDate(((_c = data_1.expectedSettlementDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "");
                        setBankName(data_1.BankName || "");
                        setBankAccountNo(data_1.BankAccNo || "");
                        setRemarks(data_1.Remarks || "");
                        setDTAAApplicable(data_1.DTAAApplicable || "");
                        setTaxDocumentView(data_1.DocumentIsAvailable || "");
                        setBankSwiftCode(data_1.BankSwiftCode || "");
                        setEligibleAmountWithWHT(data_1.EligibleAmountWithWHT || "");
                        setPaidAmount(data_1.PaidAmount || "");
                        setBallenceEligibleAmount(data_1.BallenceEligibleAmount || "");
                        setForeignCurrency(data_1.ForeignCurrency || "");
                        setForeignCurrencyAmount(data_1.ForeignCurrencyAmount || "");
                        setExchangeRate(data_1.ExchangeRate || "");
                        setInrAmount(data_1.INRAmount || "");
                        setValidationDateshow(((_d = data_1.ValidationDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "");
                        setVoucherNumbershow(data_1.VoucherNumber || "");
                        setPaymentDate(((_e = data_1.PaymentDate) === null || _e === void 0 ? void 0 : _e.split("T")[0]) || "");
                        setPaymentReferenceNumber(data_1.PaymentReferenceNumber || "");
                        // 🔥 LOAD WORKFLOW HISTORY
                        if (data_1.WorkFlowHistory) {
                            try {
                                parsed = JSON.parse(data_1.WorkFlowHistory);
                                setWorkflowHistory(parsed);
                            }
                            catch (_o) {
                                setWorkflowHistory([]);
                            }
                        }
                        setVendor(tslib_1.__assign(tslib_1.__assign({}, vendor), { VendorCode: data_1.VendorCode, VendorName: data_1.VendorName }));
                        setEmployee({
                            EmployeeCode: data_1.EmployeeCode || "",
                            EmployeeName: data_1.EmployeeName || "",
                            Division: data_1.Division || "",
                            Location: data_1.Location || "",
                            RM: ((_f = data_1.RM) === null || _f === void 0 ? void 0 : _f.Title) || "",
                            HOD: ((_g = data_1.HOD) === null || _g === void 0 ? void 0 : _g.Title) || "",
                            ContactNo: data_1.ContactNo || "",
                            EmployeeStatus: data_1.EmployeeStatus || "",
                            Email: data_1.Email || "",
                            RMId: ((_h = data_1.RM) === null || _h === void 0 ? void 0 : _h.Id) || 0,
                            HODId: ((_j = data_1.HOD) === null || _j === void 0 ? void 0 : _j.Id) || 0
                        });
                        getVendorData(data_1.VendorCode);
                        setCurrentApproverId(((_k = data_1.CurrentApprover) === null || _k === void 0 ? void 0 : _k.Id) || null);
                        approverList_1 = [];
                        if (data_1.AllApprovers) {
                            parsed = JSON.parse(data_1.AllApprovers);
                            parsed.forEach(function (a) {
                                var _a;
                                var status = "pending";
                                if (a.Status === "Approved") {
                                    status = "approved";
                                }
                                if (((_a = data_1.CurrentApprover) === null || _a === void 0 ? void 0 : _a.Id) === a.Id) {
                                    status = "current";
                                }
                                approverList_1.push({
                                    Id: a.Id,
                                    Name: a.Name,
                                    Role: a.Role,
                                    Level: a.Level,
                                    Status: status,
                                    Comment: a.Remarks
                                });
                            });
                        }
                        setApproverDetails(approverList_1);
                        setForeignAmountpayment(data_1.ForeignCurrencyAmount || "");
                        setPaymentReferencepayment(data_1.PaymentReferenceNumber || "");
                        setPaymentDatepayment(((_l = data_1.PaymentDate) === null || _l === void 0 ? void 0 : _l.split("T")[0]) || "");
                        setInrAmountpayment(data_1.INRAmount || "");
                        setExchangeRatepayment(data_1.ExchangeRate || "");
                        setForeignCurrencypayment(data_1.ForeignCurrency || "");
                    }
                    return [4 /*yield*/, sp.getData("ForexServicesBillPayment", "*,AttachmentFiles", "AttachmentFiles", "ForexIDId eq ".concat(forexId), { column: "ID", isAscending: true }, 5000, props)];
                case 4:
                    child = _m.sent();
                    if (child.length > 0) {
                        formattedRows = child.map(function (item) {
                            var _a, _b, _c, _d;
                            return ({
                                invoiceNo: item.InvoiceNumber || "",
                                invoiceDate: ((_a = item.InvoiceDate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "",
                                invoiceAmount: item.InvoiceAmount || "",
                                mrnNo: item.MRNNumber || "",
                                mrnDate: ((_b = item.MRNDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                blNo: item.BillofLandingNo || "",
                                blDate: ((_c = item.BillOfLandingdate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                boeNo: item.BOENo || "",
                                boeDate: ((_d = item.BOEDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || ""
                            });
                        });
                        setRows(formattedRows);
                        attachmentMap = {};
                        invoiceAttachmentMap_1 = {};
                        otherAttachmentMap_1 = {};
                        poAttachmentMap_1 = {};
                        piAttachmentMap_1 = {};
                        child.forEach(function (item, index) {
                            var allFiles = item.AttachmentFiles || [];
                            invoiceAttachmentMap_1[index] = allFiles.filter(function (file) { var _a; return (_a = file.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("INV_"); });
                            otherAttachmentMap_1[index] = allFiles.filter(function (file) { var _a; return (_a = file.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("DOC_"); });
                            poAttachmentMap_1[index] = allFiles.filter(function (file) { var _a; return (_a = file.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PO_"); });
                            piAttachmentMap_1[index] = allFiles.filter(function (file) { var _a; return (_a = file.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PI_"); });
                        });
                        setInvoiceAttachments(invoiceAttachmentMap_1);
                        setOtherAttachments(otherAttachmentMap_1);
                        setPoAttachments(poAttachmentMap_1);
                        setPiAttachments(piAttachmentMap_1);
                    }
                    return [4 /*yield*/, sp.getData("BillOfLandingAttachment", "FileLeafRef,FileRef,BOLNo,ReqeuestId", "", "ReqeuestId eq '".concat(Id, "'"), { column: "ID", isAscending: true }, 5000, props)];
                case 5:
                    bolFiles = _m.sent();
                    return [4 /*yield*/, sp.getData("BOEAttachments", "FileLeafRef,FileRef,BOENo,ReqeuestId", "", "ReqeuestId eq '".concat(Id, "'"), { column: "ID", isAscending: true }, 5000, props)];
                case 6:
                    boeFiles = _m.sent();
                    setBoeLibraryFiles(boeFiles);
                    setBolLibraryFiles(bolFiles);
                    return [3 /*break*/, 8];
                case 7:
                    error_1 = _m.sent();
                    console.error("Error loading edit data:", error_1);
                    return [3 /*break*/, 8];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    //=----------------------- userdata------------------------//
    var loadTrackerData = function (forexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, tracker, formattedRows, attachmentMap, poAttachmentMap_2, piAttachmentMap_2, otherAttachmentMap_2, boeAttachmentMap_1, blAttachmentMap_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    return [4 /*yield*/, sp.getData("ForexAdvanceBillPayment", "*,AttachmentFiles", "AttachmentFiles", "ForexIDId eq ".concat(forexId), { column: "ID", isAscending: true }, 5000, props)];
                case 2:
                    tracker = _a.sent();
                    if (tracker.length > 0) {
                        formattedRows = tracker.map(function (item) {
                            var _a, _b, _c, _d;
                            return ({
                                invoiceNo: item.InvoiceNumber || "",
                                invoiceDate: ((_a = item.InvoiceDate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "",
                                invoiceAmount: item.InvoiceAmount || "",
                                mrnNo: item.MRNNumber || "",
                                mrnDate: ((_b = item.MRNDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                blNo: item.BillofLandingNo || "",
                                blDate: ((_c = item.BillOfLandingdate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                boeNo: item.BOENo || "",
                                boeDate: ((_d = item.BOEDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || ""
                            });
                        });
                        setRowsAdvance(formattedRows);
                        attachmentMap = {};
                        poAttachmentMap_2 = {};
                        piAttachmentMap_2 = {};
                        otherAttachmentMap_2 = {};
                        boeAttachmentMap_1 = {};
                        blAttachmentMap_1 = {};
                        tracker.forEach(function (item, index) {
                            var files = item.AttachmentFiles || [];
                            poAttachmentMap_2[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PO_"); });
                            piAttachmentMap_2[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PI_"); });
                            otherAttachmentMap_2[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("DOC_"); });
                            boeAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("BOE_"); });
                            blAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("BL_"); });
                        });
                        setPoAttachmentsTrackeradvance(poAttachmentMap_2);
                        setPiAttachmentsTrackeradvance(piAttachmentMap_2);
                        setOtherAttachmentsTrackeradvance(otherAttachmentMap_2);
                        setBoeAttachmentstrackeradvance(boeAttachmentMap_1);
                        setBlAttachmentstrackeradvance(blAttachmentMap_1);
                    }
                    return [2 /*return*/];
            }
        });
    }); };
    var uniqueBoeNumbersadvancetracker = Array.from(new Set(rowsAdvance.map(function (r) { return r.boeNo; }).filter(Boolean)));
    var uniqueBlNumbersadvancetracker = Array.from(new Set(rowsAdvance.map(function (r) { return r.blNo; }).filter(Boolean)));
    //----------------------VendorData-------------------------//
    var getVendorData = function (vendorCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!vendorCode)
                        return [2 /*return*/];
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    (_a.sent()).getData("VendorMaster", "VendorCode,VendorName,VendorNameLegal,VendorShortName,VendorType,City/Title,State/Title,Country/Title,Currency/Title,PostalCode,ContactPersonName,EmailId,PhoneNumber,AlternateContact,BeneficiaryName,BankName,AccountNumberIBAN,SWIFTBICCode,RoutingNumberABA,IFSCCode,IntermediaryBank,IntermediarySWIFTCode,NatureOfPayment/Title,PurposeCodeRBI,BankCountry,BankAddress,VendorAddress", "NatureOfPayment,City,State,Country,Currency", "VendorCode eq '".concat(vendorCode, "'"), { column: "ID", isAscending: true }, 1, props)
                        .then(function (res) {
                        var _a, _b, _c, _d, _e;
                        if (res.length > 0) {
                            var v = res[0];
                            setVendor({
                                VendorCode: v.VendorCode || "",
                                VendorName: v.VendorName || "",
                                VendorNameLegal: v.VendorNameLegal || "",
                                VendorShortName: v.VendorShortName || "",
                                VendorType: v.VendorType || "",
                                City: ((_a = v.City) === null || _a === void 0 ? void 0 : _a.Title) || "",
                                State: ((_b = v.State) === null || _b === void 0 ? void 0 : _b.Title) || "",
                                Country: ((_c = v.Country) === null || _c === void 0 ? void 0 : _c.Title) || "",
                                Currency: ((_d = v.Currency) === null || _d === void 0 ? void 0 : _d.Title) || "",
                                PostalCode: v.PostalCode || "",
                                ContactPersonName: v.ContactPersonName || "",
                                EmailId: v.EmailId || "",
                                PhoneNumber: v.PhoneNumber || "",
                                AlternateContact: v.AlternateContact || "",
                                BeneficiaryName: v.BeneficiaryName || "",
                                BankName: v.BankName || "",
                                AccountNumberIBAN: v.AccountNumberIBAN || "",
                                SWIFTBICCode: v.SWIFTBICCode || "",
                                RoutingNumberABA: v.RoutingNumberABA || "",
                                IFSCCode: v.IFSCCode || "",
                                IntermediaryBank: v.IntermediaryBank || "",
                                IntermediarySWIFTCode: v.IntermediarySWIFTCode || "",
                                NatureOfPayment: ((_e = v.NatureOfPayment) === null || _e === void 0 ? void 0 : _e.Title) || "",
                                PurposeCodeRBI: v.PurposeCodeRBI || "",
                                BankAddress: v.BankAddress || "",
                                BankCountry: v.BankCountry || "",
                                VendorAddress: v.VendorAddress || ""
                            });
                            getTaxDeclarationdata(v.VendorCode);
                        }
                        else {
                            //alert("Vendor not found");
                            setShowVendorPopup(true);
                        }
                    })
                        .catch(function (error) {
                        console.error("Error fetching vendor data:", error);
                    });
                    return [2 /*return*/];
            }
        });
    }); };
    var getTaxDeclarationdata = function (vendorCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!vendorCode)
                        return [2 /*return*/];
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    (_a.sent()).getData("VendorTaxDeclaration", "VendorMasterId/ID,VendorCode/VendorCode,VendorName/VendorName,DeclarationType,DocumentAvailable,DocumentNumber,DocumentDate,SEPClause,ValidityStartDate,ValidityEndDate,TaxIdentificationNumber,CountryOfTaxResidence,AcknowledgmentNumber,AttachmentFiles/FileName,AttachmentFiles/ServerRelativeUrl", "VendorMasterId,VendorCode,VendorName,AttachmentFiles", "VendorCode/VendorCode eq '".concat(vendorCode, "'"), { column: "ID", isAscending: true }, 5000, props)
                        .then(function (res) {
                        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z;
                        var dates = [];
                        var permanent = res.find(function (item) { return item.DeclarationType === "Permanent Establishment"; });
                        if (permanent) {
                            var endDate = (_a = permanent.ValidityEndDate) === null || _a === void 0 ? void 0 : _a.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setPermanentEstablishmentDeclaration({
                                DocumentAvailable: permanent.DocumentAvailable || "",
                                DocumentNumber: permanent.DocumentNumber || "",
                                DocumentDate: ((_b = permanent.DocumentDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                SEPClause: permanent.SEPClause || "",
                                ValidityStartDate: ((_c = permanent.ValidityStartDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                ValidityEndDate: ((_d = permanent.ValidityEndDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "",
                                Attachmenturl: ((_f = (_e = permanent.AttachmentFiles) === null || _e === void 0 ? void 0 : _e[0]) === null || _f === void 0 ? void 0 : _f.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_h = (_g = permanent.AttachmentFiles) === null || _g === void 0 ? void 0 : _g[0]) === null || _h === void 0 ? void 0 : _h.FileName) || ""
                            });
                        }
                        var taxRes = res.find(function (item) { return item.DeclarationType === "TAX Residency Certificate"; });
                        if (taxRes) {
                            var endDate = (_j = permanent.ValidityEndDate) === null || _j === void 0 ? void 0 : _j.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setTaxResidencyCertificate({
                                DocumentAvailable: taxRes.DocumentAvailable || "",
                                DocumentNumber: taxRes.DocumentNumber || "",
                                DocumentDate: ((_k = taxRes.DocumentDate) === null || _k === void 0 ? void 0 : _k.split("T")[0]) || "",
                                ValidityStartDate: ((_l = taxRes.ValidityStartDate) === null || _l === void 0 ? void 0 : _l.split("T")[0]) || "",
                                ValidityEndDate: ((_m = taxRes.ValidityEndDate) === null || _m === void 0 ? void 0 : _m.split("T")[0]) || "",
                                TaxIdentificationNumber: taxRes.TaxIdentificationNumber || "",
                                CountryOfTaxResidence: taxRes.CountryOfTaxResidence || "",
                                Attachmenturl: ((_p = (_o = taxRes.AttachmentFiles) === null || _o === void 0 ? void 0 : _o[0]) === null || _p === void 0 ? void 0 : _p.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_r = (_q = taxRes.AttachmentFiles) === null || _q === void 0 ? void 0 : _q[0]) === null || _r === void 0 ? void 0 : _r.FileName) || ""
                            });
                        }
                        // ✅ Form 10F
                        var form10 = res.find(function (item) { return item.DeclarationType === "Form 10 F"; });
                        if (form10) {
                            var endDate = (_s = permanent.ValidityEndDate) === null || _s === void 0 ? void 0 : _s.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setForm10F({
                                DocumentAvailable: form10.DocumentAvailable || "",
                                DocumentNumber: form10.DocumentNumber || "",
                                DocumentDate: ((_t = form10.DocumentDate) === null || _t === void 0 ? void 0 : _t.split("T")[0]) || "",
                                ValidityStartDate: ((_u = form10.ValidityStartDate) === null || _u === void 0 ? void 0 : _u.split("T")[0]) || "",
                                ValidityEndDate: ((_v = form10.ValidityEndDate) === null || _v === void 0 ? void 0 : _v.split("T")[0]) || "",
                                AcknowledgmentNumber: form10.AcknowledgmentNumber || "",
                                Attachmenturl: ((_x = (_w = form10.AttachmentFiles) === null || _w === void 0 ? void 0 : _w[0]) === null || _x === void 0 ? void 0 : _x.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_z = (_y = form10.AttachmentFiles) === null || _y === void 0 ? void 0 : _y[0]) === null || _z === void 0 ? void 0 : _z.FileName) || ""
                            });
                        }
                        if (dates.length > 0) {
                            var minDate = dates.sort()[0]; // YYYY-MM-DD format works for sorting
                            setToDate(minDate); // store in state
                        }
                    })
                        .catch(function (error) {
                        console.error("Error fetching tax declaration data:", error);
                    });
                    return [2 /*return*/];
            }
        });
    }); };
    var getFinancialYearStart = function () {
        var today = new Date();
        var year = today.getFullYear();
        var month = today.getMonth(); // 0 = Jan
        var fyStartYear = month < 3 ? year - 1 : year;
        setFromDate("".concat(fyStartYear, "-04-01"));
    };
    return (react_1.default.createElement("div", { className: "forex-wrapper" },
        react_1.default.createElement("div", { className: "forex-header" },
            react_1.default.createElement("h2", null, "Forex Payment View Form")),
        react_1.default.createElement("div", { className: "forex-card" },
            react_1.default.createElement(Section, { title: "Approval Flow" },
                react_1.default.createElement("div", { className: "approval-ribbon" },
                    react_1.default.createElement("div", { className: "ribbon-step initiator" }, employee.EmployeeName),
                    approverDetails.map(function (approver, index) {
                        var stepClass = approver.Status || "pending";
                        return (react_1.default.createElement("div", { key: index, className: "ribbon-step ".concat(stepClass) },
                            approver.Role,
                            " - ",
                            approver.Name));
                    }))),
            react_1.default.createElement(Section, { title: "Requestor Information" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Type" },
                        react_1.default.createElement("select", { value: paymentType, onChange: function (e) { return setPaymentType(e.target.value); }, disabled: true },
                            react_1.default.createElement("option", { value: "Goods-Bill Payment" }, "Goods-Bill Payment"),
                            react_1.default.createElement("option", { value: "Service-Bill Payment" }, "Service-Bill Payment"),
                            react_1.default.createElement("option", { value: "Goods-Advance Payment" }, "Goods-Advance Payment"),
                            react_1.default.createElement("option", { value: "Service-Advance Payment" }, "Service-Advance Payment")))),
                react_1.default.createElement(Grid, { style: { marginTop: "20px" } },
                    react_1.default.createElement(Field, { label: "Employee Code" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Name" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Division" },
                        react_1.default.createElement("input", { type: "text", value: employee.Division, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Location" },
                        react_1.default.createElement("input", { type: "text", value: employee.Location, readOnly: true })),
                    react_1.default.createElement(Field, { label: "RM" },
                        react_1.default.createElement("input", { type: "text", value: employee.RM, readOnly: true })),
                    react_1.default.createElement(Field, { label: "HOD" },
                        react_1.default.createElement("input", { type: "text", value: employee.HOD, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Contact No" },
                        react_1.default.createElement("input", { type: "text", value: employee.ContactNo, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Status" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeStatus, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Email", full: true },
                        react_1.default.createElement("input", { type: "email", value: employee.Email, readOnly: true })))),
            react_1.default.createElement(CollapsibleSection, { title: "Vendor / Beneficiary Details" },
                react_1.default.createElement(Section, null,
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Vendor Code" },
                            react_1.default.createElement("input", { value: vendor.VendorCode, onChange: function (e) {
                                    var code = e.target.value;
                                    setVendor(tslib_1.__assign(tslib_1.__assign({}, vendor), { VendorCode: code }));
                                }, onBlur: function (e) { return getVendorData(e.target.value); }, disabled: true })),
                        react_1.default.createElement(Field, { label: "Vendor Name" },
                            react_1.default.createElement("input", { value: vendor.VendorName, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Address", full: true },
                            react_1.default.createElement("input", { value: vendor.VendorAddress, readOnly: true })),
                        react_1.default.createElement(Field, { label: "City" },
                            react_1.default.createElement("input", { value: vendor.City, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Country" },
                            react_1.default.createElement("input", { value: vendor.Country, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Pincode" },
                            react_1.default.createElement("input", { value: vendor.PostalCode, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank Name" },
                            react_1.default.createElement("input", { value: vendor.BankName, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank Country" },
                            react_1.default.createElement("input", { value: vendor.BankCountry, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank Swift Code" },
                            react_1.default.createElement("input", { value: vendor.SWIFTBICCode, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank Branch Address" },
                            react_1.default.createElement("input", { value: vendor.BankAddress, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank IBAN / Account No", full: true },
                            react_1.default.createElement("input", { value: vendor.AccountNumberIBAN, readOnly: true })))),
                react_1.default.createElement(Section, { title: "Tax & Regulatory Information" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Nature of Payment" },
                            react_1.default.createElement("input", { value: paymentType, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Tax Document Available?" },
                            react_1.default.createElement("select", { onChange: function (e) { setTaxDocumentView(e.target.value); }, disabled: true },
                                react_1.default.createElement("option", null, "Yes"),
                                react_1.default.createElement("option", null, "No"))),
                        taxDocumentView === "No" && (react_1.default.createElement(Field, null,
                            react_1.default.createElement("span", { style: { color: "red" } }, "(if No, withholding tax will be applicable)"))),
                        taxDocumentView === "Yes" && (react_1.default.createElement(Field, { label: "DTAA Applicable?" },
                            react_1.default.createElement("select", { value: dTAAApplicable, onChange: function (e) { return setDTAAApplicable(e.target.value); }, disabled: true },
                                react_1.default.createElement("option", { value: "" }, "Select"),
                                react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                react_1.default.createElement("option", { value: "No" }, "No")))))),
                taxDocumentView === "Yes" && (react_1.default.createElement(react_1.default.Fragment, null,
                    react_1.default.createElement(Section, { title: "Permanent Establishment Declaration" },
                        react_1.default.createElement(Grid, null,
                            react_1.default.createElement(Field, { label: "Document Available" },
                                react_1.default.createElement("select", { value: permanentEstablishmentDeclaration.DocumentAvailable || "", disabled: true },
                                    react_1.default.createElement("option", { value: "" }, "Select"),
                                    react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                    react_1.default.createElement("option", { value: "No" }, "No"))),
                            react_1.default.createElement(Field, { label: "Document Number" },
                                react_1.default.createElement("input", { value: permanentEstablishmentDeclaration.DocumentNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Document Date" },
                                react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.DocumentDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity Start Date" },
                                react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.ValidityStartDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity End Date" },
                                react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.ValidityEndDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "View Document" },
                                react_1.default.createElement("span", null,
                                    react_1.default.createElement("a", { href: permanentEstablishmentDeclaration.Attachmenturl || "#", target: "_blank" }, permanentEstablishmentDeclaration.Attachmentfilename || "No Document Available"))))),
                    react_1.default.createElement(Section, { title: "Tax Residency Certificate" },
                        react_1.default.createElement(Grid, null,
                            react_1.default.createElement(Field, { label: "Document Available" },
                                react_1.default.createElement("select", { value: taxResidencyCertificate.DocumentAvailable || "", disabled: true },
                                    react_1.default.createElement("option", { value: "" }, "Select"),
                                    react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                    react_1.default.createElement("option", { value: "No" }, "No"))),
                            react_1.default.createElement(Field, { label: "Document Number" },
                                react_1.default.createElement("input", { value: taxResidencyCertificate.DocumentNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Country of Tax Residence" },
                                react_1.default.createElement("input", { value: taxResidencyCertificate.CountryOfTaxResidence || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Tax Identification Number" },
                                react_1.default.createElement("input", { value: taxResidencyCertificate.TaxIdentificationNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity Start Date" },
                                react_1.default.createElement("input", { type: "date", value: taxResidencyCertificate.ValidityStartDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity End Date" },
                                react_1.default.createElement("input", { type: "date", value: taxResidencyCertificate.ValidityEndDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "View Document" },
                                react_1.default.createElement("span", null,
                                    react_1.default.createElement("a", { href: taxResidencyCertificate.Attachmenturl || "#", target: "_blank" }, taxResidencyCertificate.Attachmentfilename || "No Document Available"))))),
                    react_1.default.createElement(Section, { title: "Form 10F" },
                        react_1.default.createElement(Grid, null,
                            react_1.default.createElement(Field, { label: "Document Available" },
                                react_1.default.createElement("select", { value: form10F.DocumentAvailable || "", disabled: true },
                                    react_1.default.createElement("option", { value: "" }, "Select"),
                                    react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                    react_1.default.createElement("option", { value: "No" }, "No"))),
                            react_1.default.createElement(Field, { label: "Document Number" },
                                react_1.default.createElement("input", { value: form10F.DocumentNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Acknowledgment Number" },
                                react_1.default.createElement("input", { value: form10F.AcknowledgmentNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Document Date" },
                                react_1.default.createElement("input", { type: "date", value: form10F.DocumentDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity Start Date" },
                                react_1.default.createElement("input", { type: "date", value: form10F.ValidityStartDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity End Date" },
                                react_1.default.createElement("input", { type: "date", value: form10F.ValidityEndDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "View Document" },
                                react_1.default.createElement("span", null,
                                    react_1.default.createElement("a", { href: form10F.Attachmenturl || "#", target: "_blank" }, form10F.Attachmentfilename || "No Document Available")))))))),
            react_1.default.createElement(CollapsibleSection, { title: "Summary of WHT Applicability" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement("div", { className: "date-summary" },
                        react_1.default.createElement("span", { className: "label" }, "From"),
                        react_1.default.createElement("span", { className: "value" }, fromdate),
                        react_1.default.createElement("span", { className: "label" }, "To"),
                        react_1.default.createElement("span", { className: "value" }, todate))),
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Eligible amount that can be transmitted without WHT" },
                        react_1.default.createElement("input", { type: "number", value: eligibleAmountWithWHT || "", readOnly: true })),
                    react_1.default.createElement(Field, { label: "Paid Amount" },
                        react_1.default.createElement("input", { type: "number", value: paidAmount || "", readOnly: true })),
                    react_1.default.createElement(Field, { label: "Balance eligible amount(Without with holding Tax)" },
                        react_1.default.createElement("input", { type: "number", value: ballenceEligibleAmount || "", readOnly: true })))),
            paymentType === "Goods-Bill Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, onChange: function (e) { setCurrency(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { type: "number", value: totalAmount, onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { type: "text", value: foreignBankCharges, readOnly: true }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr.No"),
                            react_1.default.createElement("th", null, "Invoice No"),
                            react_1.default.createElement("th", null, "Invoice Date"),
                            react_1.default.createElement("th", null, "BOE No"),
                            react_1.default.createElement("th", null, "BOE Date"),
                            react_1.default.createElement("th", null, "MRN No"),
                            react_1.default.createElement("th", null, "Bill of Lading No"),
                            react_1.default.createElement("th", null, "Bill of Lading Date"),
                            react_1.default.createElement("th", null, "Invoice Amount"),
                            react_1.default.createElement("th", null, "Attach Invoice"),
                            react_1.default.createElement("th", null, "Attach Other Docs"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.boeNo, onChange: function (e) {
                                        return handleChange(index, "boeNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.boeDate, onChange: function (e) {
                                        return handleChange(index, "boeDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.mrnNo, onChange: function (e) {
                                        return handleChange(index, "mrnNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.blNo, onChange: function (e) {
                                        return handleChange(index, "blNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.blDate, onChange: function (e) {
                                        return handleChange(index, "blDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "number", value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_a = invoiceAttachments[index]) === null || _a === void 0 ? void 0 : _a.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); }))),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_b = otherAttachments[index]) === null || _b === void 0 ? void 0 : _b.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); })))));
                    }))),
                react_1.default.createElement("div", { style: { display: "flex", gap: "40px", marginTop: "30px" } },
                    react_1.default.createElement("div", { style: { flex: 1 } },
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "13px" } }, "Unique BOE no will be listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "BOE No"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBoeNumbers.map(function (boe, index) { return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, boe),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("div", null, boeLibraryFiles
                                        .filter(function (file) { return file.BOENo === boe; })
                                        .map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.FileRef, target: "_blank" }, file.FileLeafRef))); })),
                                    "                                                "))); })))),
                    react_1.default.createElement("div", { style: { flex: 1 } },
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "13px" } }, "Unique Bill of lading no will be listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "Bill of Lading Number"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBlNumbers.map(function (bl, index) { return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, bl),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("div", null, bolLibraryFiles
                                        .filter(function (file) { return file.BOLNo === bl; })
                                        .map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.FileRef, target: "_blank" }, file.FileLeafRef))); })),
                                    "                                                "))); }))))))),
            paymentType === "Service-Bill Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, onChange: function (e) { setCurrency(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { type: "number", value: totalAmount, onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { type: "text", value: foreignBankCharges, onChange: function (e) { setForeignBankCharges(e.target.value); }, readOnly: true }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null, "Invoice No"),
                            react_1.default.createElement("th", null, "Invoice Date"),
                            react_1.default.createElement("th", null, "Invoice Amount"),
                            react_1.default.createElement("th", null, "MRN No"),
                            react_1.default.createElement("th", null, "MRN Date"),
                            react_1.default.createElement("th", null, "Attach Invoice"),
                            react_1.default.createElement("th", null, "Attach Other Document"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.mrnNo, onChange: function (e) {
                                        return handleChange(index, "mrnNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.mrnDate, onChange: function (e) {
                                        return handleChange(index, "mrnDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null, (_a = invoiceAttachments[index]) === null || _a === void 0 ? void 0 : _a.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); })),
                            react_1.default.createElement("td", null, (_b = otherAttachments[index]) === null || _b === void 0 ? void 0 : _b.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); }))));
                    }))))),
            paymentType === "Service-Advance Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, onChange: function (e) { setCurrency(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { type: "number", value: totalAmount, onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { type: "text", value: foreignBankCharges, onChange: function (e) { setForeignBankCharges(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "PO/Contract No" },
                        react_1.default.createElement("input", { value: poContractNo, onChange: function (e) { setPoContractNo(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "PO Date" },
                        react_1.default.createElement("input", { type: "date", value: poDate, onChange: function (e) { setPoDate(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Expected Settlement Date" },
                        react_1.default.createElement("input", { type: "date", value: expectedSettlementDate, onChange: function (e) { setExpectedSettlementDate(e.target.value); }, readOnly: true }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null, "Performa Invoice No"),
                            react_1.default.createElement("th", null, "Performa Invoice Date"),
                            react_1.default.createElement("th", null, "Performa Invoice Amount"),
                            react_1.default.createElement("th", null, "Attach PO"),
                            react_1.default.createElement("th", null, "Attach PI"),
                            react_1.default.createElement("th", null, "Attach Other Document"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b, _c;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_a = poAttachments[index]) === null || _a === void 0 ? void 0 : _a.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); }))),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_b = piAttachments[index]) === null || _b === void 0 ? void 0 : _b.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); }))),
                            react_1.default.createElement("td", null, (_c = otherAttachments[index]) === null || _c === void 0 ? void 0 : _c.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); }))));
                    }))))),
            paymentType === "Goods-Advance Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, onChange: function (e) { setCurrency(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { type: "number", value: totalAmount, onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { type: "text", value: foreignBankCharges, onChange: function (e) { setForeignBankCharges(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "PO/Contract No" },
                        react_1.default.createElement("input", { value: poContractNo, onChange: function (e) { setPoContractNo(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "PO Date" },
                        react_1.default.createElement("input", { type: "date", value: poDate, onChange: function (e) { setPoDate(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Expected Settlement Date" },
                        react_1.default.createElement("input", { type: "date", value: expectedSettlementDate, onChange: function (e) { setExpectedSettlementDate(e.target.value); }, readOnly: true }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null, "Performa Invoice No"),
                            react_1.default.createElement("th", null, "Performa Invoice Date"),
                            react_1.default.createElement("th", null, "Performa Invoice Amount"),
                            react_1.default.createElement("th", null, "Attach PO"),
                            react_1.default.createElement("th", null, "Attach PI"),
                            react_1.default.createElement("th", null, "Attach Other Document"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b, _c;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_a = poAttachments[index]) === null || _a === void 0 ? void 0 : _a.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); }))),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_b = piAttachments[index]) === null || _b === void 0 ? void 0 : _b.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); }))),
                            react_1.default.createElement("td", null, (_c = otherAttachments[index]) === null || _c === void 0 ? void 0 : _c.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName))); }))));
                    }))))),
            paymentType === "Goods-Advance Payment" && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(Section, { title: "Bill Payment Details (For Goods Bill Payment)" },
                    react_1.default.createElement("table", { className: "data-table" },
                        react_1.default.createElement("thead", null,
                            react_1.default.createElement("tr", null,
                                react_1.default.createElement("th", null, "Sr.No."),
                                react_1.default.createElement("th", null, "Invoice Number"),
                                react_1.default.createElement("th", null, "Invoice Date"),
                                react_1.default.createElement("th", null, "BOE Number"),
                                react_1.default.createElement("th", null, "BOE Date"),
                                react_1.default.createElement("th", null, "MRN Number"),
                                react_1.default.createElement("th", null, "Bill of Lading Number"),
                                react_1.default.createElement("th", null, "Bill of Lading Date"),
                                react_1.default.createElement("th", null, "Invoice Amount"),
                                react_1.default.createElement("th", null, "Attach Invoice"),
                                react_1.default.createElement("th", null, "Attach Other"))),
                        react_1.default.createElement("tbody", null, rowsAdvance.map(function (row, index) {
                            var _a, _b;
                            return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, index + 1),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.invoiceNo)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.invoiceDate)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.boeNo)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.boeDate)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.mrnNo)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.blNo)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.blDate)),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("span", null, row.invoiceAmount)),
                                react_1.default.createElement("td", null, ((_a = poAttachmentsTrackeradvance[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (poAttachmentsTrackeradvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, download: true, target: "_blank", rel: "noopener noreferrer", className: "upload-link" },
                                        "\uD83D\uDCE5 ",
                                        file.FileName || file.name))); })) : (react_1.default.createElement("span", null, "-"))),
                                react_1.default.createElement("td", null, ((_b = piAttachmentsTrackeradvance[index]) === null || _b === void 0 ? void 0 : _b.length) > 0 ? (piAttachmentsTrackeradvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, download: true, target: "_blank", rel: "noopener noreferrer", className: "upload-link" },
                                        "\uD83D\uDCE5 ",
                                        file.FileName || file.name))); })) : (react_1.default.createElement("span", null, "-")))));
                        })))),
                react_1.default.createElement("div", { style: { display: "flex", gap: "40px", marginTop: "20px" } },
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "BOE No"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBoeNumbersadvancetracker.map(function (boe, index) {
                                var _a;
                                return (react_1.default.createElement("tr", { key: index },
                                    react_1.default.createElement("td", null, boe),
                                    react_1.default.createElement("td", null, ((_a = boeAttachmentstrackeradvance[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (boeAttachmentstrackeradvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i, style: { fontSize: "12px" } },
                                        react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", download: true, rel: "noopener noreferrer", className: "upload-link" },
                                            "\uD83D\uDCC4 ",
                                            file.FileName))); })) : (react_1.default.createElement("span", null, "-")))));
                            })))),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "Bill of Lading"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBlNumbersadvancetracker.map(function (bl, index) {
                                var _a;
                                return (react_1.default.createElement("tr", { key: index },
                                    react_1.default.createElement("td", null, bl),
                                    react_1.default.createElement("td", null, ((_a = blAttachmentstrackeradvance[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (blAttachmentstrackeradvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i, style: { fontSize: "12px" } },
                                        react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", download: true, rel: "noopener noreferrer", className: "upload-link" },
                                            "\uD83D\uDCC4 ",
                                            file.FileName))); })) : (react_1.default.createElement("span", null, "-")))));
                            }))))))),
            paymentType === "Service-Advance Payment" && (react_1.default.createElement("div", { style: { marginTop: "30px" } },
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Bill Payment Details (for Service Bill Payment)")),
                react_1.default.createElement("table", { className: "data-table" },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr.No."),
                            react_1.default.createElement("th", null, "Invoice Number"),
                            react_1.default.createElement("th", null, "Invoice Date"),
                            react_1.default.createElement("th", null, "Invoice Amount"),
                            react_1.default.createElement("th", null, "MRN Number"),
                            react_1.default.createElement("th", null, "MRN Date"),
                            react_1.default.createElement("th", null, "Invoice Document"),
                            react_1.default.createElement("th", null, "Other Document"))),
                    react_1.default.createElement("tbody", null, rowsAdvance.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.invoiceNo)),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.invoiceDate)),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.invoiceAmount)),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.mrnNo)),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("span", null, row.mrnDate)),
                            react_1.default.createElement("td", null, ((_a = poAttachmentsTrackeradvance[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (poAttachmentsTrackeradvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                react_1.default.createElement("a", { href: file.ServerRelativeUrl, download: true, target: "_blank", rel: "noopener noreferrer", className: "upload-link" },
                                    "\uD83D\uDCE5 ",
                                    file.FileName || file.name))); })) : (react_1.default.createElement("span", null, "-"))),
                            react_1.default.createElement("td", null, ((_b = piAttachmentsTrackeradvance[index]) === null || _b === void 0 ? void 0 : _b.length) > 0 ? (piAttachmentsTrackeradvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                react_1.default.createElement("a", { href: file.ServerRelativeUrl, download: true, target: "_blank", rel: "noopener noreferrer", className: "upload-link" },
                                    "\uD83D\uDCE5 ",
                                    file.FileName || file.name))); })) : (react_1.default.createElement("span", null, "-")))));
                    }))))),
            react_1.default.createElement(Section, { title: "Vouching Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Validation Date", required: true },
                        react_1.default.createElement("input", { type: "text", value: validationDateshow, 
                            // onChange={(e) => setValidationDate(e.target.value)}
                            readOnly: true })),
                    (paymentType.includes("Advance")) && (react_1.default.createElement(Field, { label: "Voucher Number", required: true },
                        react_1.default.createElement("input", { value: voucherNumbershow }))))),
            react_1.default.createElement(Section, { title: "Payment Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Foreign Currency", required: true },
                        react_1.default.createElement("input", { type: "text", value: foreignCurrency, readOnly: true, style: { marginTop: "5px" } })),
                    react_1.default.createElement(Field, { label: "Foreign Currency Amount", required: true },
                        react_1.default.createElement("input", { type: "number", value: foreignAmountpayment, 
                            // onChange={(e) => setForeignAmount(e.target.value)}
                            readOnly: true })),
                    react_1.default.createElement(Field, { label: "Exchange Rate", required: true },
                        react_1.default.createElement("input", { type: "number", value: exchangeRatepayment, 
                            // onChange={(e) => setExchangeRate(e.target.value)}
                            readOnly: true })),
                    react_1.default.createElement(Field, { label: "INR Amount", required: true },
                        react_1.default.createElement("input", { type: "number", value: inrAmountpayment, 
                            // onChange={(e) => setInrAmount(e.target.value)}
                            readOnly: true }))),
                react_1.default.createElement("p", { style: { color: "red", fontSize: "12px" } }, "(if difference in foreign currency & Amount system to display alert message only)"),
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Payment Date" },
                        react_1.default.createElement("input", { type: "date", value: paymentDatepayment, 
                            // onChange={(e) => setPaymentDate(e.target.value)}
                            readOnly: true })),
                    react_1.default.createElement(Field, { label: "Payment reference number" },
                        react_1.default.createElement("input", { value: paymentReferencepayment, 
                            // onChange={(e) => setPaymentReference(e.target.value)}
                            readOnly: true })),
                    isServicePayment && (react_1.default.createElement(Field, { label: "Form145", required: true }, form15CA.length > 0 && (react_1.default.createElement("div", { style: { marginTop: "10px" } }, form15CA.map(function (file, index) { return (react_1.default.createElement("div", { key: index, style: {
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: "5px",
                            padding: "6px 10px",
                            border: "1px solid #ddd",
                            borderRadius: "4px",
                        } },
                        react_1.default.createElement("span", null, file.name))); }))))),
                    isServicePayment && (react_1.default.createElement(Field, { label: "Form146 ", required: true }, form15CB.length > 0 && (react_1.default.createElement("div", { style: { marginTop: "10px" } }, form15CB.map(function (file, index) { return (react_1.default.createElement("div", { key: index, style: {
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: "5px",
                            padding: "6px 10px",
                            border: "1px solid #ddd",
                            borderRadius: "4px",
                        } },
                        react_1.default.createElement("span", null, file.name))); })))))),
                react_1.default.createElement(Grid, null, isGoodsPayment && (react_1.default.createElement(Field, { label: "Attach Swift Copy (Applicable for Goods)", required: true }, swiftCopy.length > 0 && (react_1.default.createElement("div", { style: { marginTop: "10px" } }, swiftCopy.map(function (file, index) { return (react_1.default.createElement("div", { key: index, style: {
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        marginBottom: "5px",
                        padding: "6px 10px",
                        border: "1px solid #ddd",
                        borderRadius: "4px",
                    } },
                    react_1.default.createElement("span", null, file.name))); }))))))),
            react_1.default.createElement(CollapsibleSection, { title: "Workflow History" }, workflowHistory.length > 0 ? (react_1.default.createElement("table", { className: "data-table" },
                react_1.default.createElement("thead", null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("th", null, "Action By"),
                        react_1.default.createElement("th", null, "Action"),
                        react_1.default.createElement("th", null, "Remark"),
                        react_1.default.createElement("th", null, "Date"))),
                react_1.default.createElement("tbody", null, workflowHistory.map(function (item, index) { return (react_1.default.createElement("tr", { key: index },
                    react_1.default.createElement("td", null, item.CurrentApprover),
                    react_1.default.createElement("td", null, item.ActionTaken),
                    react_1.default.createElement("td", null, item.Comment || "-"),
                    react_1.default.createElement("td", null, item.Date
                        ? new Date(item.Date).toLocaleString("en-GB")
                        : ""))); })))) : (react_1.default.createElement("p", null, "No workflow history available"))),
            react_1.default.createElement("div", { className: "button-row" },
                react_1.default.createElement("button", { className: "btn-exit", onClick: function () { return history.push("/"); } }, "Exit"))),
        showVendorPopup && (react_1.default.createElement("div", { className: "popup-overlay" },
            react_1.default.createElement("div", { className: "popup-box" },
                react_1.default.createElement("h3", null, "Vendor Not Found"),
                react_1.default.createElement("p", null, "Please add vendor first."),
                react_1.default.createElement("div", { style: { marginTop: "20px", display: "flex", gap: "10px", justifyContent: "center" } },
                    react_1.default.createElement("button", { className: "btn-submit", onClick: function () {
                            setShowVendorPopup(false);
                            history.push("/vendor-creation");
                        } }, "Go to Vendor Creation")))))));
};
exports.default = ViewRequestForm;
//# sourceMappingURL=NewRequestViewForm.js.map