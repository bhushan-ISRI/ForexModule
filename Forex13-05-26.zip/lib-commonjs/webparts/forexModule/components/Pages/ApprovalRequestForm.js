"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
require("../Pages/Css/NewRequest.scss");
var react_router_dom_1 = require("react-router-dom");
var react_2 = require("@fluentui/react");
var spcrud_1 = tslib_1.__importDefault(require("../../service/BAL/spcrud"));
var all_1 = require("@pnp/sp/presets/all");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/attachments");
var sp_http_1 = require("@microsoft/sp-http");
/* Helper Components */
var Section = function (_a) {
    var title = _a.title, children = _a.children;
    return (react_1.default.createElement("div", { className: "form-section" },
        react_1.default.createElement("h3", null, title),
        children));
};
var Grid = function (_a) {
    var children = _a.children;
    return (react_1.default.createElement("div", { className: "form-grid" }, children));
};
// const Field = ({ label, children, full }: any) => (
//     <div className={full ? "form-field full" : "form-field"}>
//         <label>{label}</label>
//         {children}
//     </div>
// );
var CollapsibleSection = function (_a) {
    var title = _a.title, children = _a.children;
    var _b = react_1.default.useState(false), open = _b[0], setOpen = _b[1];
    return (react_1.default.createElement("div", { className: "form-section collapsible" },
        react_1.default.createElement("div", { className: "form-section-header", onClick: function () { return setOpen(!open); } },
            react_1.default.createElement("span", null, title),
            react_1.default.createElement("i", { className: "fas fa-chevron-".concat(open ? "up" : "down") })),
        open && (react_1.default.createElement("div", { className: "form-section-body" }, children))));
};
var Field = function (_a) {
    var label = _a.label, children = _a.children, full = _a.full, required = _a.required;
    return (react_1.default.createElement("div", { className: full ? "form-field full" : "form-field" },
        react_1.default.createElement("label", null,
            label,
            required && react_1.default.createElement("span", { className: "required-star" }, "*")),
        children));
};
var ApprovalRequestForm = function (props) {
    var Id = (0, react_router_dom_1.useParams)().Id;
    var history = (0, react_router_dom_1.useHistory)();
    var spCrudOps = (0, spcrud_1.default)();
    var _a = (0, react_1.useState)("Goods-Bill Payment"), paymentType = _a[0], setPaymentType = _a[1];
    var _b = (0, react_1.useState)("Yes"), taxDocumentView = _b[0], setTaxDocumentView = _b[1];
    var _c = (0, react_1.useState)(), paymenttypeDropdownValue = _c[0], setPaymentTypeDropdownValue = _c[1];
    var _d = (0, react_1.useState)(""), fromdate = _d[0], setFromDate = _d[1];
    var _e = (0, react_1.useState)(""), todate = _e[0], setToDate = _e[1];
    var _f = (0, react_1.useState)(""), dTAAApplicable = _f[0], setDTAAApplicable = _f[1];
    var _g = react_1.default.useState(false), showVendorPopup = _g[0], setShowVendorPopup = _g[1];
    var _h = (0, react_1.useState)(""), bankaccountno = _h[0], setBankAccountNo = _h[1];
    var _j = (0, react_1.useState)(""), bankname = _j[0], setBankName = _j[1];
    var _k = (0, react_1.useState)(""), bankswiftcode = _k[0], setBankSwiftCode = _k[1];
    var _l = (0, react_1.useState)(""), remarks = _l[0], setRemarks = _l[1];
    var _m = (0, react_1.useState)(""), requestNumber = _m[0], setRequestNumber = _m[1];
    var _o = (0, react_1.useState)(""), requestedOn = _o[0], setRequestedOn = _o[1];
    var _p = (0, react_1.useState)(""), currency = _p[0], setCurrency = _p[1];
    var _q = (0, react_1.useState)(""), totalAmount = _q[0], setTotalAmount = _q[1];
    var _r = (0, react_1.useState)(""), foreignBankCharges = _r[0], setForeignBankCharges = _r[1];
    var _s = (0, react_1.useState)(""), poContractNo = _s[0], setPoContractNo = _s[1];
    var _t = (0, react_1.useState)(""), poDate = _t[0], setPoDate = _t[1];
    var _u = (0, react_1.useState)(""), expectedSettlementDate = _u[0], setExpectedSettlementDate = _u[1];
    var _v = (0, react_1.useState)([]), nextApprovers = _v[0], setNextApprovers = _v[1];
    var _w = (0, react_1.useState)([]), currentApprover = _w[0], setCurrentApprover = _w[1];
    var currentUserId = props.context.pageContext.legacyPageContext.userId;
    var _x = (0, react_1.useState)({}), invoiceAttachments = _x[0], setInvoiceAttachments = _x[1];
    var _y = (0, react_1.useState)({}), otherAttachments = _y[0], setOtherAttachments = _y[1];
    var _z = (0, react_1.useState)({}), poAttachments = _z[0], setPoAttachments = _z[1];
    var _0 = (0, react_1.useState)({}), piAttachments = _0[0], setPiAttachments = _0[1];
    var _1 = (0, react_1.useState)([]), boeLibraryFiles = _1[0], setBoeLibraryFiles = _1[1];
    var _2 = (0, react_1.useState)([]), bolLibraryFiles = _2[0], setBolLibraryFiles = _2[1];
    var _3 = (0, react_1.useState)([]), approvalSteps = _3[0], setApprovalSteps = _3[1];
    var _4 = (0, react_1.useState)([]), prevApprovers = _4[0], setPrevApprovers = _4[1];
    var _5 = (0, react_1.useState)([]), allApprovers = _5[0], setAllApprovers = _5[1];
    var _6 = (0, react_1.useState)(""), approverRemarks = _6[0], setApproverRemarks = _6[1];
    var _7 = (0, react_1.useState)(""), validationDate = _7[0], setValidationDate = _7[1];
    var _8 = (0, react_1.useState)(""), voucherNumber = _8[0], setVoucherNumber = _8[1];
    var _9 = (0, react_1.useState)(""), vouchingRemarks = _9[0], setVouchingRemarks = _9[1];
    var _10 = (0, react_1.useState)(""), treasuryRemarks = _10[0], setTreasuryRemarks = _10[1];
    var _11 = (0, react_1.useState)(""), currentRole = _11[0], setCurrentRole = _11[1];
    var _12 = (0, react_1.useState)(""), foreignCurrency = _12[0], setForeignCurrency = _12[1];
    var _13 = (0, react_1.useState)(""), foreignAmount = _13[0], setForeignAmount = _13[1];
    var _14 = (0, react_1.useState)(""), exchangeRate = _14[0], setExchangeRate = _14[1];
    var _15 = (0, react_1.useState)(""), inrAmount = _15[0], setInrAmount = _15[1];
    var _16 = (0, react_1.useState)(""), paymentDate = _16[0], setPaymentDate = _16[1];
    var _17 = (0, react_1.useState)(""), paymentReference = _17[0], setPaymentReference = _17[1];
    var _18 = (0, react_1.useState)([]), swiftCopy = _18[0], setSwiftCopy = _18[1];
    var removeSwiftCopyFile = function (index) {
        setSwiftCopy(function (prev) { return prev.filter(function (_, i) { return i !== index; }); });
    };
    var _19 = (0, react_1.useState)([]), form15CA = _19[0], setForm15CA = _19[1];
    var _20 = (0, react_1.useState)([]), form15CB = _20[0], setForm15CB = _20[1];
    var _21 = (0, react_1.useState)(""), allApproversJson = _21[0], setAllApproversJson = _21[1];
    var _22 = (0, react_1.useState)([]), workflowHistory = _22[0], setWorkflowHistory = _22[1];
    var _23 = (0, react_1.useState)(""), eligibleAmountWithWHT = _23[0], setEligibleAmountWithWHT = _23[1];
    var _24 = (0, react_1.useState)(""), paidAmount = _24[0], setPaidAmount = _24[1];
    var _25 = (0, react_1.useState)(""), validationDateshow = _25[0], setValidationDateshow = _25[1];
    var _26 = (0, react_1.useState)(""), voucherNumbershow = _26[0], setVoucherNumbershow = _26[1];
    var _27 = (0, react_1.useState)(""), ballenceEligibleAmount = _27[0], setBallenceEligibleAmount = _27[1];
    var _28 = (0, react_1.useState)([]), foreignCurrencyOptions = _28[0], setforeignCurrencyOptions = _28[1];
    var _29 = (0, react_1.useState)(false), actionLoading = _29[0], setActionLoading = _29[1];
    var _30 = react_1.default.useState({
        EmployeeCode: "",
        EmployeeName: "",
        Division: "",
        Location: "",
        RM: "",
        HOD: "",
        ContactNo: "",
        EmployeeStatus: "",
        Email: "",
        RMId: 0,
        HODId: 0
    }), employee = _30[0], setEmployee = _30[1];
    var _31 = react_1.default.useState({
        VendorCode: "",
        VendorName: "",
        VendorNameLegal: "",
        VendorShortName: "",
        VendorType: "",
        City: "",
        State: "",
        Country: "",
        Currency: "",
        PostalCode: "",
        ContactPersonName: "",
        EmailId: "",
        PhoneNumber: "",
        AlternateContact: "",
        BeneficiaryName: "",
        BankName: "",
        AccountNumberIBAN: "",
        SWIFTBICCode: "",
        RoutingNumberABA: "",
        IFSCCode: "",
        IntermediaryBank: "",
        IntermediarySWIFTCode: "",
        NatureOfPayment: "",
        PurposeCodeRBI: "",
        BankCountry: "",
        BankAddress: "",
        VendorAddress: ""
    }), vendor = _31[0], setVendor = _31[1];
    var _32 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        SEPClause: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), permanentEstablishmentDeclaration = _32[0], setPermanentEstablishmentDeclaration = _32[1];
    var _33 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        TaxIdentificationNumber: "",
        CountryOfTaxResidence: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), taxResidencyCertificate = _33[0], setTaxResidencyCertificate = _33[1];
    var _34 = (0, react_1.useState)({
        DocumentAvailable: "",
        DocumentNumber: "",
        DocumentDate: "",
        ValidityStartDate: "",
        ValidityEndDate: "",
        AcknowledgmentNumber: "",
        Attachmenturl: "",
        Attachmentfilename: ""
    }), form10F = _34[0], setForm10F = _34[1];
    var _35 = react_1.default.useState([
        {
            invoiceNo: "",
            invoiceDate: "",
            boeNo: "",
            boeDate: "",
            mrnNo: "",
            blNo: "",
            blDate: "",
            invoiceAmount: "",
            mrnDate: "" // Added for Service-Bill Payment
        }
    ]), rows = _35[0], setRows = _35[1];
    var remove15CAFile = function (index) {
        setForm15CA(function (prev) { return prev.filter(function (_, i) { return i !== index; }); });
    };
    var remove15CBFile = function (index) {
        setForm15CB(function (prev) { return prev.filter(function (_, i) { return i !== index; }); });
    };
    var addRow = function () {
        setRows(tslib_1.__spreadArray(tslib_1.__spreadArray([], rows, true), [
            {
                invoiceNo: "",
                invoiceDate: "",
                boeNo: "",
                boeDate: "",
                mrnNo: "",
                blNo: "",
                blDate: "",
                invoiceAmount: "",
                mrnDate: "" // Added for Service-Bill Payment
            }
        ], false));
    };
    var deleteRow = function (index) {
        var updatedRows = rows.filter(function (_, i) { return i !== index; });
        setRows(updatedRows);
    };
    var handleChange = function (index, field, value) {
        var updatedRows = tslib_1.__spreadArray([], rows, true);
        updatedRows[index][field] = value;
        setRows(updatedRows);
    };
    var totalInvoiceAmount = rows.reduce(function (sum, row) {
        return sum + (parseFloat(row.invoiceAmount) || 0);
    }, 0);
    var uniqueBoeNumbers = rows
        .map(function (r) { return r.boeNo; })
        .filter(function (value, index, self) {
        return value && self.indexOf(value) === index;
    });
    var uniqueBlNumbers = rows
        .map(function (r) { return r.blNo; })
        .filter(function (value, index, self) {
        return value && self.indexOf(value) === index;
    });
    (0, react_1.useEffect)(function () {
        all_1.sp.setup({
            spfxContext: props.context
        });
    }, []);
    (0, react_1.useEffect)(function () {
        getFinancialYearStart();
        getCurrencyData();
        if (Id) {
            loadForexData(Id);
        }
    }, [Id]);
    //----------------------- load data for edit------------------------//
    var loadForexData = function (forexId) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, parent_1, data_1, parsed, ids, approvers_1, current, steps_1, approvers, parsed, child, formattedRows, invoiceMap_1, otherMap_1, poMap_1, piMap_1, bolFiles, boeFiles, error_1;
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
        return tslib_1.__generator(this, function (_l) {
            switch (_l.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _l.sent();
                    _l.label = 2;
                case 2:
                    _l.trys.push([2, 7, , 8]);
                    return [4 /*yield*/, sp.getData("ForexRequest", "*,AllApprovers,RM/Title,HOD/Title,RM/Id,HOD/Id,Author/Id,Currency/Title,Currency/Id,NextApprovers/Id,NextApprovers/Title,CurrentApprover/Id,CurrentApprover/Title,PrevApprovers/Id,PrevApprovers/Title", "RM,HOD,Author,Currency,NextApprovers,CurrentApprover,PrevApprovers", "ID eq ".concat(forexId), { column: "ID", isAscending: true }, 1, props)];
                case 3:
                    parent_1 = _l.sent();
                    if (parent_1.length > 0) {
                        data_1 = parent_1[0];
                        setPaymentType(data_1.ForexType || "");
                        setRequestNumber(data_1.ForexNumber || "");
                        setRequestedOn(((_a = data_1.RequestedOn) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "");
                        setCurrency(((_b = data_1.Currency) === null || _b === void 0 ? void 0 : _b.Title) || "");
                        setTotalAmount(data_1.TotalAmount || "");
                        setForeignBankCharges(data_1.ForeignBankCharges || "");
                        setPoContractNo(data_1.poContractNo || "");
                        setPoDate(((_c = data_1.poDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "");
                        setExpectedSettlementDate(((_d = data_1.expectedSettlementDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "");
                        setBankName(data_1.BankName || "");
                        setBankAccountNo(data_1.BankAccNo || "");
                        setRemarks(data_1.Remarks || "");
                        setDTAAApplicable(data_1.DTAAApplicable || "");
                        setTaxDocumentView(data_1.DocumentIsAvailable || "");
                        setBankSwiftCode(data_1.BankSwiftCode || "");
                        setNextApprovers(((_e = data_1.NextApprovers) === null || _e === void 0 ? void 0 : _e.map(function (approver) { return approver.Id; })) || []);
                        setEligibleAmountWithWHT(data_1.EligibleAmountWithWHT || "");
                        setPaidAmount(data_1.PaidAmount || "");
                        setBallenceEligibleAmount(data_1.BallenceEligibleAmount || "");
                        setVoucherNumbershow(data_1.VoucherNumber || "");
                        setValidationDateshow(data_1.ValidationDate ? data_1.ValidationDate.split("T")[0] : "");
                        if (data_1.AllApprovers) {
                            setAllApproversJson(data_1.AllApprovers);
                            parsed = JSON.parse(data_1.AllApprovers);
                            ids = parsed.map(function (a) { return a.Id; });
                            setAllApprovers(ids);
                        }
                        setVendor(tslib_1.__assign(tslib_1.__assign({}, vendor), { VendorCode: data_1.VendorCode, VendorName: data_1.VendorName }));
                        setEmployee({
                            EmployeeCode: data_1.EmployeeCode || "",
                            EmployeeName: data_1.EmployeeName || "",
                            Division: data_1.Division || "",
                            Location: data_1.Location || "",
                            RM: ((_f = data_1.RM) === null || _f === void 0 ? void 0 : _f.Title) || "",
                            HOD: ((_g = data_1.HOD) === null || _g === void 0 ? void 0 : _g.Title) || "",
                            ContactNo: data_1.ContactNo || "",
                            EmployeeStatus: data_1.EmployeeStatus || "",
                            Email: data_1.Email || "",
                            RMId: ((_h = data_1.RM) === null || _h === void 0 ? void 0 : _h.Id) || 0,
                            HODId: ((_j = data_1.HOD) === null || _j === void 0 ? void 0 : _j.Id) || 0
                        });
                        getVendorData(data_1.VendorCode);
                        setCurrentApprover(data_1.CurrentApprover ? [data_1.CurrentApprover.Id] : []);
                        if (data_1.AllApprovers) {
                            approvers_1 = JSON.parse(data_1.AllApprovers);
                            current = approvers_1.find(function (a) { var _a; return a.Id === ((_a = data_1.CurrentApprover) === null || _a === void 0 ? void 0 : _a.Id); });
                            if (current) {
                                setCurrentRole(current.Role);
                            }
                        }
                        setPrevApprovers(((_k = data_1.PrevApprovers) === null || _k === void 0 ? void 0 : _k.map(function (p) { return p.Id; })) || []);
                        steps_1 = [];
                        steps_1.push({
                            name: data_1.EmployeeName,
                            status: "initiator"
                        });
                        approvers = [];
                        if (data_1.AllApprovers) {
                            approvers = JSON.parse(data_1.AllApprovers);
                        }
                        approvers.forEach(function (a) {
                            var _a;
                            var status = "pending";
                            if (a.Status === "Approved") {
                                status = "approved";
                            }
                            else if (((_a = data_1.CurrentApprover) === null || _a === void 0 ? void 0 : _a.Id) === a.Id) {
                                status = "current";
                            }
                            steps_1.push({
                                id: a.Id,
                                name: "".concat(a.Role, " - ").concat(a.Name),
                                status: status
                            });
                        });
                        setApprovalSteps(steps_1);
                        if (data_1.WorkFlowHistory) {
                            try {
                                parsed = JSON.parse(data_1.WorkFlowHistory);
                                setWorkflowHistory(parsed);
                            }
                            catch (_m) {
                                setWorkflowHistory([]);
                            }
                        }
                    }
                    return [4 /*yield*/, sp.getData("ForexServicesBillPayment", "*,AttachmentFiles", "AttachmentFiles", "ForexIDId eq ".concat(forexId), { column: "ID", isAscending: true }, 5000, props)];
                case 4:
                    child = _l.sent();
                    if (child.length > 0) {
                        formattedRows = child.map(function (item) {
                            var _a, _b, _c, _d;
                            return ({
                                invoiceNo: item.InvoiceNumber || "",
                                invoiceDate: ((_a = item.InvoiceDate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "",
                                invoiceAmount: item.InvoiceAmount || "",
                                mrnNo: item.MRNNumber || "",
                                mrnDate: ((_b = item.MRNDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                blNo: item.BillofLandingNo || "",
                                blDate: ((_c = item.BillOfLandingdate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                boeNo: item.BOENo || "",
                                boeDate: ((_d = item.BOEDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || ""
                            });
                        });
                        setRows(formattedRows);
                        invoiceMap_1 = {};
                        otherMap_1 = {};
                        poMap_1 = {};
                        piMap_1 = {};
                        child.forEach(function (item, index) {
                            var allFiles = item.AttachmentFiles || [];
                            invoiceMap_1[index] = allFiles.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("INV_"); });
                            otherMap_1[index] = allFiles.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("DOC_"); });
                            poMap_1[index] = allFiles.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PO_"); });
                            piMap_1[index] = allFiles.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PI_"); });
                        });
                        setInvoiceAttachments(invoiceMap_1);
                        setOtherAttachments(otherMap_1);
                        setPoAttachments(poMap_1);
                        setPiAttachments(piMap_1);
                    }
                    return [4 /*yield*/, sp.getData("BillOfLandingAttachment", "FileLeafRef,FileRef,BOLNo,ReqeuestId", "", "ReqeuestId eq '".concat(Id, "'"), { column: "ID", isAscending: true }, 5000, props)];
                case 5:
                    bolFiles = _l.sent();
                    return [4 /*yield*/, sp.getData("BOEAttachments", "FileLeafRef,FileRef,BOENo,ReqeuestId", "", "ReqeuestId eq '".concat(Id, "'"), { column: "ID", isAscending: true }, 5000, props)];
                case 6:
                    boeFiles = _l.sent();
                    setBoeLibraryFiles(boeFiles);
                    setBolLibraryFiles(bolFiles);
                    return [3 /*break*/, 8];
                case 7:
                    error_1 = _l.sent();
                    console.error("Error loading edit data:", error_1);
                    return [3 /*break*/, 8];
                case 8: return [2 /*return*/];
            }
        });
    }); };
    //----------------------VendorData-------------------------//
    var getVendorData = function (vendorCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!vendorCode)
                        return [2 /*return*/];
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    (_a.sent()).getData("VendorMaster", "VendorCode,VendorName,VendorNameLegal,VendorShortName,VendorType,City/Title,State/Title,Country/Title,Currency/Title,PostalCode,ContactPersonName,EmailId,PhoneNumber,AlternateContact,BeneficiaryName,BankName,AccountNumberIBAN,SWIFTBICCode,RoutingNumberABA,IFSCCode,IntermediaryBank,IntermediarySWIFTCode,NatureOfPayment/Title,PurposeCodeRBI,BankCountry,BankAddress,VendorAddress", "NatureOfPayment,City,State,Country,Currency", "VendorCode eq '".concat(vendorCode, "'"), { column: "ID", isAscending: true }, 1, props)
                        .then(function (res) {
                        var _a, _b, _c, _d, _e;
                        if (res.length > 0) {
                            var v = res[0];
                            setVendor({
                                VendorCode: v.VendorCode || "",
                                VendorName: v.VendorName || "",
                                VendorNameLegal: v.VendorNameLegal || "",
                                VendorShortName: v.VendorShortName || "",
                                VendorType: v.VendorType || "",
                                City: ((_a = v.City) === null || _a === void 0 ? void 0 : _a.Title) || "",
                                State: ((_b = v.State) === null || _b === void 0 ? void 0 : _b.Title) || "",
                                Country: ((_c = v.Country) === null || _c === void 0 ? void 0 : _c.Title) || "",
                                Currency: ((_d = v.Currency) === null || _d === void 0 ? void 0 : _d.Title) || "",
                                PostalCode: v.PostalCode || "",
                                ContactPersonName: v.ContactPersonName || "",
                                EmailId: v.EmailId || "",
                                PhoneNumber: v.PhoneNumber || "",
                                AlternateContact: v.AlternateContact || "",
                                BeneficiaryName: v.BeneficiaryName || "",
                                BankName: v.BankName || "",
                                AccountNumberIBAN: v.AccountNumberIBAN || "",
                                SWIFTBICCode: v.SWIFTBICCode || "",
                                RoutingNumberABA: v.RoutingNumberABA || "",
                                IFSCCode: v.IFSCCode || "",
                                IntermediaryBank: v.IntermediaryBank || "",
                                IntermediarySWIFTCode: v.IntermediarySWIFTCode || "",
                                NatureOfPayment: ((_e = v.NatureOfPayment) === null || _e === void 0 ? void 0 : _e.Title) || "",
                                PurposeCodeRBI: v.PurposeCodeRBI || "",
                                BankAddress: v.BankAddress || "",
                                BankCountry: v.BankCountry || "",
                                VendorAddress: v.VendorAddress || ""
                            });
                            getTaxDeclarationdata(v.VendorCode);
                        }
                        else {
                            //alert("Vendor not found");
                            setShowVendorPopup(true);
                        }
                    })
                        .catch(function (error) {
                        console.error("Error fetching vendor data:", error);
                    });
                    return [2 /*return*/];
            }
        });
    }); };
    var getTaxDeclarationdata = function (vendorCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!vendorCode)
                        return [2 /*return*/];
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    (_a.sent()).getData("VendorTaxDeclaration", "VendorMasterId/ID,VendorCode/VendorCode,VendorName/VendorName,DeclarationType,DocumentAvailable,DocumentNumber,DocumentDate,SEPClause,ValidityStartDate,ValidityEndDate,TaxIdentificationNumber,CountryOfTaxResidence,AcknowledgmentNumber,AttachmentFiles/FileName,AttachmentFiles/ServerRelativeUrl", "VendorMasterId,VendorCode,VendorName,AttachmentFiles", "VendorCode/VendorCode eq '".concat(vendorCode, "'"), { column: "ID", isAscending: true }, 5000, props)
                        .then(function (res) {
                        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z;
                        var dates = [];
                        var permanent = res.find(function (item) { return item.DeclarationType === "Permanent Establishment"; });
                        if (permanent) {
                            var endDate = (_a = permanent.ValidityEndDate) === null || _a === void 0 ? void 0 : _a.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setPermanentEstablishmentDeclaration({
                                DocumentAvailable: permanent.DocumentAvailable || "",
                                DocumentNumber: permanent.DocumentNumber || "",
                                DocumentDate: ((_b = permanent.DocumentDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                SEPClause: permanent.SEPClause || "",
                                ValidityStartDate: ((_c = permanent.ValidityStartDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                ValidityEndDate: ((_d = permanent.ValidityEndDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "",
                                Attachmenturl: ((_f = (_e = permanent.AttachmentFiles) === null || _e === void 0 ? void 0 : _e[0]) === null || _f === void 0 ? void 0 : _f.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_h = (_g = permanent.AttachmentFiles) === null || _g === void 0 ? void 0 : _g[0]) === null || _h === void 0 ? void 0 : _h.FileName) || ""
                            });
                        }
                        var taxRes = res.find(function (item) { return item.DeclarationType === "TAX Residency Certificate"; });
                        if (taxRes) {
                            var endDate = (_j = permanent.ValidityEndDate) === null || _j === void 0 ? void 0 : _j.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setTaxResidencyCertificate({
                                DocumentAvailable: taxRes.DocumentAvailable || "",
                                DocumentNumber: taxRes.DocumentNumber || "",
                                DocumentDate: ((_k = taxRes.DocumentDate) === null || _k === void 0 ? void 0 : _k.split("T")[0]) || "",
                                ValidityStartDate: ((_l = taxRes.ValidityStartDate) === null || _l === void 0 ? void 0 : _l.split("T")[0]) || "",
                                ValidityEndDate: ((_m = taxRes.ValidityEndDate) === null || _m === void 0 ? void 0 : _m.split("T")[0]) || "",
                                TaxIdentificationNumber: taxRes.TaxIdentificationNumber || "",
                                CountryOfTaxResidence: taxRes.CountryOfTaxResidence || "",
                                Attachmenturl: ((_p = (_o = taxRes.AttachmentFiles) === null || _o === void 0 ? void 0 : _o[0]) === null || _p === void 0 ? void 0 : _p.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_r = (_q = taxRes.AttachmentFiles) === null || _q === void 0 ? void 0 : _q[0]) === null || _r === void 0 ? void 0 : _r.FileName) || ""
                            });
                        }
                        // ✅ Form 10F
                        var form10 = res.find(function (item) { return item.DeclarationType === "Form 10 F"; });
                        if (form10) {
                            var endDate = (_s = permanent.ValidityEndDate) === null || _s === void 0 ? void 0 : _s.split("T")[0];
                            if (endDate)
                                dates.push(endDate);
                            setForm10F({
                                DocumentAvailable: form10.DocumentAvailable || "",
                                DocumentNumber: form10.DocumentNumber || "",
                                DocumentDate: ((_t = form10.DocumentDate) === null || _t === void 0 ? void 0 : _t.split("T")[0]) || "",
                                ValidityStartDate: ((_u = form10.ValidityStartDate) === null || _u === void 0 ? void 0 : _u.split("T")[0]) || "",
                                ValidityEndDate: ((_v = form10.ValidityEndDate) === null || _v === void 0 ? void 0 : _v.split("T")[0]) || "",
                                AcknowledgmentNumber: form10.AcknowledgmentNumber || "",
                                Attachmenturl: ((_x = (_w = form10.AttachmentFiles) === null || _w === void 0 ? void 0 : _w[0]) === null || _x === void 0 ? void 0 : _x.ServerRelativeUrl) || "",
                                Attachmentfilename: ((_z = (_y = form10.AttachmentFiles) === null || _y === void 0 ? void 0 : _y[0]) === null || _z === void 0 ? void 0 : _z.FileName) || ""
                            });
                        }
                        if (dates.length > 0) {
                            var minDate = dates.sort()[0]; // YYYY-MM-DD format works for sorting
                            setToDate(minDate); // store in state
                        }
                    })
                        .catch(function (error) {
                        console.error("Error fetching tax declaration data:", error);
                    });
                    return [2 /*return*/];
            }
        });
    }); };
    var getFinancialYearStart = function () {
        var today = new Date();
        var year = today.getFullYear();
        var month = today.getMonth(); // 0 = Jan
        var fyStartYear = month < 3 ? year - 1 : year;
        setFromDate("".concat(fyStartYear, "-04-01"));
    };
    var getApproversdata = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var Sp, res, categoryOrder_1, sorted, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    Sp = _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, Sp.getData("ForexApprovalMAtrix", "ID,Approver/Id,Approver/Title,Level,Title", "Approver", "", { column: "Level", isAscending: true }, 5000, props)];
                case 3:
                    res = _a.sent();
                    if (!res || res.length === 0) {
                        console.error("No approvers found in matrix");
                        return [2 /*return*/, []];
                    }
                    categoryOrder_1 = ["Approver", "VouchingApprover", "TreasuryTeam"];
                    sorted = res.sort(function (a, b) {
                        var catDiff = categoryOrder_1.indexOf(a.Level) -
                            categoryOrder_1.indexOf(b.Level);
                        if (catDiff !== 0)
                            return catDiff;
                        return a.Level - b.Level;
                    });
                    // 🔹 Return only user IDs
                    return [2 /*return*/, sorted.map(function (item) { var _a; return (_a = item.Approver) === null || _a === void 0 ? void 0 : _a.Id; })];
                case 4:
                    error_2 = _a.sent();
                    console.error("Error fetching approval matrix:", error_2);
                    return [2 /*return*/, []];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var validateAndBuildApprovers = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, approvers, requestTypeFilter, matrix;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    approvers = [];
                    // RM
                    if (employee.RMId) {
                        approvers.push({
                            Id: employee.RMId,
                            Name: employee.RM,
                            Role: "RM",
                            Level: 1
                        });
                    }
                    // HOD
                    if (employee.HODId) {
                        approvers.push({
                            Id: employee.HODId,
                            Name: employee.HOD,
                            Role: "HOD",
                            Level: 2
                        });
                    }
                    requestTypeFilter = "";
                    if (paymentType === "Goods-Advance Payment" ||
                        paymentType === "Service-Advance Payment") {
                        requestTypeFilter = "Advance Payment";
                    }
                    else {
                        requestTypeFilter = paymentType; // direct match for Bill types
                    }
                    return [4 /*yield*/, sp.getData("ForexApprovalMatrix", "Title,Role,Approver/Id,Approver/Title,Level,RequestType", "Approver", "RequestType eq '".concat(requestTypeFilter, "' and Status eq 'Active'"), { column: "Level", isAscending: true }, 5000, props)];
                case 2:
                    matrix = _a.sent();
                    matrix.forEach(function (item) {
                        var _a, _b;
                        var id = (_a = item.Approver) === null || _a === void 0 ? void 0 : _a.Id;
                        if (!approvers.find(function (a) { return a.Id === id; })) {
                            approvers.push({
                                Id: id,
                                Name: (_b = item.Approver) === null || _b === void 0 ? void 0 : _b.Title,
                                Role: item.Role,
                                Level: item.Level
                            });
                        }
                    });
                    return [2 /*return*/, approvers];
            }
        });
    }); };
    var getCurrencyData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp_1, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    sp_1 = _a.sent();
                    return [4 /*yield*/, sp_1.getData("Currency", "Title,Id", "", "", { column: "Title", isAscending: true }, 5000, props).then(function (res) {
                            var options = res.map(function (c) { return ({
                                key: c.Title,
                                text: c.Title
                            }); });
                            setforeignCurrencyOptions(options);
                        })];
                case 2:
                    _a.sent();
                    return [3 /*break*/, 4];
                case 3:
                    error_3 = _a.sent();
                    console.error("Error fetching currency data:", error_3);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var isServicePayment = paymentType.includes("Service");
    var isGoodsPayment = paymentType.includes("Goods");
    var onsubmit = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, correctApproversObjects, existingApprovers_1, approvers, currentIndex, currentApproverObj, nextApprover, status_1, existingItem, existingHistory, remarksPayload, finalRemark, updatedHistory, webUrl, _i, swiftCopy_1, file, fileName, _a, form15CA_1, file, fileName, _b, form15CB_1, file, fileName, error_4;
        return tslib_1.__generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    if (actionLoading)
                        return [2 /*return*/];
                    setActionLoading(true);
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _c.sent();
                    _c.label = 2;
                case 2:
                    _c.trys.push([2, 18, , 19]);
                    return [4 /*yield*/, validateAndBuildApprovers()];
                case 3:
                    correctApproversObjects = _c.sent();
                    if (!correctApproversObjects.length) {
                        alert("Approval matrix not configured");
                        return [2 /*return*/];
                    }
                    existingApprovers_1 = [];
                    if (allApproversJson) {
                        existingApprovers_1 = JSON.parse(allApproversJson);
                    }
                    approvers = correctApproversObjects.map(function (newAppr) {
                        var existing = existingApprovers_1.find(function (a) { return a.Id === newAppr.Id; });
                        return existing
                            ? existing
                            : tslib_1.__assign(tslib_1.__assign({}, newAppr), { Status: "", ActionDate: "", Remarks: "" });
                    });
                    currentIndex = approvers.findIndex(function (a) { return a.Id === currentUserId; });
                    if (currentIndex === -1) {
                        alert("You are not authorized to approve");
                        return [2 /*return*/];
                    }
                    currentApproverObj = approvers[currentIndex];
                    // ⭐ Update current approver
                    approvers[currentIndex].Status = "Approved";
                    approvers[currentIndex].ActionDate = new Date().toISOString();
                    approvers[currentIndex].Remarks = approverRemarks;
                    nextApprover = currentIndex + 1 < approvers.length
                        ? approvers[currentIndex + 1]
                        : null;
                    if (nextApprover && !nextApprover.Status) {
                        nextApprover.Status = "Pending";
                    }
                    status_1 = "Approved";
                    if (nextApprover) {
                        if (nextApprover.Role === "HOD")
                            status_1 = "Pending for HOD Approval";
                        else if (nextApprover.Role === "Vouching")
                            status_1 = "Pending for Vouching";
                        else if (nextApprover.Role === "TreasuryVerification")
                            status_1 = "Pending for Treasury Verification";
                        else if (nextApprover.Role === "TreasuryPayment")
                            status_1 = "Pending for Payment";
                    }
                    else {
                        // Final approver logic
                        if (currentApproverObj.Role === "TreasuryPayment" && paymentType.includes("Advance")) {
                            status_1 = "Paid";
                        }
                        else {
                            status_1 = "Paid & Closed";
                        }
                    }
                    return [4 /*yield*/, sp.getData("ForexRequest", "WorkFlowHistory", "", "ID eq ".concat(Id), { column: "ID", isAscending: true }, 1, props)];
                case 4:
                    existingItem = _c.sent();
                    existingHistory = [];
                    if (existingItem.length > 0 && existingItem[0].WorkFlowHistory) {
                        try {
                            existingHistory = JSON.parse(existingItem[0].WorkFlowHistory);
                        }
                        catch (_d) {
                            existingHistory = [];
                        }
                    }
                    remarksPayload = {};
                    finalRemark = "";
                    if (currentApproverObj.Role === "RM" || currentApproverObj.Role === "HOD") {
                        if (!approverRemarks || approverRemarks.trim() === "") {
                            alert("Please enter remark before approving");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = approverRemarks;
                    }
                    else if (currentApproverObj.Role === "Vouching") {
                        if (!vouchingRemarks || vouchingRemarks.trim() === "") {
                            alert("Please enter vouching remark");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = vouchingRemarks;
                    }
                    else if (currentApproverObj.Role === "TreasuryVerification") {
                        if (!treasuryRemarks || treasuryRemarks.trim() === "") {
                            alert("Please enter treasury remark");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = treasuryRemarks;
                    }
                    else if (currentApproverObj.Role === "TreasuryPayment") {
                        if (!paymentReference || paymentReference.trim() === "") {
                            alert("Please enter payment reference");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        //finalRemark = paymentReference; // or treasuryRemarks if you want
                    }
                    updatedHistory = tslib_1.__spreadArray([], existingHistory, true);
                    updatedHistory.push({
                        CurrentApprover: currentApproverObj.Name,
                        ActionTaken: "Approved",
                        Comment: finalRemark,
                        Date: new Date().toISOString(),
                        CurrentStatus: status_1
                    });
                    if (currentApproverObj.Role === "RM") {
                        remarksPayload.RMRemark = approverRemarks;
                    }
                    if (currentApproverObj.Role === "HOD") {
                        remarksPayload.HODRemarks = approverRemarks;
                    }
                    if (currentApproverObj.Role === "Vouching") {
                        remarksPayload.ValidationDate = validationDate;
                        remarksPayload.VoucherNumber = voucherNumber;
                        remarksPayload.VouchingRemarks = vouchingRemarks;
                        if (!validationDate) {
                            alert("Please enter validation date");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (paymentType.includes("Advance")) {
                            if (!voucherNumber || voucherNumber.trim() === "") {
                                alert("Please enter voucher number");
                                setActionLoading(false);
                                return [2 /*return*/];
                            }
                        }
                    }
                    if (currentApproverObj.Role === "TreasuryVerification") {
                        remarksPayload.TreasuryRemark = treasuryRemarks;
                    }
                    if (currentApproverObj.Role === "TreasuryPayment") {
                        if (!foreignCurrency) {
                            alert("Please select foreign currency");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (!foreignAmount || isNaN(Number(foreignAmount))) {
                            alert("Please enter a valid foreign amount");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (!exchangeRate || isNaN(Number(exchangeRate))) {
                            alert("Please enter a valid exchange rate");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (!inrAmount || isNaN(Number(inrAmount))) {
                            alert("Please enter a valid INR amount");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (!paymentDate) {
                            alert("Please enter payment date");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (!paymentReference || paymentReference.trim() === "") {
                            alert("Please enter payment reference");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (!isGoodsPayment && (form15CA.length <= 0)) {
                            alert("Please attach Form145 ");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (!isGoodsPayment && (form15CB.length <= 0)) {
                            alert("Please attach Form146 ");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        if (isGoodsPayment && (swiftCopy.length <= 0)) {
                            alert("Please attach SWIFT copy");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        remarksPayload.ForeignCurrency = foreignCurrency;
                        remarksPayload.ForeignCurrencyAmount = foreignAmount;
                        remarksPayload.ExchangeRate = exchangeRate;
                        remarksPayload.INRAmount = inrAmount;
                        remarksPayload.PaymentDate = paymentDate;
                        remarksPayload.PaymentReferenceNumber = paymentReference;
                    }
                    if (!(currentApproverObj.Role === "TreasuryPayment")) return [3 /*break*/, 16];
                    webUrl = props.context.pageContext.web.absoluteUrl;
                    if (!(swiftCopy.length > 0)) return [3 /*break*/, 8];
                    _i = 0, swiftCopy_1 = swiftCopy;
                    _c.label = 5;
                case 5:
                    if (!(_i < swiftCopy_1.length)) return [3 /*break*/, 8];
                    file = swiftCopy_1[_i];
                    fileName = "SwiftCopy_".concat(file.name);
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexRequest')/items(").concat(Id, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, {
                            body: file
                        })];
                case 6:
                    _c.sent();
                    _c.label = 7;
                case 7:
                    _i++;
                    return [3 /*break*/, 5];
                case 8:
                    if (!(form15CA.length > 0)) return [3 /*break*/, 12];
                    _a = 0, form15CA_1 = form15CA;
                    _c.label = 9;
                case 9:
                    if (!(_a < form15CA_1.length)) return [3 /*break*/, 12];
                    file = form15CA_1[_a];
                    fileName = "15CA_".concat(file.name);
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexRequest')/items(").concat(Id, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, {
                            body: file
                        })];
                case 10:
                    _c.sent();
                    _c.label = 11;
                case 11:
                    _a++;
                    return [3 /*break*/, 9];
                case 12:
                    if (!(form15CB.length > 0)) return [3 /*break*/, 16];
                    _b = 0, form15CB_1 = form15CB;
                    _c.label = 13;
                case 13:
                    if (!(_b < form15CB_1.length)) return [3 /*break*/, 16];
                    file = form15CB_1[_b];
                    fileName = "15CB_".concat(file.name);
                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('ForexRequest')/items(").concat(Id, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, {
                            body: file
                        })];
                case 14:
                    _c.sent();
                    _c.label = 15;
                case 15:
                    _b++;
                    return [3 /*break*/, 13];
                case 16: 
                // ⭐ Update SharePoint
                return [4 /*yield*/, sp.updateData("ForexRequest", Number(Id), tslib_1.__assign({ AllApprovers: JSON.stringify(approvers), WorkFlowHistory: JSON.stringify(updatedHistory), CurrentApproverId: nextApprover ? nextApprover.Id : null, Status: status_1 }, remarksPayload), props)];
                case 17:
                    // ⭐ Update SharePoint
                    _c.sent();
                    if (currentApproverObj.Role === "Vouching") {
                        alert("Request has been vouched");
                    }
                    else if (currentApproverObj.Role === "TreasuryVerification") {
                        alert("Request has been verified");
                    }
                    else if (currentApproverObj.Role === "TreasuryPayment") {
                        alert("Request has been processed successfully");
                    }
                    else {
                        alert("Request has been approved successfully");
                    }
                    history.push("/ApprovalDashboard");
                    return [3 /*break*/, 19];
                case 18:
                    error_4 = _c.sent();
                    console.error(error_4);
                    alert("Approval failed");
                    setActionLoading(false);
                    return [3 /*break*/, 19];
                case 19: return [2 /*return*/];
            }
        });
    }); };
    var onReject = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, correctApproversObjects, approvers, currentIndex, currentApproverObj, existingItem, existingHistory, finalRemark, updatedHistory, error_5;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (actionLoading)
                        return [2 /*return*/];
                    setActionLoading(true);
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 6, , 7]);
                    return [4 /*yield*/, validateAndBuildApprovers()];
                case 3:
                    correctApproversObjects = _a.sent();
                    approvers = correctApproversObjects;
                    currentIndex = approvers.findIndex(function (a) { return a.Id === currentUserId; });
                    if (currentIndex === -1) {
                        alert("You are not authorized");
                        setActionLoading(false);
                        return [2 /*return*/];
                    }
                    currentApproverObj = approvers[currentIndex];
                    return [4 /*yield*/, sp.getData("ForexRequest", "WorkFlowHistory", "", "ID eq ".concat(Id), { column: "ID", isAscending: true }, 1, props)];
                case 4:
                    existingItem = _a.sent();
                    existingHistory = [];
                    if (existingItem.length > 0 && existingItem[0].WorkFlowHistory) {
                        try {
                            existingHistory = JSON.parse(existingItem[0].WorkFlowHistory);
                        }
                        catch (_b) {
                            existingHistory = [];
                        }
                    }
                    finalRemark = "";
                    if (currentApproverObj.Role === "RM" || currentApproverObj.Role === "HOD") {
                        if (!approverRemarks || approverRemarks.trim() === "") {
                            alert("Please enter remark before approving");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = approverRemarks;
                    }
                    else if (currentApproverObj.Role === "Vouching") {
                        if (!vouchingRemarks || vouchingRemarks.trim() === "") {
                            alert("Please enter vouching remark");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = vouchingRemarks;
                    }
                    else if (currentApproverObj.Role === "TreasuryVerification") {
                        if (!treasuryRemarks || treasuryRemarks.trim() === "") {
                            alert("Please enter treasury remark");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = treasuryRemarks;
                    }
                    else if (currentApproverObj.Role === "TreasuryPayment") {
                        // if (!paymentReference || paymentReference.trim() === "") {
                        //     alert("Please enter payment reference");
                        //     setActionLoading(false);
                        //     return;
                        // }
                        // finalRemark = paymentReference; // or treasuryRemarks if you want
                    }
                    approvers[currentIndex].Status = "Rejected";
                    approvers[currentIndex].ActionDate = new Date().toISOString();
                    approvers[currentIndex].Remarks = finalRemark;
                    updatedHistory = tslib_1.__spreadArray([], existingHistory, true);
                    updatedHistory.push({
                        CurrentApprover: approvers[currentIndex].Name,
                        ActionTaken: "Rejected",
                        Comment: finalRemark,
                        Date: new Date().toISOString(),
                        CurrentStatus: "Rejected"
                    });
                    // let updatedHistory = [...existingHistory];
                    // updatedHistory.push({
                    //     CurrentApprover: approvers[currentIndex].Name,
                    //     ActionTaken: "Rejected",
                    //     Comment: approverRemarks,
                    //     Date: new Date().toISOString(),
                    //     CurrentStatus: "Rejected"
                    // });
                    return [4 /*yield*/, sp.updateData("ForexRequest", Number(Id), {
                            AllApprovers: JSON.stringify(approvers),
                            WorkFlowHistory: JSON.stringify(updatedHistory),
                            CurrentApproverId: null,
                            Status: "Rejected"
                        }, props)];
                case 5:
                    // let updatedHistory = [...existingHistory];
                    // updatedHistory.push({
                    //     CurrentApprover: approvers[currentIndex].Name,
                    //     ActionTaken: "Rejected",
                    //     Comment: approverRemarks,
                    //     Date: new Date().toISOString(),
                    //     CurrentStatus: "Rejected"
                    // });
                    _a.sent();
                    alert("Request has been rejected by Approver");
                    history.push("/ApprovalDashboard");
                    return [3 /*break*/, 7];
                case 6:
                    error_5 = _a.sent();
                    console.error(error_5);
                    alert("Sent back failed");
                    setActionLoading(false);
                    return [3 /*break*/, 7];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    var onSentBack = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, existingItem, approvers, currentIndex, currentApproverObj, previousApprover, finalRemark, existingHistory, error_6;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (actionLoading)
                        return [2 /*return*/];
                    setActionLoading(true);
                    return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 5, , 6]);
                    return [4 /*yield*/, sp.getData("ForexRequest", "AllApprovers,WorkFlowHistory", "", "ID eq ".concat(Id), { column: "ID", isAscending: true }, 1, props)];
                case 3:
                    existingItem = _a.sent();
                    if (!existingItem.length) {
                        alert("Item not found");
                        return [2 /*return*/];
                    }
                    approvers = [];
                    if (existingItem[0].AllApprovers) {
                        approvers = JSON.parse(existingItem[0].AllApprovers);
                    }
                    currentIndex = approvers.findIndex(function (a) { return a.Id === currentUserId; });
                    if (currentIndex === -1) {
                        alert("You are not authorized");
                        setActionLoading(false);
                        return [2 /*return*/];
                    }
                    currentApproverObj = approvers[currentIndex];
                    previousApprover = currentIndex - 1 >= 0 ? approvers[currentIndex - 1] : null;
                    if (previousApprover) {
                        previousApprover.Status = "Pending";
                    }
                    finalRemark = "";
                    if (currentApproverObj.Role === "RM" || currentApproverObj.Role === "HOD") {
                        if (!approverRemarks || approverRemarks.trim() === "") {
                            alert("Please enter remark before approving");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = approverRemarks;
                    }
                    else if (currentApproverObj.Role === "Vouching") {
                        if (!vouchingRemarks || vouchingRemarks.trim() === "") {
                            alert("Please enter vouching remark");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = vouchingRemarks;
                    }
                    else if (currentApproverObj.Role === "TreasuryVerification") {
                        if (!treasuryRemarks || treasuryRemarks.trim() === "") {
                            alert("Please enter treasury remark");
                            setActionLoading(false);
                            return [2 /*return*/];
                        }
                        finalRemark = treasuryRemarks;
                    }
                    // 🔹 6. Workflow History
                    approvers[currentIndex].Status = "Sent Back";
                    approvers[currentIndex].ActionDate = new Date().toISOString();
                    approvers[currentIndex].Remarks = finalRemark;
                    existingHistory = [];
                    if (existingItem[0].WorkFlowHistory) {
                        try {
                            existingHistory = JSON.parse(existingItem[0].WorkFlowHistory);
                        }
                        catch (_b) {
                            existingHistory = [];
                        }
                    }
                    existingHistory.push({
                        CurrentApprover: currentApproverObj.Name,
                        ActionTaken: "Sent Back",
                        Comment: finalRemark,
                        Date: new Date().toISOString(),
                        CurrentStatus: "Sent Back"
                    });
                    // 🔹 7. Update SharePoint
                    return [4 /*yield*/, sp.updateData("ForexRequest", Number(Id), {
                            AllApprovers: JSON.stringify(approvers),
                            WorkFlowHistory: JSON.stringify(existingHistory),
                            CurrentApproverId: previousApprover ? previousApprover.Id : null,
                            Status: "Sent Back"
                        }, props)];
                case 4:
                    // 🔹 7. Update SharePoint
                    _a.sent();
                    alert("Request sent back successfully");
                    history.push("/ApprovalDashboard");
                    return [3 /*break*/, 6];
                case 5:
                    error_6 = _a.sent();
                    console.error(error_6);
                    alert("Send back failed");
                    setActionLoading(false);
                    return [3 /*break*/, 6];
                case 6: return [2 /*return*/];
            }
        });
    }); };
    var getApproveButtonText = function () {
        switch (currentRole) {
            case "Vouching":
                return "Vouch";
            case "TreasuryVerification":
                return "Verify";
            case "TreasuryPayment":
                return "Pay & Close";
            default:
                return "Approve";
        }
    };
    var formatDate = function (date) {
        if (!date)
            return "";
        var d = new Date(date);
        var day = String(d.getDate()).padStart(2, "0");
        var month = String(d.getMonth() + 1).padStart(2, "0");
        var year = d.getFullYear();
        return "".concat(day, "-").concat(month, "-").concat(year);
    };
    return (react_1.default.createElement("div", { className: "forex-wrapper" },
        react_1.default.createElement("div", { className: "forex-header" },
            react_1.default.createElement("h2", null, "Forex Payment Approval Form")),
        react_1.default.createElement("div", { className: "forex-card" },
            react_1.default.createElement(Section, { title: "Approval Flow" },
                react_1.default.createElement("div", { className: "approval-ribbon" }, approvalSteps.map(function (step, index) {
                    var className = "pending";
                    if (step.status === "initiator")
                        className = "initiator";
                    if (step.status === "approved")
                        className = "approved";
                    if (step.status === "current")
                        className = "current";
                    return (react_1.default.createElement("div", { key: index, className: "ribbon-step ".concat(className) }, step.name));
                }))),
            react_1.default.createElement(Section, { title: "Requestor Information" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Type" },
                        react_1.default.createElement("select", { value: paymentType, onChange: function (e) { return setPaymentType(e.target.value); } },
                            react_1.default.createElement("option", { value: "Goods-Bill Payment" }, "Goods-Bill Payment"),
                            react_1.default.createElement("option", { value: "Service-Bill Payment" }, "Service-Bill Payment"),
                            react_1.default.createElement("option", { value: "Goods-Advance Payment" }, "Goods-Advance Payment"),
                            react_1.default.createElement("option", { value: "Service-Advance Payment" }, "Service-Advance Payment")))),
                react_1.default.createElement(Grid, { style: { marginTop: "20px" } },
                    react_1.default.createElement(Field, { label: "Employee Code" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Name" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Division" },
                        react_1.default.createElement("input", { type: "text", value: employee.Division, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Location" },
                        react_1.default.createElement("input", { type: "text", value: employee.Location, readOnly: true })),
                    react_1.default.createElement(Field, { label: "RM" },
                        react_1.default.createElement("input", { type: "text", value: employee.RM, readOnly: true })),
                    react_1.default.createElement(Field, { label: "HOD" },
                        react_1.default.createElement("input", { type: "text", value: employee.HOD, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Contact No" },
                        react_1.default.createElement("input", { type: "text", value: employee.ContactNo, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Status" },
                        react_1.default.createElement("input", { type: "text", value: employee.EmployeeStatus, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Email", full: true },
                        react_1.default.createElement("input", { type: "email", value: employee.Email, readOnly: true })))),
            react_1.default.createElement(CollapsibleSection, { title: "Vendor / Beneficiary Details" },
                react_1.default.createElement(Section, { title: "Vendor / Beneficiary Details" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Vendor Code" },
                            react_1.default.createElement("input", { value: vendor.VendorCode, onChange: function (e) {
                                    var code = e.target.value;
                                    setVendor(tslib_1.__assign(tslib_1.__assign({}, vendor), { VendorCode: code }));
                                }, onBlur: function (e) { return getVendorData(e.target.value); }, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Vendor Name" },
                            react_1.default.createElement("input", { value: vendor.VendorName, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Address", full: true },
                            react_1.default.createElement("input", { value: vendor.VendorAddress, readOnly: true })),
                        react_1.default.createElement(Field, { label: "City" },
                            react_1.default.createElement("input", { value: vendor.City, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Country" },
                            react_1.default.createElement("input", { value: vendor.Country, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Pincode" },
                            react_1.default.createElement("input", { value: vendor.PostalCode, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank Name" },
                            react_1.default.createElement("input", { value: vendor.BankName, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank Country" },
                            react_1.default.createElement("input", { value: vendor.BankCountry, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank Swift Code" },
                            react_1.default.createElement("input", { value: vendor.SWIFTBICCode, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank Branch Address" },
                            react_1.default.createElement("input", { value: vendor.BankAddress, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Bank IBAN / Account No", full: true },
                            react_1.default.createElement("input", { value: vendor.AccountNumberIBAN, readOnly: true })))),
                react_1.default.createElement(Section, { title: "Tax & Regulatory Information" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Nature of Payment" },
                            react_1.default.createElement("input", { value: paymentType, readOnly: true })),
                        react_1.default.createElement(Field, { label: "Tax Document Available?" },
                            react_1.default.createElement("select", { onChange: function (e) { setTaxDocumentView(e.target.value); }, disabled: true },
                                react_1.default.createElement("option", null, "Yes"),
                                react_1.default.createElement("option", null, "No"))),
                        taxDocumentView === "No" && (react_1.default.createElement(Field, null,
                            react_1.default.createElement("span", { style: { color: "red" } }, "(if No, withholding tax will be applicable)"))),
                        taxDocumentView === "Yes" && (react_1.default.createElement(Field, { label: "DTAA Applicable?" },
                            react_1.default.createElement("select", { value: dTAAApplicable, onChange: function (e) { return setDTAAApplicable(e.target.value); }, disabled: true },
                                react_1.default.createElement("option", { value: "" }, "Select"),
                                react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                react_1.default.createElement("option", { value: "No" }, "No")))))),
                taxDocumentView === "Yes" && (react_1.default.createElement(react_1.default.Fragment, null,
                    react_1.default.createElement(Section, { title: "Permanent Establishment Declaration" },
                        react_1.default.createElement(Grid, null,
                            react_1.default.createElement(Field, { label: "Document Available" },
                                react_1.default.createElement("select", { value: permanentEstablishmentDeclaration.DocumentAvailable || "", disabled: true },
                                    react_1.default.createElement("option", { value: "" }, "Select"),
                                    react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                    react_1.default.createElement("option", { value: "No" }, "No"))),
                            react_1.default.createElement(Field, { label: "Document Number" },
                                react_1.default.createElement("input", { value: permanentEstablishmentDeclaration.DocumentNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Document Date" },
                                react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.DocumentDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity Start Date" },
                                react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.ValidityStartDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity End Date" },
                                react_1.default.createElement("input", { type: "date", value: permanentEstablishmentDeclaration.ValidityEndDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "View Document" },
                                react_1.default.createElement("span", null,
                                    react_1.default.createElement("a", { href: permanentEstablishmentDeclaration.Attachmenturl || "#", target: "_blank" }, permanentEstablishmentDeclaration.Attachmentfilename || "No Document Available"))))),
                    react_1.default.createElement(Section, { title: "Tax Residency Certificate" },
                        react_1.default.createElement(Grid, null,
                            react_1.default.createElement(Field, { label: "Document Available" },
                                react_1.default.createElement("select", { value: taxResidencyCertificate.DocumentAvailable || "", disabled: true },
                                    react_1.default.createElement("option", { value: "" }, "Select"),
                                    react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                    react_1.default.createElement("option", { value: "No" }, "No"))),
                            react_1.default.createElement(Field, { label: "Document Number" },
                                react_1.default.createElement("input", { value: taxResidencyCertificate.DocumentNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Country of Tax Residence" },
                                react_1.default.createElement("input", { value: taxResidencyCertificate.CountryOfTaxResidence || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Tax Identification Number" },
                                react_1.default.createElement("input", { value: taxResidencyCertificate.TaxIdentificationNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity Start Date" },
                                react_1.default.createElement("input", { type: "date", value: taxResidencyCertificate.ValidityStartDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity End Date" },
                                react_1.default.createElement("input", { type: "date", value: taxResidencyCertificate.ValidityEndDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "View Document" },
                                react_1.default.createElement("span", null,
                                    react_1.default.createElement("a", { href: taxResidencyCertificate.Attachmenturl || "#", target: "_blank" }, taxResidencyCertificate.Attachmentfilename || "No Document Available"))))),
                    react_1.default.createElement(Section, { title: "Form 10F" },
                        react_1.default.createElement(Grid, null,
                            react_1.default.createElement(Field, { label: "Document Available" },
                                react_1.default.createElement("select", { value: form10F.DocumentAvailable || "", disabled: true },
                                    react_1.default.createElement("option", { value: "" }, "Select"),
                                    react_1.default.createElement("option", { value: "Yes" }, "Yes"),
                                    react_1.default.createElement("option", { value: "No" }, "No"))),
                            react_1.default.createElement(Field, { label: "Document Number" },
                                react_1.default.createElement("input", { value: form10F.DocumentNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Acknowledgment Number" },
                                react_1.default.createElement("input", { value: form10F.AcknowledgmentNumber || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Document Date" },
                                react_1.default.createElement("input", { type: "date", value: form10F.DocumentDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity Start Date" },
                                react_1.default.createElement("input", { type: "date", value: form10F.ValidityStartDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "Validity End Date" },
                                react_1.default.createElement("input", { type: "date", value: form10F.ValidityEndDate || "", readOnly: true })),
                            react_1.default.createElement(Field, { label: "View Document" },
                                react_1.default.createElement("span", null,
                                    react_1.default.createElement("a", { href: form10F.Attachmenturl || "#", target: "_blank" }, form10F.Attachmentfilename || "No Document Available")))))))),
            react_1.default.createElement(CollapsibleSection, { title: "Summary of WHT Applicability" },
                react_1.default.createElement("div", { className: "date-summary" },
                    react_1.default.createElement("span", { className: "label" }, "From"),
                    react_1.default.createElement("span", { className: "value" }, formatDate(fromdate)),
                    react_1.default.createElement("span", { className: "label" }, "To"),
                    react_1.default.createElement("span", { className: "value" },
                        formatDate(todate),
                        ",")),
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Eligible amount that can be transmitted without WHT" },
                        react_1.default.createElement("input", { type: "number", value: eligibleAmountWithWHT || "", readOnly: true })),
                    react_1.default.createElement(Field, { label: "Paid Amount" },
                        react_1.default.createElement("input", { type: "number", value: paidAmount || "", readOnly: true })),
                    react_1.default.createElement(Field, { label: "Balance eligible amount(Without with holding Tax)" },
                        react_1.default.createElement("input", { type: "number", value: ballenceEligibleAmount || "", readOnly: true })))),
            paymentType === "Goods-Bill Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, onChange: function (e) { setCurrency(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { type: "number", value: totalAmount, onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { type: "text", value: foreignBankCharges, onChange: function (e) { setForeignBankCharges(e.target.value); }, readOnly: true }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr.No"),
                            react_1.default.createElement("th", null, "Invoice No"),
                            react_1.default.createElement("th", null, "Invoice Date"),
                            react_1.default.createElement("th", null, "BOE No"),
                            react_1.default.createElement("th", null, "BOE Date"),
                            react_1.default.createElement("th", null, "MRN No"),
                            react_1.default.createElement("th", null, "Bill of Lading No"),
                            react_1.default.createElement("th", null, "Bill of Lading Date"),
                            react_1.default.createElement("th", null, "Invoice Amount"),
                            react_1.default.createElement("th", null, "Attach Invoice"),
                            react_1.default.createElement("th", null, "Attach Other Docs"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.boeNo, onChange: function (e) {
                                        return handleChange(index, "boeNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.boeDate, onChange: function (e) {
                                        return handleChange(index, "boeDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.mrnNo, onChange: function (e) {
                                        return handleChange(index, "mrnNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.blNo, onChange: function (e) {
                                        return handleChange(index, "blNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.blDate, onChange: function (e) {
                                        return handleChange(index, "blDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "number", value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, ((_a = invoiceAttachments[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (invoiceAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("INV_", "")))); })) : (react_1.default.createElement("span", null, "-"))),
                                "                                        "),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_b = otherAttachments[index]) === null || _b === void 0 ? void 0 : _b.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("DOC_", "")))); })),
                                "                                        ")));
                    }))),
                react_1.default.createElement("div", { style: { display: "flex", gap: "40px", marginTop: "30px" } },
                    react_1.default.createElement("div", { style: { flex: 1 } },
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "13px" } }, "Unique BOE no will be listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "BOE No"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBoeNumbers.map(function (boe, index) { return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, boe),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("div", null, boeLibraryFiles
                                        .filter(function (file) { return file.BOENo === boe; })
                                        .map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.FileRef, target: "_blank" }, file.FileLeafRef))); })),
                                    "                                                "))); })))),
                    react_1.default.createElement("div", { style: { flex: 1 } },
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "13px" } }, "Unique Bill of lading no will be listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "Bill of Lading Number"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBlNumbers.map(function (bl, index) { return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, bl),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("div", null, bolLibraryFiles
                                        .filter(function (file) { return file.BOLNo === bl; })
                                        .map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.FileRef, target: "_blank" }, file.FileLeafRef))); })),
                                    "                                                "))); }))))))),
            paymentType === "Service-Bill Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, onChange: function (e) { setCurrency(e.target.value); } })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { type: "number", value: totalAmount, onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { type: "text", value: foreignBankCharges, onChange: function (e) { setForeignBankCharges(e.target.value); }, readOnly: true }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null, "Invoice No"),
                            react_1.default.createElement("th", null, "Invoice Date"),
                            react_1.default.createElement("th", null, "Invoice Amount"),
                            react_1.default.createElement("th", null, "MRN No"),
                            react_1.default.createElement("th", null, "MRN Date"),
                            react_1.default.createElement("th", null, "Attach Invoice"),
                            react_1.default.createElement("th", null, "Attach Other Document"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.mrnNo, onChange: function (e) {
                                        return handleChange(index, "mrnNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.mrnDate, onChange: function (e) {
                                        return handleChange(index, "mrnDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, ((_a = invoiceAttachments[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (invoiceAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("INV_", "")))); })) : (react_1.default.createElement("span", null, "-")))),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_b = otherAttachments[index]) === null || _b === void 0 ? void 0 : _b.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("DOC_", "")))); })))));
                    }))))),
            paymentType === "Service-Advance Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, onChange: function (e) { setCurrency(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { type: "number", value: totalAmount, onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { type: "text", value: foreignBankCharges, onChange: function (e) { setForeignBankCharges(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "PO/Contract No" },
                        react_1.default.createElement("input", { value: poContractNo, onChange: function (e) { setPoContractNo(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "PO Date" },
                        react_1.default.createElement("input", { type: "date", value: poDate, onChange: function (e) { setPoDate(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Expected Settlement Date" },
                        react_1.default.createElement("input", { type: "date", value: expectedSettlementDate, onChange: function (e) { setExpectedSettlementDate(e.target.value); }, readOnly: true }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null, "Performa Invoice No"),
                            react_1.default.createElement("th", null, "Performa Invoice Date"),
                            react_1.default.createElement("th", null, "Performa Invoice Amount"),
                            react_1.default.createElement("th", null, "Attach PO"),
                            react_1.default.createElement("th", null, "Attach PI"),
                            react_1.default.createElement("th", null, "Attach Other Document"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b, _c;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_a = poAttachments[index]) === null || _a === void 0 ? void 0 : _a.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("PO_", "")))); })),
                                "                                        "),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_b = piAttachments[index]) === null || _b === void 0 ? void 0 : _b.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("PI_", "")))); })),
                                "                                        "),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_c = otherAttachments[index]) === null || _c === void 0 ? void 0 : _c.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("DOC_", "")))); })),
                                "                                        ")));
                    }))))),
            paymentType === "Goods-Advance Payment" && (react_1.default.createElement(Section, { title: "Forex Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, onChange: function (e) { setRequestNumber(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, onChange: function (e) { setRequestedOn(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, onChange: function (e) { setCurrency(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { type: "number", value: totalAmount, onChange: function (e) { setTotalAmount(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { type: "text", value: foreignBankCharges, onChange: function (e) { setForeignBankCharges(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "PO/Contract No" },
                        react_1.default.createElement("input", { value: poContractNo, onChange: function (e) { setPoContractNo(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "PO Date" },
                        react_1.default.createElement("input", { type: "date", value: poDate, onChange: function (e) { setPoDate(e.target.value); }, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Expected Settlement Date" },
                        react_1.default.createElement("input", { type: "date", value: expectedSettlementDate, onChange: function (e) { setExpectedSettlementDate(e.target.value); }, readOnly: true }))),
                react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr No"),
                            react_1.default.createElement("th", null, "Performa Invoice No"),
                            react_1.default.createElement("th", null, "Performa Invoice Date"),
                            react_1.default.createElement("th", null, "Performa Invoice Amount"),
                            react_1.default.createElement("th", null, "Attach PO"),
                            react_1.default.createElement("th", null, "Attach PI"),
                            react_1.default.createElement("th", null, "Attach Other Document"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b, _c;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) {
                                        return handleChange(index, "invoiceNo", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) {
                                        return handleChange(index, "invoiceDate", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) {
                                        return handleChange(index, "invoiceAmount", e.target.value);
                                    }, readOnly: true })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_a = poAttachments[index]) === null || _a === void 0 ? void 0 : _a.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("PO_", "")))); })),
                                "                                        "),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_b = piAttachments[index]) === null || _b === void 0 ? void 0 : _b.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("PI_", "")))); })),
                                "                                        "),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("div", null, (_c = otherAttachments[index]) === null || _c === void 0 ? void 0 : _c.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank" }, file.FileName.replace("DOC_", "")))); })),
                                "                                        ")));
                    }))))),
            react_1.default.createElement(CollapsibleSection, { title: "Workflow History" }, workflowHistory.length > 0 ? (react_1.default.createElement("table", { className: "data-table" },
                react_1.default.createElement("thead", null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("th", null, "Action By"),
                        react_1.default.createElement("th", null, "Action"),
                        react_1.default.createElement("th", null, "Remark"),
                        " ",
                        react_1.default.createElement("th", null, "Date"))),
                react_1.default.createElement("tbody", null, workflowHistory.map(function (item, index) { return (react_1.default.createElement("tr", { key: index },
                    react_1.default.createElement("td", null, item.CurrentApprover),
                    "   ",
                    react_1.default.createElement("td", null, item.ActionTaken),
                    "       ",
                    react_1.default.createElement("td", null, item.Comment),
                    "           ",
                    react_1.default.createElement("td", null, item.Date
                        ? new Date(item.Date).toLocaleString("en-GB")
                        : ""))); })))) : (react_1.default.createElement("p", null, "No workflow history available"))),
            currentRole === "Vouching" && (react_1.default.createElement(Section, { title: "Vouching Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Validation Date", required: true },
                        react_1.default.createElement("input", { type: "date", value: validationDate, onChange: function (e) { return setValidationDate(e.target.value); } })),
                    (paymentType.includes("Advance")) && (react_1.default.createElement(Field, { label: "Voucher Number", required: true },
                        react_1.default.createElement("input", { value: voucherNumber, onChange: function (e) { return setVoucherNumber(e.target.value); } }))),
                    react_1.default.createElement(Field, { label: "Remarks", full: true, required: true },
                        react_1.default.createElement("textarea", { rows: 2, value: vouchingRemarks, onChange: function (e) { return setVouchingRemarks(e.target.value); } }))))),
            currentRole === "TreasuryVerification" && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(Section, { title: "Vouching Details" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Validation Date", required: true },
                            react_1.default.createElement("input", { type: "text", value: validationDateshow, 
                                // onChange={(e) => setValidationDate(e.target.value)}
                                readOnly: true })),
                        (paymentType.includes("Advance")) && (react_1.default.createElement(Field, { label: "Voucher Number", required: true },
                            react_1.default.createElement("input", { value: voucherNumbershow, onChange: function (e) { return setVoucherNumber(e.target.value); } }))))),
                react_1.default.createElement(Section, { title: "Treasury Verification" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Treasury Remarks", full: true, required: true },
                            react_1.default.createElement("textarea", { rows: 2, value: treasuryRemarks, onChange: function (e) { return setTreasuryRemarks(e.target.value); } })))))),
            currentRole === "TreasuryPayment" && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(Section, { title: "Vouching Details" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Validation Date", required: true },
                            react_1.default.createElement("input", { type: "text", value: validationDateshow, readOnly: true })),
                        (paymentType.includes("Advance")) && (react_1.default.createElement(Field, { label: "Voucher Number", required: true },
                            react_1.default.createElement("input", { value: voucherNumbershow, 
                                // onChange={(e) => setVoucherNumber(e.target.value)}
                                readOnly: true }))))),
                react_1.default.createElement(Section, { title: "Payment Details" },
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Foreign Currency", required: true },
                            react_1.default.createElement(react_2.Dropdown, { options: foreignCurrencyOptions, selectedKey: foreignCurrency, onChange: function (e, option) {
                                    if (option) {
                                        setForeignCurrency(option.key);
                                    }
                                } })),
                        react_1.default.createElement(Field, { label: "Foreign Currency Amount", required: true },
                            react_1.default.createElement("input", { type: "number", value: foreignAmount, onChange: function (e) { return setForeignAmount(e.target.value); } })),
                        react_1.default.createElement(Field, { label: "Exchange Rate", required: true },
                            react_1.default.createElement("input", { type: "number", value: exchangeRate, onChange: function (e) { return setExchangeRate(e.target.value); } })),
                        react_1.default.createElement(Field, { label: "INR Amount", required: true },
                            react_1.default.createElement("input", { type: "number", value: inrAmount, onChange: function (e) { return setInrAmount(e.target.value); } }))),
                    react_1.default.createElement("p", { style: { color: "red", fontSize: "12px" } }, "(if difference in foreign currency & Amount system to display alert message only)"),
                    react_1.default.createElement(Grid, null,
                        react_1.default.createElement(Field, { label: "Payment Date", required: true },
                            react_1.default.createElement("input", { type: "date", value: paymentDate, onChange: function (e) { return setPaymentDate(e.target.value); } })),
                        react_1.default.createElement(Field, { label: "Payment reference number", required: true },
                            react_1.default.createElement("input", { value: paymentReference, onChange: function (e) { return setPaymentReference(e.target.value); } })),
                        isServicePayment && (react_1.default.createElement(Field, { label: "Form145", required: true },
                            react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) {
                                    var files = e.target.files
                                        ? Array.from(e.target.files)
                                        : [];
                                    setForm15CA(function (prev) { return tslib_1.__spreadArray(tslib_1.__spreadArray([], prev, true), files, true); });
                                } }),
                            form15CA.length > 0 && (react_1.default.createElement("div", { style: { marginTop: "10px" } }, form15CA.map(function (file, index) { return (react_1.default.createElement("div", { key: index, style: {
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    marginBottom: "5px",
                                    padding: "6px 10px",
                                    border: "1px solid #ddd",
                                    borderRadius: "4px",
                                } },
                                react_1.default.createElement("span", null, file.name),
                                react_1.default.createElement("button", { type: "button", onClick: function () { return remove15CAFile(index); }, style: {
                                        background: "red",
                                        color: "#fff",
                                        border: "none",
                                        padding: "4px 8px",
                                        cursor: "pointer",
                                        borderRadius: "4px",
                                    } }, "Delete"))); }))))),
                        isServicePayment && (react_1.default.createElement(Field, { label: "Form146 ", required: true },
                            react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) {
                                    var files = e.target.files
                                        ? Array.from(e.target.files)
                                        : [];
                                    setForm15CB(function (prev) { return tslib_1.__spreadArray(tslib_1.__spreadArray([], prev, true), files, true); });
                                } }),
                            form15CB.length > 0 && (react_1.default.createElement("div", { style: { marginTop: "10px" } }, form15CB.map(function (file, index) { return (react_1.default.createElement("div", { key: index, style: {
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    marginBottom: "5px",
                                    padding: "6px 10px",
                                    border: "1px solid #ddd",
                                    borderRadius: "4px",
                                } },
                                react_1.default.createElement("span", null, file.name),
                                react_1.default.createElement("button", { type: "button", onClick: function () { return remove15CBFile(index); }, style: {
                                        background: "red",
                                        color: "#fff",
                                        border: "none",
                                        padding: "4px 8px",
                                        cursor: "pointer",
                                        borderRadius: "4px",
                                    } }, "Delete"))); })))))),
                    react_1.default.createElement(Grid, null, isGoodsPayment && (react_1.default.createElement(Field, { label: "Attach Swift Copy (Applicable for Goods)", required: true },
                        react_1.default.createElement("input", { type: "file", multiple: true, onChange: function (e) {
                                var files = e.target.files
                                    ? Array.from(e.target.files)
                                    : [];
                                setSwiftCopy(function (prev) { return tslib_1.__spreadArray(tslib_1.__spreadArray([], prev, true), files, true); });
                            } }),
                        swiftCopy.length > 0 && (react_1.default.createElement("div", { style: { marginTop: "10px" } }, swiftCopy.map(function (file, index) { return (react_1.default.createElement("div", { key: index, style: {
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "center",
                                marginBottom: "5px",
                                padding: "6px 10px",
                                border: "1px solid #ddd",
                                borderRadius: "4px",
                            } },
                            react_1.default.createElement("span", null, file.name),
                            react_1.default.createElement("button", { type: "button", onClick: function () { return removeSwiftCopyFile(index); }, style: {
                                    background: "red",
                                    color: "#fff",
                                    border: "none",
                                    padding: "4px 8px",
                                    cursor: "pointer",
                                    borderRadius: "4px",
                                } }, "Delete"))); }))))))))),
            (currentRole === "RM" || currentRole === "HOD") && (react_1.default.createElement(Section, { title: " Remarks Section " },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Approver Remarks", full: true, required: true },
                        react_1.default.createElement("textarea", { rows: 2, value: approverRemarks, onChange: function (e) { return setApproverRemarks(e.target.value); } }))))),
            react_1.default.createElement("div", { className: "button-row" },
                react_1.default.createElement("button", { className: "btn-submit", onClick: onsubmit, disabled: actionLoading }, actionLoading ? "Processing..." : getApproveButtonText()),
                react_1.default.createElement("button", { className: "btn-Reject", onClick: onReject, disabled: actionLoading }, actionLoading ? "Processing..." : "Reject"),
                react_1.default.createElement("button", { className: "btn-exit", onClick: onSentBack, disabled: actionLoading }, actionLoading ? "Processing..." : "Send Back"),
                react_1.default.createElement("button", { className: "btn-exit", onClick: function () { return history.goBack(); } }, "Exit"))),
        showVendorPopup && (react_1.default.createElement("div", { className: "popup-overlay" },
            react_1.default.createElement("div", { className: "popup-box" },
                react_1.default.createElement("h3", null, "Vendor Not Found"),
                react_1.default.createElement("p", null, "Please add vendor first."),
                react_1.default.createElement("div", { style: { marginTop: "20px", display: "flex", gap: "10px", justifyContent: "center" } },
                    react_1.default.createElement("button", { className: "btn-submit", onClick: function () {
                            setShowVendorPopup(false);
                            history.push("/vendor-creation");
                        } }, "Go to Vendor Creation")))))));
};
exports.default = ApprovalRequestForm;
//# sourceMappingURL=ApprovalRequestForm.js.map