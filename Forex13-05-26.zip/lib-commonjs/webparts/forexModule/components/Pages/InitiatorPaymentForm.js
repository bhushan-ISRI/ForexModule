"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var react_1 = tslib_1.__importStar(require("react"));
require("../Pages/Css/NewRequest.scss");
var react_router_dom_1 = require("react-router-dom");
var spcrud_1 = tslib_1.__importDefault(require("../../service/BAL/spcrud"));
var sp_http_1 = require("@microsoft/sp-http");
/* ---------- Layout Helpers ---------- */
var Section = function (_a) {
    var title = _a.title, children = _a.children;
    return (react_1.default.createElement("div", { className: "form-section" },
        title && react_1.default.createElement("h3", null, title),
        children));
};
var Grid = function (_a) {
    var children = _a.children;
    return (react_1.default.createElement("div", { className: "form-grid" }, children));
};
var Field = function (_a) {
    var label = _a.label, children = _a.children, full = _a.full;
    return (react_1.default.createElement("div", { className: full ? "form-field full" : "form-field" },
        react_1.default.createElement("label", null, label),
        children));
};
var CollapsibleSection = function (_a) {
    var title = _a.title, children = _a.children;
    var _b = react_1.default.useState(false), open = _b[0], setOpen = _b[1];
    return (react_1.default.createElement("div", { className: "form-section collapsible" },
        react_1.default.createElement("div", { className: "form-section-header", onClick: function () { return setOpen(!open); } },
            react_1.default.createElement("span", null, title),
            react_1.default.createElement("i", { className: "fas fa-chevron-".concat(open ? "up" : "down") })),
        open && (react_1.default.createElement("div", { className: "form-section-body" }, children))));
};
var TrackerForm = function (props) {
    var Id = (0, react_router_dom_1.useParams)().Id;
    var history = (0, react_router_dom_1.useHistory)();
    var spCrudOps = (0, spcrud_1.default)();
    var _a = (0, react_1.useState)(""), paymentType = _a[0], setPaymentType = _a[1];
    var _b = (0, react_1.useState)({}), employee = _b[0], setEmployee = _b[1];
    var _c = (0, react_1.useState)({}), vendor = _c[0], setVendor = _c[1];
    var _d = (0, react_1.useState)(""), requestNumber = _d[0], setRequestNumber = _d[1];
    var _e = (0, react_1.useState)(""), currency = _e[0], setCurrency = _e[1];
    var _f = (0, react_1.useState)(""), requestedOn = _f[0], setRequestedOn = _f[1];
    var _g = (0, react_1.useState)(""), totalAmount = _g[0], setTotalAmount = _g[1];
    var _h = (0, react_1.useState)(""), foreignBankCharges = _h[0], setForeignBankCharges = _h[1];
    var _j = (0, react_1.useState)({}), invoiceAttachments = _j[0], setInvoiceAttachments = _j[1];
    var _k = (0, react_1.useState)({}), otherAttachments = _k[0], setOtherAttachments = _k[1];
    var _l = (0, react_1.useState)({}), poAttachments = _l[0], setPoAttachments = _l[1];
    var _m = (0, react_1.useState)({}), piAttachments = _m[0], setPiAttachments = _m[1];
    var _o = (0, react_1.useState)({}), boeAttachments = _o[0], setBoeAttachments = _o[1];
    var _p = (0, react_1.useState)({}), blAttachments = _p[0], setBlAttachments = _p[1];
    var _q = (0, react_1.useState)({}), otherAttachmentsadvance = _q[0], setOtherAttachmentsadvance = _q[1];
    var _r = (0, react_1.useState)([
        {
            invoiceNo: "",
            invoiceDate: "",
            boeNo: "",
            boeDate: "",
            mrnNo: "",
            blNo: "",
            blDate: "",
            invoiceAmount: "",
        },
    ]), rows = _r[0], setRows = _r[1];
    var _s = (0, react_1.useState)([
        {
            invoiceNo: "",
            invoiceDate: "",
            boeNo: "",
            boeDate: "",
            mrnNo: "",
            blNo: "",
            blDate: "",
            invoiceAmountnew: "",
        },
    ]), ShowInvoiceData = _s[0], serShowInvoiceData = _s[1];
    var _t = (0, react_1.useState)([]), workflowHistory = _t[0], setWorkflowHistory = _t[1];
    (0, react_1.useEffect)(function () {
        if (Id)
            loadForexData(Id);
    }, [Id]);
    var getVendorData = function (vendorCode) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, res, v;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    return [4 /*yield*/, sp.getData("VendorMaster", "VendorCode,VendorName,VendorNameLegal,VendorShortName,VendorType,City/Title,State/Title,Country/Title,Currency/Title,PostalCode,ContactPersonName,EmailId,PhoneNumber,AlternateContact,BeneficiaryName,BankName,AccountNumberIBAN,SWIFTBICCode,RoutingNumberABA,IFSCCode,IntermediaryBank,IntermediarySWIFTCode,NatureOfPayment/Title,PurposeCodeRBI,BankCountry,BankAddress,VendorAddress", "NatureOfPayment,City,State,Country,Currency", "VendorCode eq '".concat(vendorCode, "'"), { column: "ID", isAscending: true }, 1, props)];
                case 2:
                    res = _a.sent();
                    if (res.length > 0) {
                        v = res[0];
                        setVendor({
                            VendorCode: v.VendorCode,
                            VendorName: v.VendorName,
                            VendorAddress: v.VendorAddress,
                            City: v.City.Title,
                            Country: v.Country.Title,
                            PostalCode: v.PostalCode,
                            BankName: v.BankName,
                            BankCountry: v.BankCountry,
                            SWIFTBICCode: v.SWIFTBICCode,
                            BankAddress: v.BankAddress,
                            AccountNumberIBAN: v.AccountNumberIBAN
                        });
                    }
                    return [2 /*return*/];
            }
        });
    }); };
    var loadForexData = function (id) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, parent, data, parsed, child, formattedRows, invoiceAttachmentMap_1, otherAttachmentMap_1, poAttachmentMap_1, piAttachmentMap_1, trackerData, trackerInvoiceAttachments_1, trackerOtherAttachments_1, trackerBoeAttachments_1, trackerBlAttachments_1, trackerRows, savedAmount, finalRows;
        var _a, _b, _c;
        return tslib_1.__generator(this, function (_d) {
            switch (_d.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _d.sent();
                    return [4 /*yield*/, sp.getData("ForexRequest", "*,RM/Title,HOD/Title,Currency/Title", "RM,HOD,Currency", "ID eq ".concat(id), { column: "ID", isAscending: true }, 1, props)];
                case 2:
                    parent = _d.sent();
                    if (!(parent.length > 0)) return [3 /*break*/, 5];
                    data = parent[0];
                    if (data.WorkFlowHistory) {
                        try {
                            parsed = JSON.parse(data.WorkFlowHistory);
                            setWorkflowHistory(parsed);
                        }
                        catch (_e) {
                            setWorkflowHistory([]);
                        }
                    }
                    setPaymentType(data.ForexType);
                    setRequestNumber(data.ForexNumber);
                    setRequestedOn((_a = data.RequestedOn) === null || _a === void 0 ? void 0 : _a.split("T")[0]);
                    setCurrency(data.Currency.Title);
                    setTotalAmount(data.TotalAmount);
                    setForeignBankCharges(data.ForeignBankCharges);
                    setEmployee({
                        EmployeeCode: data.EmployeeCode || "",
                        EmployeeName: data.EmployeeName || "",
                        Division: data.Division || "",
                        Location: data.Location || "",
                        RM: ((_b = data.RM) === null || _b === void 0 ? void 0 : _b.Title) || "",
                        HOD: ((_c = data.HOD) === null || _c === void 0 ? void 0 : _c.Title) || "",
                        ContactNo: data.ContactNo || "",
                        EmployeeStatus: data.EmployeeStatus || "",
                        Email: data.Email || ""
                    });
                    // setVendor({
                    //     VendorCode: data.VendorCode,
                    //     VendorName: data.VendorName,
                    //     VendorAddress: data.VendorAddress,
                    //     City: data.City,
                    //     Country: data.Country,
                    //     PostalCode: data.PostalCode,
                    //     BankName: data.BankName,
                    //     BankCountry: data.BankCountry,
                    //     SWIFTBICCode: data.BankSwiftCode,
                    //     BankAddress: data.BankAddress,
                    //     AccountNumberIBAN: data.BankAccNo,
                    // });
                    getVendorData(data.VendorCode);
                    return [4 /*yield*/, sp.getData("ForexServicesBillPayment", "*,AttachmentFiles", "AttachmentFiles", "ForexIDId eq ".concat(id), { column: "ID", isAscending: true }, 5000, props)];
                case 3:
                    child = _d.sent();
                    if (child.length > 0) {
                        formattedRows = child.map(function (item) {
                            var _a, _b, _c, _d;
                            return ({
                                invoiceNo: item.InvoiceNumber || "",
                                invoiceDate: ((_a = item.InvoiceDate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "",
                                invoiceAmountnew: item.InvoiceAmount || "",
                                mrnNo: item.MRNNumber || "",
                                mrnDate: ((_b = item.MRNDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                blNo: item.BillofLandingNo || "",
                                blDate: ((_c = item.BillOfLandingdate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                boeNo: item.BOENo || "",
                                boeDate: ((_d = item.BOEDate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || ""
                            });
                        });
                        serShowInvoiceData(formattedRows);
                        invoiceAttachmentMap_1 = {};
                        otherAttachmentMap_1 = {};
                        poAttachmentMap_1 = {};
                        piAttachmentMap_1 = {};
                        child.forEach(function (item, index) {
                            var files = item.AttachmentFiles || [];
                            invoiceAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("INV_"); });
                            otherAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("DOC_"); });
                            poAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PO_"); });
                            piAttachmentMap_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("PI_"); });
                        });
                        setInvoiceAttachments(invoiceAttachmentMap_1);
                        setOtherAttachments(otherAttachmentMap_1);
                        setPoAttachments(poAttachmentMap_1);
                        setPiAttachments(piAttachmentMap_1);
                    }
                    return [4 /*yield*/, sp.getData("ForexAdvanceBillPayment", "*,AttachmentFiles", "AttachmentFiles", "ForexIDId eq ".concat(id), { column: "ID", isAscending: true }, 5000, props)];
                case 4:
                    trackerData = _d.sent();
                    if (trackerData.length > 0) {
                        trackerInvoiceAttachments_1 = {};
                        trackerOtherAttachments_1 = {};
                        trackerBoeAttachments_1 = {};
                        trackerBlAttachments_1 = {};
                        trackerRows = trackerData.map(function (item, index) {
                            var _a, _b, _c, _d;
                            var files = item.AttachmentFiles || [];
                            trackerInvoiceAttachments_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("INV_"); });
                            trackerOtherAttachments_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("DOC_"); });
                            trackerBoeAttachments_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("BOE_"); });
                            trackerBlAttachments_1[index] = files.filter(function (f) { var _a; return (_a = f.FileName) === null || _a === void 0 ? void 0 : _a.startsWith("BL_"); });
                            return {
                                invoiceNo: item.InvoiceNumber || "",
                                invoiceDate: ((_a = item.InvoiceDate) === null || _a === void 0 ? void 0 : _a.split("T")[0]) || "",
                                boeNo: item.BOENo || "",
                                boeDate: ((_b = item.BOEDate) === null || _b === void 0 ? void 0 : _b.split("T")[0]) || "",
                                mrnNo: item.MRNNumber || "",
                                mrnDate: ((_c = item.MRNDate) === null || _c === void 0 ? void 0 : _c.split("T")[0]) || "",
                                blNo: item.BillofLandingNo || "",
                                blDate: ((_d = item.BillOfLandingdate) === null || _d === void 0 ? void 0 : _d.split("T")[0]) || "",
                                invoiceAmount: item.InvoiceAmount || "",
                            };
                        });
                        setInvoiceAttachments(trackerInvoiceAttachments_1);
                        setOtherAttachmentsadvance(trackerOtherAttachments_1);
                        setBoeAttachments(trackerBoeAttachments_1);
                        setBlAttachments(trackerBlAttachments_1);
                        savedAmount = trackerRows.reduce(function (sum, r) { return sum + (parseFloat(r.invoiceAmount || "0")); }, 0);
                        finalRows = tslib_1.__spreadArray([], trackerRows, true);
                        if (savedAmount < parseFloat(data.TotalAmount || "0")) {
                            finalRows.push({
                                invoiceNo: "",
                                invoiceDate: "",
                                boeNo: "",
                                boeDate: "",
                                mrnNo: "",
                                mrnDate: "",
                                blNo: "",
                                blDate: "",
                                invoiceAmount: "",
                            });
                        }
                        setRows(finalRows);
                    }
                    _d.label = 5;
                case 5: return [2 /*return*/];
            }
        });
    }); };
    /* ---------- Rows ---------- */
    var addRow = function () {
        setRows(tslib_1.__spreadArray(tslib_1.__spreadArray([], rows, true), [
            {
                invoiceNo: "",
                invoiceDate: "",
                boeNo: "",
                boeDate: "",
                mrnNo: "",
                blNo: "",
                blDate: "",
                invoiceAmount: "",
            },
        ], false));
    };
    var deleteRow = function (index) {
        var updated = rows.filter(function (_, i) { return i !== index; });
        setRows(updated);
    };
    var handleChange = function (index, field, value) {
        var updated = tslib_1.__spreadArray([], rows, true);
        updated[index][field] = value;
        setRows(updated);
    };
    var totalInvoiceAmount = rows.reduce(function (sum, r) { return sum + (parseFloat(r.invoiceAmount) || 0); }, 0);
    var totalInvoiceAmountNew = ShowInvoiceData.reduce(function (sum, r) { return sum + (parseFloat(r.invoiceAmountnew) || 0); }, 0);
    var uniqueBoeNumbers = Array.from(new Set(rows.map(function (r) { return r.boeNo; }).filter(Boolean)));
    var uniqueBlNumbers = Array.from(new Set(rows.map(function (r) { return r.blNo; }).filter(Boolean)));
    var getTreasuryPaymentApprover = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, res;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    return [4 /*yield*/, sp.getData("ForexApprovalMatrix", "*,Approver/Id,Approver/Title", "Approver", "Role eq 'TreasuryPayment' and RequestType eq 'Advance Payment' and Status eq 'Active'", { column: "ID", isAscending: true }, 1, props)];
                case 2:
                    res = _a.sent();
                    if (res.length > 0) {
                        return [2 /*return*/, res[0].ApproverId];
                    }
                    return [2 /*return*/, null];
            }
        });
    }); };
    var validateForm = function () {
        for (var i = 0; i < rows.length; i++) {
            var row = rows[i];
            // COMMON
            if (!row.invoiceNo) {
                alert("Invoice No required in row ".concat(i + 1));
                return false;
            }
            if (!row.invoiceDate) {
                alert("Invoice Date required in row ".concat(i + 1));
                return false;
            }
            if (!row.invoiceAmount) {
                alert("Invoice Amount required in row ".concat(i + 1));
                return false;
            }
            if (totalInvoiceAmount > parseFloat(totalAmount)) {
                alert("Total Invoice Amount cannot be greater than Total Performa Invoice Amount");
                return false;
            }
            // ================= GOODS ADVANCE =================
            if (paymentType === "Goods-Advance Payment") {
                if (!row.boeNo) {
                    alert("BOE No required in row ".concat(i + 1));
                    return false;
                }
                if (!row.boeDate) {
                    alert("BOE Date required in row ".concat(i + 1));
                    return false;
                }
                if (!row.mrnNo) {
                    alert("MRN No required in row ".concat(i + 1));
                    return false;
                }
                if (!row.blNo) {
                    alert("Bill of Lading No required in row ".concat(i + 1));
                    return false;
                }
                if (!row.blDate) {
                    alert("Bill of Lading Date required in row ".concat(i + 1));
                    return false;
                }
                // Invoice file
                if (!invoiceAttachments[i] || invoiceAttachments[i].length === 0) {
                    alert("Invoice attachment required in row ".concat(i + 1));
                    return false;
                }
            }
            // ================= SERVICE ADVANCE =================
            if (paymentType === "Service-Advance Payment") {
                if (!row.mrnNo) {
                    alert("MRN No required in row ".concat(i + 1));
                    return false;
                }
                if (!row.mrnDate) {
                    alert("MRN Date required in row ".concat(i + 1));
                    return false;
                }
                if (!invoiceAttachments[i] || invoiceAttachments[i].length === 0) {
                    alert("Invoice attachment required in row ".concat(i + 1));
                    return false;
                }
            }
        }
        // ================= GOODS ADVANCE UNIQUE FILES =================
        if (paymentType === "Goods-Advance Payment") {
            for (var i = 0; i < uniqueBoeNumbers.length; i++) {
                if (!boeAttachments[i] || boeAttachments[i].length === 0) {
                    alert("BOE document required for BOE No: ".concat(uniqueBoeNumbers[i]));
                    return false;
                }
            }
            for (var i = 0; i < uniqueBlNumbers.length; i++) {
                if (!blAttachments[i] || blAttachments[i].length === 0) {
                    alert("BL document required for Bill of Lading: ".concat(uniqueBlNumbers[i]));
                    return false;
                }
            }
        }
        return true;
    };
    var onSubmit = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var sp, trackerData_1, newRows, _loop_1, i, treasuryUserId, existingItem, existingHistory, updatedHistory, advanceAmount, settledAmount, finalStatus, balanceAmount, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1:
                    sp = _a.sent();
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 11, , 12]);
                    if (!validateForm())
                        return [2 /*return*/];
                    return [4 /*yield*/, sp.getData("ForexAdvanceBillPayment", "*", "", "ForexIDId eq ".concat(Id), { column: "ID", isAscending: true }, 5000, props)];
                case 3:
                    trackerData_1 = _a.sent();
                    newRows = rows.filter(function (r) {
                        return r.invoiceNo &&
                            r.invoiceDate &&
                            r.invoiceAmount &&
                            !trackerData_1.some(function (t) {
                                return t.InvoiceNumber === r.invoiceNo &&
                                    t.InvoiceAmount == r.invoiceAmount;
                            });
                    });
                    _loop_1 = function (i) {
                        var row, item, itemId, uploadFiles, _i, _c, file, fileName, _d, _e, file, fileName;
                        return tslib_1.__generator(this, function (_f) {
                            switch (_f.label) {
                                case 0:
                                    row = newRows[i];
                                    return [4 /*yield*/, sp.insertData("ForexAdvanceBillPayment", {
                                            ForexIDId: Number(Id),
                                            InvoiceNumber: row.invoiceNo,
                                            InvoiceDate: row.invoiceDate ? row.invoiceDate : null,
                                            InvoiceAmount: '' + row.invoiceAmount,
                                            MRNNumber: '' + row.mrnNo,
                                            MRNDate: row.mrnDate ? row.mrnDate : null,
                                            BOENo: '' + row.boeNo,
                                            BOEDate: row.boeDate ? row.boeDate : null,
                                            BillofLandingNo: row.blNo,
                                            BillOfLandingdate: row.blDate ? row.blDate : null
                                        }, props)];
                                case 1:
                                    item = _f.sent();
                                    itemId = item.data.ID;
                                    uploadFiles = function (files) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
                                        var _i, files_1, file, response, blob;
                                        return tslib_1.__generator(this, function (_a) {
                                            switch (_a.label) {
                                                case 0:
                                                    _i = 0, files_1 = files;
                                                    _a.label = 1;
                                                case 1:
                                                    if (!(_i < files_1.length)) return [3 /*break*/, 6];
                                                    file = files_1[_i];
                                                    return [4 /*yield*/, fetch(file.ServerRelativeUrl)];
                                                case 2:
                                                    response = _a.sent();
                                                    return [4 /*yield*/, response.blob()];
                                                case 3:
                                                    blob = _a.sent();
                                                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(props.context.pageContext.web.absoluteUrl, "/_api/web/lists/getbytitle('ForexAdvanceBillPayment')/items(").concat(itemId, ")/AttachmentFiles/add(FileName='").concat(file.FileName, "')"), sp_http_1.SPHttpClient.configurations.v1, { body: blob })];
                                                case 4:
                                                    _a.sent();
                                                    _a.label = 5;
                                                case 5:
                                                    _i++;
                                                    return [3 /*break*/, 1];
                                                case 6: return [2 /*return*/];
                                            }
                                        });
                                    }); };
                                    if (!poAttachments[i]) return [3 /*break*/, 3];
                                    return [4 /*yield*/, uploadFiles(poAttachments[i])];
                                case 2:
                                    _f.sent();
                                    _f.label = 3;
                                case 3:
                                    if (!piAttachments[i]) return [3 /*break*/, 5];
                                    return [4 /*yield*/, uploadFiles(piAttachments[i])];
                                case 4:
                                    _f.sent();
                                    _f.label = 5;
                                case 5:
                                    if (!otherAttachmentsadvance[i]) return [3 /*break*/, 7];
                                    return [4 /*yield*/, uploadFiles(otherAttachmentsadvance[i])];
                                case 6:
                                    _f.sent();
                                    _f.label = 7;
                                case 7:
                                    if (!boeAttachments[i]) return [3 /*break*/, 11];
                                    _i = 0, _c = boeAttachments[i];
                                    _f.label = 8;
                                case 8:
                                    if (!(_i < _c.length)) return [3 /*break*/, 11];
                                    file = _c[_i];
                                    fileName = "BOE_".concat(row.boeNo, "_").concat(file.name);
                                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(props.context.pageContext.web.absoluteUrl, "/_api/web/lists/getbytitle('ForexAdvanceBillPayment')/items(").concat(itemId, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, { body: file })];
                                case 9:
                                    _f.sent();
                                    _f.label = 10;
                                case 10:
                                    _i++;
                                    return [3 /*break*/, 8];
                                case 11:
                                    if (!blAttachments[i]) return [3 /*break*/, 15];
                                    _d = 0, _e = blAttachments[i];
                                    _f.label = 12;
                                case 12:
                                    if (!(_d < _e.length)) return [3 /*break*/, 15];
                                    file = _e[_d];
                                    fileName = "BL_".concat(row.blNo, "_").concat(file.name);
                                    return [4 /*yield*/, props.context.spHttpClient.post("".concat(props.context.pageContext.web.absoluteUrl, "/_api/web/lists/getbytitle('ForexAdvanceBillPayment')/items(").concat(itemId, ")/AttachmentFiles/add(FileName='").concat(fileName, "')"), sp_http_1.SPHttpClient.configurations.v1, { body: file })];
                                case 13:
                                    _f.sent();
                                    _f.label = 14;
                                case 14:
                                    _d++;
                                    return [3 /*break*/, 12];
                                case 15: return [2 /*return*/];
                            }
                        });
                    };
                    i = 0;
                    _a.label = 4;
                case 4:
                    if (!(i < newRows.length)) return [3 /*break*/, 7];
                    return [5 /*yield**/, _loop_1(i)];
                case 5:
                    _a.sent();
                    _a.label = 6;
                case 6:
                    i++;
                    return [3 /*break*/, 4];
                case 7: return [4 /*yield*/, getTreasuryPaymentApprover()];
                case 8:
                    treasuryUserId = _a.sent();
                    return [4 /*yield*/, sp.getData("ForexRequest", "WorkFlowHistory", "", "ID eq ".concat(Id), { column: "ID", isAscending: true }, 1, props)];
                case 9:
                    existingItem = _a.sent();
                    existingHistory = [];
                    if (existingItem.length > 0 && existingItem[0].WorkFlowHistory) {
                        try {
                            existingHistory = JSON.parse(existingItem[0].WorkFlowHistory);
                        }
                        catch (_b) {
                            existingHistory = [];
                        }
                    }
                    updatedHistory = tslib_1.__spreadArray([], existingHistory, true);
                    advanceAmount = parseFloat(totalAmount || "0");
                    settledAmount = parseFloat(totalInvoiceAmount.toFixed(2) || "0");
                    finalStatus = "";
                    balanceAmount = 0;
                    if (advanceAmount === settledAmount) {
                        finalStatus = "Paid and Pending for Settlement";
                        balanceAmount = 0;
                    }
                    else {
                        finalStatus = "Paid";
                        balanceAmount = advanceAmount - settledAmount;
                    }
                    updatedHistory.push({
                        CurrentApprover: props.context.pageContext.user.displayName,
                        Role: "",
                        ActionTaken: "Tracker Submitted",
                        Comment: "",
                        Date: new Date().toISOString(),
                        CurrentStatus: finalStatus
                    });
                    return [4 /*yield*/, sp.updateData("ForexRequest", Number(Id), {
                            Status: finalStatus,
                            // 🔹 New fields
                            // TotalPerformaInvoice: advanceAmount,
                            // AdvancePaid: advanceAmount,
                            // AmountSettled: settledAmount,
                            // Balance: balanceAmount,
                            WorkFlowHistory: JSON.stringify(updatedHistory),
                            CurrentApproverId: finalStatus === "Paid and Pending for Settlement"
                                ? treasuryUserId
                                : null,
                            BalenceAmount: "" + balanceAmount
                        }, props)];
                case 10:
                    _a.sent();
                    alert("Tracker saved successfully");
                    history.push("/");
                    return [3 /*break*/, 12];
                case 11:
                    error_1 = _a.sent();
                    console.error(error_1);
                    alert("Error saving tracker");
                    return [3 /*break*/, 12];
                case 12: return [2 /*return*/];
            }
        });
    }); };
    var handleInvoiceFile = function (index, files) {
        if (!files)
            return;
        var updated = tslib_1.__assign({}, invoiceAttachments);
        updated[index] = Array.from(files);
        setInvoiceAttachments(updated);
    };
    var handleOtherFile = function (index, files) {
        if (!files)
            return;
        var updated = tslib_1.__assign({}, otherAttachments);
        updated[index] = Array.from(files);
        setOtherAttachmentsadvance(updated);
    };
    var handleBoeUpload = function (index, files) {
        if (!files)
            return;
        var updated = tslib_1.__assign({}, boeAttachments);
        updated[index] = Array.from(files);
        setBoeAttachments(updated);
    };
    var handleBlUpload = function (index, files) {
        if (!files)
            return;
        var updated = tslib_1.__assign({}, blAttachments);
        updated[index] = Array.from(files);
        setBlAttachments(updated);
    };
    return (react_1.default.createElement("div", { className: "forex-wrapper" },
        react_1.default.createElement("div", { className: "forex-header" },
            react_1.default.createElement("h2", null, "Forex Payment - Advance Payment Tracker")),
        react_1.default.createElement("div", { className: "forex-card" },
            react_1.default.createElement(Section, { title: "Requestor Information" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Type" },
                        react_1.default.createElement("input", { value: paymentType, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Code" },
                        react_1.default.createElement("input", { value: employee.EmployeeCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Name" },
                        react_1.default.createElement("input", { value: employee.EmployeeName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Division" },
                        react_1.default.createElement("input", { value: employee.Division, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Location" },
                        react_1.default.createElement("input", { value: employee.Location, readOnly: true })),
                    react_1.default.createElement(Field, { label: "RM" },
                        react_1.default.createElement("input", { value: employee.RM, readOnly: true })),
                    react_1.default.createElement(Field, { label: "HOD" },
                        react_1.default.createElement("input", { value: employee.HOD, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Contact No" },
                        react_1.default.createElement("input", { value: employee.ContactNo, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Employee Status" },
                        react_1.default.createElement("input", { value: employee.EmployeeStatus, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Email", full: true },
                        react_1.default.createElement("input", { value: employee.Email, readOnly: true })))),
            react_1.default.createElement(CollapsibleSection, { title: "Vendor - Beneficiary Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Vendor Code" },
                        react_1.default.createElement("input", { value: vendor.VendorCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Vendor Name" },
                        react_1.default.createElement("input", { value: vendor.VendorName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Address", full: true },
                        react_1.default.createElement("input", { value: vendor.VendorAddress, readOnly: true })),
                    react_1.default.createElement(Field, { label: "City" },
                        react_1.default.createElement("input", { value: vendor.City, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Country" },
                        react_1.default.createElement("input", { value: vendor.Country, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Pincode" },
                        react_1.default.createElement("input", { value: vendor.PostalCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Name" },
                        react_1.default.createElement("input", { value: vendor.BankName, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Country" },
                        react_1.default.createElement("input", { value: vendor.BankCountry, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Swift Code" },
                        react_1.default.createElement("input", { value: vendor.SWIFTBICCode, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank Branch" },
                        react_1.default.createElement("input", { value: vendor.BankAddress, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Bank IBAN / Account No", full: true },
                        react_1.default.createElement("input", { value: vendor.AccountNumberIBAN, readOnly: true })))),
            react_1.default.createElement(Section, { title: "Advance Payment Request Details" },
                react_1.default.createElement(Grid, null,
                    react_1.default.createElement(Field, { label: "Request Number" },
                        react_1.default.createElement("input", { value: requestNumber, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Currency" },
                        react_1.default.createElement("input", { value: currency, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Total Amount" },
                        react_1.default.createElement("input", { value: totalAmount || totalInvoiceAmountNew.toFixed(2), readOnly: true })),
                    react_1.default.createElement(Field, { label: "Foreign Bank Charges" },
                        react_1.default.createElement("input", { value: foreignBankCharges, readOnly: true })),
                    react_1.default.createElement(Field, { label: "Requested On" },
                        react_1.default.createElement("input", { type: "date", value: requestedOn, readOnly: true })))),
            react_1.default.createElement("table", { className: "data-table", style: { marginTop: "10px" } },
                react_1.default.createElement("thead", null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("th", null, "Sr.No."),
                        react_1.default.createElement("th", null, "Performa Invoice No"),
                        react_1.default.createElement("th", null, "Performa Invoice Date"),
                        react_1.default.createElement("th", null, "Performa Invoice Amount"),
                        react_1.default.createElement("th", null, "Attach PO"),
                        react_1.default.createElement("th", null, "Attach PI"),
                        react_1.default.createElement("th", null, "Attach Other"))),
                react_1.default.createElement("tbody", null, ShowInvoiceData.map(function (row, index) {
                    var _a, _b, _c;
                    return (react_1.default.createElement("tr", { key: index },
                        react_1.default.createElement("td", null, index + 1),
                        react_1.default.createElement("td", null, row.invoiceNo),
                        react_1.default.createElement("td", null, row.invoiceDate),
                        react_1.default.createElement("td", null, row.invoiceAmountnew),
                        react_1.default.createElement("td", null, ((_a = poAttachments[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 ? (poAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                            react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", className: "upload-link" }, file.FileName))); })) : (react_1.default.createElement("span", null, "-"))),
                        react_1.default.createElement("td", null, ((_b = piAttachments[index]) === null || _b === void 0 ? void 0 : _b.length) > 0 ? (piAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                            react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", className: "upload-link" }, file.FileName))); })) : (react_1.default.createElement("span", null, "-"))),
                        react_1.default.createElement("td", null, ((_c = otherAttachments[index]) === null || _c === void 0 ? void 0 : _c.length) > 0 ? (otherAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                            react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", className: "upload-link" }, file.FileName))); })) : (react_1.default.createElement("span", null, "-")))));
                }))),
            react_1.default.createElement(CollapsibleSection, { title: "Workflow History" }, workflowHistory.length > 0 ? (react_1.default.createElement("table", { className: "data-table" },
                react_1.default.createElement("thead", null,
                    react_1.default.createElement("tr", null,
                        react_1.default.createElement("th", null, "Action By"),
                        react_1.default.createElement("th", null, "Action"),
                        react_1.default.createElement("th", null, "Remark"),
                        react_1.default.createElement("th", null, "Date"))),
                react_1.default.createElement("tbody", null, workflowHistory.map(function (item, index) { return (react_1.default.createElement("tr", { key: index },
                    react_1.default.createElement("td", null, item.CurrentApprover),
                    react_1.default.createElement("td", null, item.ActionTaken),
                    react_1.default.createElement("td", null, item.Comment || "-"),
                    react_1.default.createElement("td", null, item.Date
                        ? new Date(item.Date).toLocaleString("en-GB")
                        : ""))); })))) : (react_1.default.createElement("p", null, "No workflow history available"))),
            paymentType === "Goods-Advance Payment" && (react_1.default.createElement(react_1.default.Fragment, null,
                react_1.default.createElement(Section, { title: "Bill Payment Details (For Goods Bill Payment)" },
                    react_1.default.createElement("table", { className: "data-table" },
                        react_1.default.createElement("thead", null,
                            react_1.default.createElement("tr", null,
                                react_1.default.createElement("th", null, "Sr.No. "),
                                react_1.default.createElement("th", null,
                                    "Invoice Number ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null,
                                    "Invoice Date ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null,
                                    "BOE Number ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null,
                                    "BOE Date ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null,
                                    "MRN Number ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null,
                                    "Bill of Lading Number ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null,
                                    "Bill of Lading Date ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null,
                                    "Invoice Amount ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null,
                                    "Attach Invoice ",
                                    react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                                react_1.default.createElement("th", null, "Attach Other "),
                                react_1.default.createElement("th", null, "Add/Delete entry"))),
                        react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                            var _a, _b;
                            return (react_1.default.createElement("tr", { key: index },
                                react_1.default.createElement("td", null, index + 1),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) { return handleChange(index, "invoiceNo", e.target.value); } })),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) { return handleChange(index, "invoiceDate", e.target.value); } })),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { value: row.boeNo, onChange: function (e) { return handleChange(index, "boeNo", e.target.value); } })),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { type: "date", value: row.boeDate, onChange: function (e) { return handleChange(index, "boeDate", e.target.value); } })),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { value: row.mrnNo, onChange: function (e) { return handleChange(index, "mrnNo", e.target.value); } })),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { value: row.blNo, onChange: function (e) { return handleChange(index, "blNo", e.target.value); } })),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { type: "date", value: row.blDate, onChange: function (e) { return handleChange(index, "blDate", e.target.value); } })),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { type: "number", value: row.invoiceAmount, onChange: function (e) { return handleChange(index, "invoiceAmount", e.target.value); } })),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { type: "file", onChange: function (e) { return handleInvoiceFile(index, e.target.files); } }),
                                    ((_a = invoiceAttachments[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 && (react_1.default.createElement("div", { style: { marginTop: "5px" } }, invoiceAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", style: { fontSize: "12px" } }, file.FileName))); })))),
                                react_1.default.createElement("td", null,
                                    react_1.default.createElement("input", { type: "file", onChange: function (e) { return handleOtherFile(index, e.target.files); } }),
                                    ((_b = otherAttachmentsadvance[index]) === null || _b === void 0 ? void 0 : _b.length) > 0 && (react_1.default.createElement("div", { style: { marginTop: "5px" } }, otherAttachmentsadvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                        react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", style: { fontSize: "12px" } }, file.FileName))); })))),
                                react_1.default.createElement("td", { style: { textAlign: "center" } },
                                    index === rows.length - 1 && (react_1.default.createElement("span", { style: { cursor: "pointer" }, onClick: addRow }, "+")),
                                    rows.length > 1 && (react_1.default.createElement("span", { style: { cursor: "pointer", marginLeft: "8px" }, onClick: function () { return deleteRow(index); } }, "\u2716")))));
                        })),
                        react_1.default.createElement("tfoot", null,
                            react_1.default.createElement("tr", null,
                                react_1.default.createElement("td", { colSpan: 7 }),
                                react_1.default.createElement("td", { style: { fontWeight: "bold" } }, "Total Amount"),
                                react_1.default.createElement("td", null, totalInvoiceAmount.toFixed(2)),
                                react_1.default.createElement("td", { colSpan: 3 }))))),
                react_1.default.createElement("div", { style: { display: "flex", gap: "40px", marginTop: "20px" } },
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "12px" } }, "Unique BOE no will be listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "BOE No"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBoeNumbers.map(function (boe, index) {
                                var _a;
                                return (react_1.default.createElement("tr", { key: index },
                                    react_1.default.createElement("td", null, boe),
                                    react_1.default.createElement("td", null,
                                        react_1.default.createElement("input", { type: "file", onChange: function (e) { return handleBoeUpload(index, e.target.files); } }), (_a = boeAttachments[index]) === null || _a === void 0 ? void 0 :
                                        _a.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                            react_1.default.createElement("a", { href: file.ServerRelativeUrl || "#", target: "_blank", rel: "noopener noreferrer", style: { fontSize: "12px" } }, file.FileName || file.name))); }))));
                            })))),
                    react_1.default.createElement("div", null,
                        react_1.default.createElement("p", { style: { color: "red", fontSize: "12px" } }, "Unique Bill of lading no will be listed below"),
                        react_1.default.createElement("table", { className: "data-table" },
                            react_1.default.createElement("thead", null,
                                react_1.default.createElement("tr", null,
                                    react_1.default.createElement("th", null, "Bill of Lading"),
                                    react_1.default.createElement("th", null, "Attach Documents"))),
                            react_1.default.createElement("tbody", null, uniqueBlNumbers.map(function (bl, index) {
                                var _a;
                                return (react_1.default.createElement("tr", { key: index },
                                    react_1.default.createElement("td", null, bl),
                                    react_1.default.createElement("td", null,
                                        react_1.default.createElement("input", { type: "file", onChange: function (e) { return handleBlUpload(index, e.target.files); } }), (_a = blAttachments[index]) === null || _a === void 0 ? void 0 :
                                        _a.map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                            react_1.default.createElement("a", { href: file.ServerRelativeUrl || "#", target: "_blank", rel: "noopener noreferrer", style: { fontSize: "12px" } }, file.FileName || file.name))); }))));
                            }))))))),
            paymentType === "Service-Advance Payment" && (react_1.default.createElement("div", { style: { marginTop: "30px" } },
                react_1.default.createElement("p", null,
                    react_1.default.createElement("b", null, "Bill Payment Details (for Service Bill Payment)")),
                react_1.default.createElement("table", { className: "data-table" },
                    react_1.default.createElement("thead", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("th", null, "Sr.No."),
                            react_1.default.createElement("th", null,
                                "Invoice Number ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Invoice Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Invoice Amount ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "MRN Number ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "MRN Date ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null,
                                "Attach Invoice ",
                                react_1.default.createElement("span", { className: "required", style: { color: "red" } }, "*")),
                            react_1.default.createElement("th", null, "Attach Other Document"),
                            react_1.default.createElement("th", null, "Add/Delete entry"))),
                    react_1.default.createElement("tbody", null, rows.map(function (row, index) {
                        var _a, _b;
                        return (react_1.default.createElement("tr", { key: index },
                            react_1.default.createElement("td", null, index + 1),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceNo, onChange: function (e) { return handleChange(index, "invoiceNo", e.target.value); } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.invoiceDate, onChange: function (e) { return handleChange(index, "invoiceDate", e.target.value); } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.invoiceAmount, onChange: function (e) { return handleChange(index, "invoiceAmount", e.target.value); } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { value: row.mrnNo, onChange: function (e) { return handleChange(index, "mrnNo", e.target.value); } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "date", value: row.mrnDate || "", onChange: function (e) { return handleChange(index, "mrnDate", e.target.value); } })),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "file", onChange: function (e) { return handleInvoiceFile(index, e.target.files); } }),
                                ((_a = invoiceAttachments[index]) === null || _a === void 0 ? void 0 : _a.length) > 0 && (react_1.default.createElement("div", { style: { marginTop: "5px" } }, invoiceAttachments[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", style: { fontSize: "12px" } }, file.FileName))); })))),
                            react_1.default.createElement("td", null,
                                react_1.default.createElement("input", { type: "file", onChange: function (e) { return handleOtherFile(index, e.target.files); } }),
                                ((_b = otherAttachmentsadvance[index]) === null || _b === void 0 ? void 0 : _b.length) > 0 && (react_1.default.createElement("div", { style: { marginTop: "5px" } }, otherAttachmentsadvance[index].map(function (file, i) { return (react_1.default.createElement("div", { key: i },
                                    react_1.default.createElement("a", { href: file.ServerRelativeUrl, target: "_blank", rel: "noopener noreferrer", style: { fontSize: "12px" } }, file.FileName))); })))),
                            react_1.default.createElement("td", null,
                                rows.length > 1 && (react_1.default.createElement("span", { onClick: function () { return deleteRow(index); } }, "\u2716")),
                                index === rows.length - 1 && (react_1.default.createElement("span", { style: { marginLeft: "8px" }, onClick: addRow }, "+")))));
                    })),
                    react_1.default.createElement("tfoot", null,
                        react_1.default.createElement("tr", null,
                            react_1.default.createElement("td", { colSpan: 2 }),
                            react_1.default.createElement("td", { style: { fontWeight: "bold" } }, "Total Amount"),
                            react_1.default.createElement("td", null, totalInvoiceAmount.toFixed(2)),
                            react_1.default.createElement("td", { colSpan: 5 })))))),
            react_1.default.createElement("div", { className: "button-row" },
                react_1.default.createElement("button", { className: "btn-submit", onClick: onSubmit }, "Submit"),
                react_1.default.createElement("button", { className: "btn-exit", onClick: function () { return history.push("/"); } }, "Exit")))));
};
exports.default = TrackerForm;
//# sourceMappingURL=InitiatorPaymentForm.js.map