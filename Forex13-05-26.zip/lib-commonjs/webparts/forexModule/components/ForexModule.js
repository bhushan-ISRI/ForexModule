"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_router_dom_1 = require("react-router-dom");
var Sidebar_1 = tslib_1.__importDefault(require("../components/Pages/Sidebar"));
var InitiatorDashboard_1 = require("../components/Pages/InitiatorDashboard");
var NewRequestForm_1 = tslib_1.__importDefault(require("./Pages/NewRequestForm"));
var ApprovalDashboard_1 = tslib_1.__importDefault(require("./Pages/ApprovalDashboard"));
var APTeamLandingPage_1 = tslib_1.__importDefault(require("./Pages/APTeamLandingPage"));
var TreasuryLandingPage_1 = tslib_1.__importDefault(require("./Pages/TreasuryLandingPage"));
var NewRequestEditForm_1 = tslib_1.__importDefault(require("./Pages/NewRequestEditForm"));
var NewRequestViewForm_1 = tslib_1.__importDefault(require("./Pages/NewRequestViewForm"));
var ApprovalRequestForm_1 = tslib_1.__importDefault(require("./Pages/ApprovalRequestForm"));
var InitiatorPaymentForm_1 = tslib_1.__importDefault(require("./Pages/InitiatorPaymentForm"));
var TrackerApprovalForm_1 = tslib_1.__importDefault(require("./Pages/TrackerApprovalForm"));
var ApprovedRejectByme_1 = tslib_1.__importDefault(require("./Pages/ApprovedRejectByme"));
var ForexModule = function (props) {
    var description = props.description, isDarkTheme = props.isDarkTheme, environmentMessage = props.environmentMessage, hasTeamsContext = props.hasTeamsContext, userDisplayName = props.userDisplayName;
    var location = (0, react_router_dom_1.useLocation)(); // ✅ Now inside Router
    var hideSidebar = location.pathname === "/NewRequest" ||
        location.pathname.startsWith("/ViewRequest/") ||
        location.pathname.startsWith("/EditRequest/") ||
        location.pathname.startsWith("/ApprovalRequest/") || location.pathname.startsWith("/AdvancePaymentTracker/") || location.pathname.startsWith('/TrackerApprovalForm/') || location.pathname.startsWith('/ApprovedRejectedByMe');
    return (React.createElement("div", { className: "container-fluid", style: { display: 'flex', width: '100%' } },
        !hideSidebar && React.createElement(Sidebar_1.default, tslib_1.__assign({}, props)),
        React.createElement("div", { className: "main" },
            React.createElement(react_router_dom_1.Switch, null,
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/", render: function () { return React.createElement(InitiatorDashboard_1.InitiatorDashboard, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/NewRequest", render: function () { return React.createElement(NewRequestForm_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/ViewRequest/:Id", render: function () { return React.createElement(NewRequestViewForm_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/EditRequest/:Id", render: function () { return React.createElement(NewRequestEditForm_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/AdvancePaymentTracker/:Id", render: function () { return React.createElement(InitiatorPaymentForm_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/ApprovalRequest/:Id", render: function () { return React.createElement(ApprovalRequestForm_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/ApprovalDashboard", render: function () { return React.createElement(ApprovalDashboard_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/APTeamLandingPage", render: function () { return React.createElement(APTeamLandingPage_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/TreasuryLandingPage", render: function () { return React.createElement(TreasuryLandingPage_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/TrackerApprovalForm/:Id", render: function () { return React.createElement(TrackerApprovalForm_1.default, tslib_1.__assign({}, props)); } }),
                React.createElement(react_router_dom_1.Route, { exact: true, path: "/ApprovedRejectedByMe", render: function () { return React.createElement(ApprovedRejectByme_1.default, tslib_1.__assign({}, props)); } })))));
};
var Drr = function (props) {
    return (React.createElement(react_router_dom_1.HashRouter, null,
        React.createElement(ForexModule, tslib_1.__assign({}, props))));
};
exports.default = Drr;
//# sourceMappingURL=ForexModule.js.map