"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = SPCRUDOPS;
var tslib_1 = require("tslib");
var all_1 = require("@pnp/sp/presets/all");
var sp_1 = require("@pnp/sp");
require("@pnp/sp/lists");
require("@pnp/sp/items");
var SPCRUDOPSImpl = /** @class */ (function () {
    function SPCRUDOPSImpl() {
    }
    SPCRUDOPSImpl.prototype.getData = function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!props.currentSPContext || !props.currentSPContext.pageContext) {
                            throw new Error('SharePoint context is not available');
                        }
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        items = web.lists.getByTitle(listName).items;
                        if (columnsToRetrieve) {
                            items = items.select(columnsToRetrieve);
                        }
                        if (columnsToExpand) {
                            items = items.expand(columnsToExpand);
                        }
                        if (filters) {
                            items = items.filter(filters);
                        }
                        if (orderby) {
                            items = items.orderBy(orderby.column, orderby.isAscending);
                        }
                        return [4 /*yield*/, items.getAll()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getRootData = function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var fullUrl, parts, baseUrl, web, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!props.currentSPContext || !props.currentSPContext.pageContext) {
                            throw new Error('SharePoint context is not available');
                        }
                        fullUrl = props.currentSPContext.pageContext.web.absoluteUrl;
                        parts = fullUrl.split('/');
                        baseUrl = parts.slice(0, 5).join('/');
                        web = (0, all_1.Web)(baseUrl);
                        items = web.lists.getByTitle(listName).items;
                        if (columnsToRetrieve) {
                            items = items.select(columnsToRetrieve);
                        }
                        if (columnsToExpand) {
                            items = items.expand(columnsToExpand);
                        }
                        if (filters) {
                            items = items.filter(filters);
                        }
                        if (orderby) {
                            items = items.orderBy(orderby.column, orderby.isAscending);
                        }
                        return [4 /*yield*/, items.getAll()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.insertData = function (listName, data, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.lists.getByTitle(listName).items.add(data)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.updateData = function (listName, itemId, data, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.lists.getByTitle(listName).items.getById(itemId).update(data)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.deleteData = function (listName, itemId, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.lists.getByTitle(listName).items.getById(itemId).recycle()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getListInfo = function (listName, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.lists.getByTitle(listName).get()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getListData = function (listName, columnsToRetrieve, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        items = web.lists.getByTitle(listName).items;
                        if (columnsToRetrieve) {
                            items = items.select(columnsToRetrieve);
                        }
                        return [4 /*yield*/, items.get()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.batchInsert = function (listName, data, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web, entityTypeFullName, batch;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.lists.getByTitle(listName).getListItemEntityTypeFullName()];
                    case 1:
                        entityTypeFullName = _a.sent();
                        batch = web.createBatch();
                        data.forEach(function (item) {
                            web.lists.getByTitle(listName).items.inBatch(batch).add(item, entityTypeFullName);
                        });
                        return [4 /*yield*/, batch.execute()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.batchUpdate = function (listName, data, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web, batch;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        batch = web.createBatch();
                        data.forEach(function (item) {
                            web.lists.getByTitle(listName).items.getById(item.Id).inBatch(batch).update(item);
                        });
                        return [4 /*yield*/, batch.execute()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.batchDelete = function (listName, data, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web, batch;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        batch = web.createBatch();
                        data.forEach(function (item) {
                            web.lists.getByTitle(listName).items.getById(item.Id).inBatch(batch).delete();
                        });
                        return [4 /*yield*/, batch.execute()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.createFolder = function (listName, folderName, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.lists.getByTitle(listName).rootFolder.folders.addUsingPath(folderName)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.uploadFile = function (folderServerRelativeUrl, file, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.getFolderByServerRelativeUrl(folderServerRelativeUrl).files.add(file.name, file, true)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.deleteFile = function (fileServerRelativeUrl, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.getFileByServerRelativeUrl(fileServerRelativeUrl).recycle()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    // async currentProfile(props: IForexModuleProps): Promise<any> {
    //     const web = Web(props.currentSPContext.pageContext.web.absoluteUrl);
    //     return await web.currentUser.get();
    // }
    SPCRUDOPSImpl.prototype.currentProfile = function (props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var profile, error_1;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, sp_1.sp.profiles.myProperties.get()];
                    case 1:
                        profile = _a.sent();
                        return [2 /*return*/, profile];
                    case 2:
                        error_1 = _a.sent();
                        console.error("Error fetching user profile", error_1);
                        return [2 /*return*/, null];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getLoggedInSiteGroups = function (props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.currentUser.groups.get()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getAllSiteGroups = function (props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.siteGroups.get()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.getTopData = function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web, items;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        items = web.lists.getByTitle(listName).items;
                        if (columnsToRetrieve) {
                            items = items.select(columnsToRetrieve);
                        }
                        if (columnsToExpand) {
                            items = items.expand(columnsToExpand);
                        }
                        if (filters) {
                            items = items.filter(filters);
                        }
                        if (orderby) {
                            items = items.orderBy(orderby.column, orderby.isAscending);
                        }
                        if (top) {
                            items = items.top(top);
                        }
                        return [4 /*yield*/, items.get()];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    SPCRUDOPSImpl.prototype.addAttchmentInList = function (data, listName, itemId, fileName, props) {
        return tslib_1.__awaiter(this, void 0, void 0, function () {
            var web;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        web = (0, all_1.Web)(props.currentSPContext.pageContext.web.absoluteUrl);
                        return [4 /*yield*/, web.lists.getByTitle(listName).items.getById(itemId).attachmentFiles.add(fileName, data)];
                    case 1: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    return SPCRUDOPSImpl;
}());
function SPCRUDOPS() {
    return Promise.resolve(new SPCRUDOPSImpl());
}
//# sourceMappingURL=spcrudops.js.map