"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = USESPCRUD;
var tslib_1 = require("tslib");
require("@pnp/sp/lists");
require("@pnp/sp/items");
var spcrudops_1 = tslib_1.__importDefault(require("../../service/DAL/spcrudops"));
function USESPCRUD() {
    return tslib_1.__awaiter(this, void 0, void 0, function () {
        var spCrudOps;
        var _this = this;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, (0, spcrudops_1.default)()];
                case 1:
                    spCrudOps = _a.sent();
                    return [2 /*return*/, {
                            getData: function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getData(listName, columnsToRetrieve, columnsToExpand, filters, orderby, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getRootData: function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getData(listName, columnsToRetrieve, columnsToExpand, filters, orderby, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            insertData: function (listName, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.insertData(listName, data, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            updateData: function (listName, itemId, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.updateData(listName, itemId, data, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            deleteData: function (listName, itemId, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.deleteData(listName, itemId, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getListInfo: function (listName, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getListInfo(listName, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getListData: function (listName, columnsToRetrieve, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getListData(listName, columnsToRetrieve, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            batchInsert: function (listName, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.batchInsert(listName, data, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            batchUpdate: function (listName, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.batchUpdate(listName, data, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            batchDelete: function (listName, data, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.batchDelete(listName, data, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            createFolder: function (listName, folderName, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.createFolder(listName, folderName, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            uploadFile: function (folderServerRelativeUrl, file, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.uploadFile(folderServerRelativeUrl, file, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            deleteFile: function (fileServerRelativeUrl, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.deleteFile(fileServerRelativeUrl, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            currentProfile: function (props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.currentProfile(props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            // const currentUserProfile = async (props: IDeviationuatProps) => {
                            //    // const queryUrl = "https://etgworld.sharepoint.com/sites/UAT_BPM/_api/web/currentuser/groups";
                            //     const result: any = await (await spCrudOps).currentUserProfile( props);
                            //     return result;
                            // };
                            getLoggedInSiteGroups: function (props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getLoggedInSiteGroups(props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getAllSiteGroups: function (props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getAllSiteGroups(props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            getTopData: function (listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.getTopData(listName, columnsToRetrieve, columnsToExpand, filters, orderby, top, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); },
                            addAttchmentInList: function (attFiles, listName, itemId, fileName, props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
                                return tslib_1.__generator(this, function (_a) {
                                    switch (_a.label) {
                                        case 0: return [4 /*yield*/, spCrudOps.addAttchmentInList(attFiles, listName, itemId, fileName, props)];
                                        case 1: return [2 /*return*/, _a.sent()];
                                    }
                                });
                            }); }
                        }];
            }
        });
    });
}
//# sourceMappingURL=spcrud.js.map