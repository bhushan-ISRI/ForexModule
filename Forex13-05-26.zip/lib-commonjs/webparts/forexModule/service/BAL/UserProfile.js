"use strict";
// import { IForexModuleProps } from '../../components/IForexModuleProps';
// import SPCRUDOPS from '../DAL/spcrudops';
// import { IUserProfile } from '../../services/INTERFACES/IUserProfile';
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = LoggUserProfileOps;
var tslib_1 = require("tslib");
var spcrudops_1 = tslib_1.__importDefault(require("../DAL/spcrudops"));
function LoggUserProfileOps() {
    var _this = this;
    var spCrudOps = (0, spcrudops_1.default)();
    var getLoggUserProfile = function (props) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var result, userProfileProperties, locationValue;
        var _a, _b;
        return tslib_1.__generator(this, function (_c) {
            switch (_c.label) {
                case 0: return [4 /*yield*/, spCrudOps];
                case 1: return [4 /*yield*/, (_c.sent()).currentProfile(props)];
                case 2:
                    result = _c.sent();
                    userProfileProperties = (_a = result.UserProfileProperties) !== null && _a !== void 0 ? _a : [];
                    locationValue = ((_b = userProfileProperties.find(function (prop) { return prop.Key === 'Office'; } // Change this key if needed
                    )) === null || _b === void 0 ? void 0 : _b.Value) || "Location not found";
                    return [2 /*return*/, {
                            AccountName: result.AccountName,
                            UserProfileProperties: userProfileProperties,
                            Location: locationValue
                        }];
            }
        });
    }); };
    return {
        getLoggUserProfile: getLoggUserProfile
    };
}
//# sourceMappingURL=UserProfile.js.map