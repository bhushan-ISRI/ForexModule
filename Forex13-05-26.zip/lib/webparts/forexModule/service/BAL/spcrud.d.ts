import "@pnp/sp/lists";
import "@pnp/sp/items";
import { IForexModuleProps } from "../../components/IForexModuleProps";
export interface ISPCRUD {
    [x: string]: any;
    getData(listName: string, columnsToRetrieve: string, columnsToExpand: string, filters: string, orderby: {
        column: string;
        isAscending: boolean;
    }, top: number, props: IForexModuleProps): Promise<any>;
    getRootData(listName: string, columnsToRetrieve: string, columnsToExpand: string, filters: string, orderby: {
        column: string;
        isAscending: boolean;
    }, top: number, props: IForexModuleProps): Promise<any>;
    insertData(listName: string, data: any, props: IForexModuleProps): Promise<any>;
    updateData(listName: string, itemId: number, data: any, props: IForexModuleProps): Promise<any>;
    deleteData(listName: string, itemId: number, props: IForexModuleProps): Promise<any>;
    getListInfo(listName: string, props: IForexModuleProps): Promise<any>;
    getListData(listName: string, columnsToRetrieve: string, props: IForexModuleProps): Promise<any>;
    batchInsert(listName: string, data: any, props: IForexModuleProps): Promise<any>;
    batchUpdate(listName: string, data: any, props: IForexModuleProps): Promise<any>;
    batchDelete(listName: string, data: any, props: IForexModuleProps): Promise<any>;
    createFolder(listName: string, folderName: string, props: IForexModuleProps): Promise<any>;
    uploadFile(folderServerRelativeUrl: string, file: File, props: IForexModuleProps): Promise<any>;
    deleteFile(fileServerRelativeUrl: string, props: IForexModuleProps): Promise<any>;
    currentProfile(props: IForexModuleProps): Promise<any>;
    getLoggedInSiteGroups(props: IForexModuleProps): Promise<any>;
    getAllSiteGroups(props: IForexModuleProps): Promise<any>;
    getTopData(listName: string, columnsToRetrieve: string, columnsToExpand: string, filters: string, orderby: {
        column: string;
        isAscending: boolean;
    }, top: number, props: IForexModuleProps): Promise<any>;
    addAttchmentInList(attFiles: File, listName: string, itemId: number, fileName: string, props: IForexModuleProps): Promise<any>;
}
export default function USESPCRUD(): Promise<ISPCRUD>;
//# sourceMappingURL=spcrud.d.ts.map