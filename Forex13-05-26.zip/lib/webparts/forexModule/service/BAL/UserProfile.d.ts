import { IForexModuleProps } from '../../components/IForexModuleProps';
import { IUserProfile } from '../../service/INTERFACE/IUserProfile';
export interface UserProfileOps {
    getLoggUserProfile(props: IForexModuleProps): Promise<IUserProfile>;
}
export default function LoggUserProfileOps(): UserProfileOps;
//# sourceMappingURL=UserProfile.d.ts.map