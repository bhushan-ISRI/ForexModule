export interface IUserProfile {
    Id?: number;
    AccountName?: string;
    UserName?: any;
    Key?: any;
    Value?: any;
    RequestorName?: any;
    RequestorDepartment?: any;
    EmployeeID?: any;
    Location?: any;
    UserProfileProperties: {
        Key: string;
        Value: string;
    }[];
}
//# sourceMappingURL=IUserProfile.d.ts.map