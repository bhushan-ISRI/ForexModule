import * as React from 'react';
import type { IForexModuleProps } from './IForexModuleProps';
declare const Drr: React.FC<IForexModuleProps>;
export default Drr;
//# sourceMappingURL=ForexModule.d.ts.map