import "../Pages/Css/NewRequest.scss";
import { IForexModuleProps } from "../IForexModuleProps";
import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
declare const NewRequest: (props: IForexModuleProps) => JSX.Element;
export default NewRequest;
//# sourceMappingURL=NewRequestForm.d.ts.map