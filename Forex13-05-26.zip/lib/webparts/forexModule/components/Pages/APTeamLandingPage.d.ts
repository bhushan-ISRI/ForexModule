import * as React from "react";
import type { IForexModuleProps } from "../IForexModuleProps";
import "../../components/Pages/Css/InitiatorDashboard.scss";
export declare const APTeamLP: React.FC<IForexModuleProps>;
export default APTeamLP;
//# sourceMappingURL=APTeamLandingPage.d.ts.map