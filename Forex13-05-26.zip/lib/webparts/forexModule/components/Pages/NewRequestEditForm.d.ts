import "../Pages/Css/NewRequest.scss";
import { IForexModuleProps } from "../IForexModuleProps";
declare const Editrequest: (props: IForexModuleProps) => JSX.Element;
export default Editrequest;
//# sourceMappingURL=NewRequestEditForm.d.ts.map