import "../Pages/Css/NewRequest.scss";
import { IForexModuleProps } from "../IForexModuleProps";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/attachments";
declare const ApprovalRequestForm: (props: IForexModuleProps) => JSX.Element;
export default ApprovalRequestForm;
//# sourceMappingURL=ApprovalRequestForm.d.ts.map