import * as React from "react";
import type { IForexModuleProps } from "../IForexModuleProps";
import "../../components/Pages/Css/ApprovedRejectedbyme.scss";
declare const ModernForexDashboard: React.FC<IForexModuleProps>;
export default ModernForexDashboard;
//# sourceMappingURL=ApprovedRejectByme.d.ts.map