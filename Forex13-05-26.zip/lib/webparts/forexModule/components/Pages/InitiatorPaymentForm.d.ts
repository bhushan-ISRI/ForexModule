import "../Pages/Css/NewRequest.scss";
import { IForexModuleProps } from "../IForexModuleProps";
declare const TrackerForm: (props: IForexModuleProps) => JSX.Element;
export default TrackerForm;
//# sourceMappingURL=InitiatorPaymentForm.d.ts.map