import * as React from "react";
import type { IForexModuleProps } from "../IForexModuleProps";
import "../../components/Pages/Css/InitiatorDashboard.scss";
export declare const InitiatorDashboard: React.FC<IForexModuleProps>;
export default InitiatorDashboard;
//# sourceMappingURL=InitiatorDashboard.d.ts.map