import '../../components/Pages/Css/Sidebar.scss';
import { IForexModuleProps } from '../IForexModuleProps';
import '@fortawesome/fontawesome-free/css/all.min.css';
declare const Sidebar: (props: IForexModuleProps) => JSX.Element;
export default Sidebar;
//# sourceMappingURL=Sidebar.d.ts.map