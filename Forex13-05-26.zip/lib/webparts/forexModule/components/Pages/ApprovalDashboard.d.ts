import * as React from "react";
import type { IForexModuleProps } from "../IForexModuleProps";
import "../../components/Pages/Css/InitiatorDashboard.scss";
export declare const ApprovalDashboard: React.FC<IForexModuleProps>;
export default ApprovalDashboard;
//# sourceMappingURL=ApprovalDashboard.d.ts.map