import "../Pages/Css/NewRequest.scss";
import { IForexModuleProps } from "../IForexModuleProps";
declare const TrackerApprovalForm: (props: IForexModuleProps) => JSX.Element;
export default TrackerApprovalForm;
//# sourceMappingURL=TrackerApprovalForm.d.ts.map