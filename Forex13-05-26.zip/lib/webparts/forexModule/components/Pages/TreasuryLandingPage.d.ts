import * as React from "react";
import type { IForexModuleProps } from "../IForexModuleProps";
import "../../components/Pages/Css/InitiatorDashboard.scss";
export declare const TreasuryLandingPage: React.FC<IForexModuleProps>;
export default TreasuryLandingPage;
//# sourceMappingURL=TreasuryLandingPage.d.ts.map