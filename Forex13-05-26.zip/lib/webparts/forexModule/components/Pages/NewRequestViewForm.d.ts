import "../Pages/Css/NewRequest.scss";
import { IForexModuleProps } from "../IForexModuleProps";
declare const ViewRequestForm: (props: IForexModuleProps) => JSX.Element;
export default ViewRequestForm;
//# sourceMappingURL=NewRequestViewForm.d.ts.map